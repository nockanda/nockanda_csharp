﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example55
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        int location = 0;
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[1];
                serialPort1.Read(recv, 0, 1);
                int data = recv[0] - 16;
                location = location + data;
                print(location);
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "" && serialPort1.IsOpen)
            {
                string input = textBox2.Text;
                for(int i = 0; i < input.Length; i++)
                {
                    //input[i]
                    byte[] send = new byte[1];
                    send[0] = (byte)input[i];
                    serialPort1.Write(send, 0, 1);
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        void print(int n)
        {
            Bitmap bt = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(SystemColors.Control);
            int center_x = bt.Width / 2;
            int center_y = bt.Height / 2;
            //g.DrawLine(Pens.Black, 0, center_y, bt.Width, center_y);
            //g.DrawLine(Pens.Black, center_x, 0, center_x, bt.Height);
            g.DrawEllipse(Pens.Black, 0, 0, bt.Width - 1, bt.Height - 1);
            //g.DrawRectangle(Pens.Black, 0, 0, bt.Width - 1, bt.Height - 1);

            //double degree = 30;
            //몇번칸이 몇도인가?
            //n*22.5 = 칸번호
            double b_x = center_x + ((center_x / 2.0) * Math.Cos(n * 22.5 * (Math.PI / 180.0))); ;
            double b_y = center_y + ((center_x / 2.0) * Math.Sin(n * 22.5 * (Math.PI / 180.0))) * -1;
            g.DrawLine(Pens.Black, center_x, center_y, (float)b_x, (float)b_y);

            byte i = 0;
            for (double degree = 0; degree < 360; degree += 22.5)
            {

                double arc_x = center_x + ((center_x - 40) * Math.Cos(degree * (Math.PI / 180.0)));
                double arc_y = center_y + ((center_x - 40) * Math.Sin(degree * (Math.PI / 180.0))) * -1;
                g.DrawString(i.ToString("X"), DefaultFont, Brushes.Black, (float)arc_x, (float)arc_y);
                i++;

                //g.DrawLine(Pens.Red, center_x, center_y, (float)arc_x, (float)arc_y);
            }
            for (double degree = 11.25; degree < 360; degree += 22.5)
            {

                double arc_x = center_x + (center_x * Math.Cos(degree * (Math.PI / 180.0)));
                double arc_y = center_y + (center_x * Math.Sin(degree * (Math.PI / 180.0))) * -1;
                g.DrawLine(Pens.Blue, center_x, center_y, (float)arc_x, (float)arc_y);
            }
            g.Dispose();
            pictureBox1.Image = bt;
        }
    }
}
