﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using MediaPlayer;
using System.Xml;

namespace example134
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string url = "https://kakaoi-newtone-openapi.kakao.com/v1/synthesize";

            string your_key = textBox1.Text;


            //웹클라이언트에서 정성스럽게 요청을 해야한다!
            WebRequest wr = WebRequest.Create(url);
            wr.Method = "POST";
            wr.ContentType = "application/xml";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);


            string text = "<speak><voice name=\"" + comboBox1.SelectedItem + "\">" + richTextBox1.Text + "</voice></speak>";

            byte[] request = Encoding.UTF8.GetBytes(text);
            Stream request_stream = wr.GetRequestStream();
            request_stream.Write(request, 0, request.Length);

            request_stream.Close();


            WebResponse wrs = wr.GetResponse();
            Stream response_stream = wrs.GetResponseStream();
            //응답데이터가 mp3인 상황이라서!
            //이것을 파일로 저장해야한다!

            string path = "./output.mp3";
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            FileStream fs = new FileStream("./output.mp3", FileMode.Create);

            response_stream.CopyTo(fs);

            fs.Close();
            fs.Dispose();
            response_stream.Close();
            response_stream.Dispose();
            wrs.Close();


            MediaPlayerClass mpc = new MediaPlayerClass();
            mpc.FileName = "./output.mp3";
            mpc.Play();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string data = get_rss();
            richTextBox2.Text = data;
            string url = "https://kakaoi-newtone-openapi.kakao.com/v1/synthesize";

            string your_key = textBox1.Text;


            //웹클라이언트에서 정성스럽게 요청을 해야한다!
            WebRequest wr = WebRequest.Create(url);
            wr.Method = "POST";
            wr.ContentType = "application/xml";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);


            string text = "<speak>"+ data + "</speak>";

            byte[] request = Encoding.UTF8.GetBytes(text);
            Stream request_stream = wr.GetRequestStream();
            request_stream.Write(request, 0, request.Length);

            request_stream.Close();


            WebResponse wrs = wr.GetResponse();
            Stream response_stream = wrs.GetResponseStream();
            //응답데이터가 mp3인 상황이라서!
            //이것을 파일로 저장해야한다!

            string path = "./output.mp3";
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            FileStream fs = new FileStream("./output.mp3", FileMode.Create);

            response_stream.CopyTo(fs);

            fs.Close();
            fs.Dispose();
            response_stream.Close();
            response_stream.Dispose();
            wrs.Close();


            MediaPlayerClass mpc = new MediaPlayerClass();
            mpc.FileName = "./output.mp3";
            mpc.Play();
        }


        string get_rss()
        {
            string url = "https://www.weather.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=108";

            WebRequest wr = WebRequest.Create(url);
            wr.Method = "GET";

            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            //xml파싱을 해야겠다!
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["rss"]["channel"]["item"]["description"]["header"]["wf"];

            string data = xn.InnerText;
            data = data.Replace("○", "");
            data = data.Replace("<br />", "");


            return data;
        }
    }
}
