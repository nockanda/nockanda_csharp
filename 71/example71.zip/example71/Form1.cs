﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example71
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool first_click = true;
        Point p1;
        Point p2;
        Pen p = Pens.Black;
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (first_click)
            {
                //처음 클릭한거
                //첫번째점
                p1 = e.Location;
                first_click = false;
            }
            else
            {
                //두번째 클릭한거
                p2 = e.Location;

                Graphics g = pictureBox1.CreateGraphics();
                g.DrawLine(p, p1, p2);

                double length =Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));

                g.DrawString("길이="+length.ToString(), DefaultFont, Brushes.Blue, p2);
                listBox1.Items.Add(length);
                g.Dispose();
                first_click = true;
            }
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            this.Text = e.Location.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            g.FillRectangle(Brushes.White, 0, 0, pictureBox1.Width, pictureBox1.Height);

            g.Dispose();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //검빨노파
            if(comboBox1.SelectedIndex == 0)
            {
                p = new Pen(Color.Black, p.Width);
            }
            else if(comboBox1.SelectedIndex == 1)
            {
                p = new Pen(Color.Red, p.Width);
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                p = new Pen(Color.Yellow, p.Width);
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                p = new Pen(Color.Blue, p.Width);
            }
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label1.Text = hScrollBar1.Value.ToString();
            p = new Pen(p.Color, hScrollBar1.Value);

        }
    }
}
