﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example133
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dictionary<string, int> dic1 = new Dictionary<string, int>();
            Dictionary<string, int> dic2 = new Dictionary<string, int>();

            string text1 = richTextBox1.Text;
            string text2 = richTextBox2.Text;

            text1 = Regex.Replace(text1, @"[^a-zA-Z0-9가-힣]", " ", RegexOptions.Singleline);
            text2 = Regex.Replace(text2, @"[^a-zA-Z0-9가-힣]", " ", RegexOptions.Singleline);

            //richTextBox1.Text = text1;
            string[] words1 = text1.Split(" ");

            for(int i = 0; i < words1.Length; i++)
            {
                if(words1[i] != "")
                {
                    if (dic1.ContainsKey(words1[i]))
                    {
                        //i번쨰 단어가 사전에 있냐없냐?
                        //있는경우
                        dic1[words1[i]]++;
                    }
                    else
                    {
                        //없는경우
                        dic1.Add(words1[i], 1);
                    }

                }
            }
            string[] words2 = text2.Split(" ");
            for (int i = 0; i < words2.Length; i++)
            {
                if (words2[i] != "")
                {
                    if (dic2.ContainsKey(words2[i]))
                    {
                        //i번쨰 단어가 사전에 있냐없냐?
                        //있는경우
                        dic2[words2[i]]++;
                    }
                    else
                    {
                        //없는경우
                        dic2.Add(words2[i], 1);
                    }

                }
            }

            //중복된 word가 총 몇개인가?
            int count = 0;
            foreach (KeyValuePair<string, int> kvp in dic2)
            {
                //kvp.Key
                //kvp.Value
                if (dic1.ContainsKey(kvp.Key))
                {
                    //딕셔너리2의 단어가 딕셔너리1과 중복이다!
                    count += kvp.Value + dic1[kvp.Key];
                }
            }


            //richTextBox1.Text = "\n";
            int text1_count = 0;
            foreach (KeyValuePair<string, int> kvp in dic1)
            {
                text1_count += kvp.Value;
                //richTextBox1.Text += kvp.Key + "\t" + kvp.Value + "\n";
            }

            int text2_count = 0;
            foreach (KeyValuePair<string, int> kvp in dic2)
            {
                text2_count += kvp.Value;
                //richTextBox1.Text += kvp.Key + "\t" + kvp.Value + "\n";
            }
            //richTextBox1.Text = count + "/" + text1_count + "/" + text2_count;
            label1.Text = "일치도 = " + ((double)count / (text1_count + text2_count) * 100.0).ToString() + "%";
        }
    }
}
