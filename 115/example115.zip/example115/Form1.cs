﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example115
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string your_key = textBox1.Text;

            string query = "http://swopenAPI.seoul.go.kr/api/subway/"+ your_key + "/xml/realtimeStationArrival/0/100/"+textBox2.Text;

            WebRequest wr = WebRequest.Create(query);
            wr.Method = "GET";

            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            //richTextBox1.Text = response;

            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["realtimeStationArrival"];

            listView1.Items.Clear();
            listView2.Items.Clear();
            for(int i = 1; i < xn.ChildNodes.Count; i++)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = xn.ChildNodes[i]["subwayId"].InnerText;
                lvi.SubItems.Add(xn.ChildNodes[i]["updnLine"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["trainLineNm"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["subwayHeading"].InnerText);
                //lvi.SubItems.Add(xn.ChildNodes[i]["statnFid"].InnerText);
                //lvi.SubItems.Add(xn.ChildNodes[i]["statnTid"].InnerText);
                //lvi.SubItems.Add(xn.ChildNodes[i]["statnId"].InnerText);

                //lvi.SubItems.Add(xn.ChildNodes[i]["statnNm"].InnerText);

                //lvi.SubItems.Add(xn.ChildNodes[i]["ordkey"].InnerText);
                //lvi.SubItems.Add(xn.ChildNodes[i]["subwayList"].InnerText);
                //lvi.SubItems.Add(xn.ChildNodes[i]["statnList"].InnerText);

                int barvlDt = int.Parse(xn.ChildNodes[i]["barvlDt"].InnerText);

                lvi.SubItems.Add(xn.ChildNodes[i]["barvlDt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["btrainNo"].InnerText);
                //lvi.SubItems.Add(xn.ChildNodes[i]["bstatnId"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["bstatnNm"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["recptnDt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["arvlMsg2"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["arvlMsg3"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["arvlCd"].InnerText);


                if (barvlDt >= 180)
                {
                    listView1.Items.Add(lvi);
                }
                else
                {
                    listView2.Items.Add(lvi);
                }

                //richTextBox1.Text += xn.ChildNodes[i]["subwayId"].InnerText + "\n";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
    }
}
