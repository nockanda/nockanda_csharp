﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example41
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
                timer1.Start();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //토양센서(0) 2바이트
                //유속센서(1) 2바이트
                byte[] recv = new byte[3];
                serialPort1.Read(recv, 0, 3);
                int value = 0;
                if(recv[0] == 0)
                {
                    //토양센서의 값 0~1023
                    value = (recv[1] * 256) + recv[2];
                    if (value >= 0 && value <= 1023)
                    {
                        label1.Text = value.ToString();
                        progressBar1.Value = value;
                    }
                }
                else if(recv[0] == 1)
                {
                    //유속센서의 값
                    value = (recv[1] * 256) + recv[2];
                    
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = DateTime.Now.ToString();
                    lvi.SubItems.Add(value.ToString());

                    listView1.Items.Add(lvi);
                    
                  
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //워터펌프가 이송해야하는 물의양을 2바이트로 보내자
                //2바이트는 0~65000 정도 보낼 수 있다.
                //단위는 mL로 보내자
                //워터펌프 작동은 앞에 2 을 붙여서 보낸다
                int water = 100; //mL
                byte[] send = new byte[3];
                send[0] = 2; //워터펌프 작동 신호
                send[1] = (byte)(water / 256);
                send[2] = (byte)(water % 256);
                
                serialPort1.Write(send, 0, 3);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //토양센서값을 요청할때는
                //앞에 0을 보내면 끝!
                byte[] send = new byte[3];
                send[0] = 0; //토양센서값 요청 신호
                send[1] = 0;
                send[2] = 0;
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //워터펌프가 이송해야하는 물의양을 2바이트로 보내자
                //2바이트는 0~65000 정도 보낼 수 있다.
                //단위는 mL로 보내자
                //워터펌프 작동은 앞에 2 을 붙여서 보낸다
                int water = 200; //mL
                byte[] send = new byte[3];
                send[0] = 2; //워터펌프 작동 신호
                send[1] = (byte)(water / 256);
                send[2] = (byte)(water % 256);

                serialPort1.Write(send, 0, 3);
            }
        }
    }
}
