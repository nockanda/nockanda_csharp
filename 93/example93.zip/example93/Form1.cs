﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example93
{
    public partial class Form1 : Form
    {
        int x_pos = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");
            label2.Text = response + "ug/m3";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                //이미 타이머가 작동중이라면..
                //작동중인것을 일단 멈추고 시작한다..
                timer1.Stop();
            }
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");
            label2.Text = response + "ug/m3";

            //리스트뷰에 실시간 측정값을 저장하는 부분
            ListViewItem lvi = new ListViewItem();
            lvi.Text = DateTime.Now.ToString();
            lvi.SubItems.Add(response);

            listView1.Items.Add(lvi);

            //차트에 실시간값을 드로잉하는 부분
            chart1.Series[0].Points.AddXY(x_pos, float.Parse(response));
            

            if (chart1.Series[0].Points.Count > 10)
                chart1.Series[0].Points.RemoveAt(0);

            chart1.ChartAreas[0].AxisX.Maximum = x_pos;
            chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;

            chart1.ChartAreas[0].AxisY.Maximum = 500;

            x_pos++;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("./output.csv", FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);

            //파일에다가 기록한다!
            for(int i = 0; i < listView1.Items.Count; i++)
            {
                sw.WriteLine(listView1.Items[i].SubItems[0].Text + "," + listView1.Items[i].SubItems[1].Text);
            }

            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();
            MessageBox.Show("완료했습니다!");
        }
    }
}
