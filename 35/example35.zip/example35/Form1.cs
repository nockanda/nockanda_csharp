﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example35
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            total = new List<student>(); //제네릭코드(스포/내일할내용임)
            
        }

        List<student> total;
        private void button1_Click(object sender, EventArgs e)
        {
            student std = new student();
            std.name = textBox1.Text;
            std.age = int.Parse(textBox2.Text);
            if (radioButton1.Checked)
            {
                std.gender = 1;
            }
            else
            {
                std.gender = 2;
            }
            std.dongne = textBox3.Text;
            std.score1 = byte.Parse(textBox5.Text);
            std.score2 = byte.Parse(textBox4.Text);
            std.score3 = byte.Parse(textBox7.Text);
            std.score4 = byte.Parse(textBox6.Text);

            total.Add(std);

            richTextBox1.Text = "이름 : " + std.name + "\n";
            richTextBox1.Text += "나이 : " + std.age +"/" + std.is_misungyeunja()+ "\n";
            richTextBox1.Text += "성별 : " + std.convert_gender() + "\n";
            richTextBox1.Text += "사는동네 : " + std.dongne + "\n";
            richTextBox1.Text += "국어성적 : " + std.score1 + "\n";
            richTextBox1.Text += "수학성적 : " + std.score2 + "\n";
            richTextBox1.Text += "사회성적 : " + std.score3 + "\n";
            richTextBox1.Text += "과학성적 : " + std.score4 + "\n";
            richTextBox1.Text += "평균 : " + std.ave() + "\n";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            for(int i = 0; i < total.Count; i++)
            {
                richTextBox1.Text += (i + 1) + "번째 학생 정보\n";
                richTextBox1.Text += "이름 : " + total[i].name + "\n";
                richTextBox1.Text += "나이 : " + total[i].age + "/" + total[i].is_misungyeunja() + "\n";
                richTextBox1.Text += "성별 : " + total[i].convert_gender() + "\n";
                richTextBox1.Text += "사는동네 : " + total[i].dongne + "\n";
                richTextBox1.Text += "국어성적 : " + total[i].score1 + "\n";
                richTextBox1.Text += "수학성적 : " + total[i].score2 + "\n";
                richTextBox1.Text += "사회성적 : " + total[i].score3 + "\n";
                richTextBox1.Text += "과학성적 : " + total[i].score4 + "\n";
                richTextBox1.Text += "평균 : " + total[i].ave() + "\n";
            }
        }
    }
    class student
    {
        //멤버변수
        public string name;
        public int age;
        public byte gender;
        public string dongne;
        public byte score1; //국어성적
        public byte score2; //수학성적
        public byte score3; //사회성적
        public byte score4; //과학성적
        

        public string is_misungyeunja()
        {
            if (age < 20) return "미성년자임";
            else return "성인임";
        }
        public double ave()
        {
            return (score1 + score2 + score3 + score4) / 4;
        }
        public string convert_gender()
        {
            if (gender == 1) return "남자";
            else if (gender == 2) return "여자";
            else return "에러"; 
        }
    }
}
