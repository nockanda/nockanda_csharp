﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example43
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(textBox11.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox11.Text;
                serialPort1.Open();

                byte[] send = new byte[3];
                send[0] = 0;
                send[1] = 0;
                send[2] = 0;
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                send[0] = 1;
                send[1] = byte.Parse(textBox1.Text);
                send[2] = byte.Parse(textBox2.Text);

                serialPort1.Write(send, 0, 3);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] send = new byte[3];
            send[0] = 2;
            send[1] = byte.Parse(textBox4.Text);
            send[2] = byte.Parse(textBox3.Text);

            serialPort1.Write(send, 0, 3);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] send = new byte[3];
            send[0] = 3;
            send[1] = byte.Parse(textBox6.Text);
            send[2] = byte.Parse(textBox5.Text);

            serialPort1.Write(send, 0, 3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte[] send = new byte[3];
            send[0] = 4;
            send[1] = byte.Parse(textBox8.Text);
            send[2] = byte.Parse(textBox7.Text);

            serialPort1.Write(send, 0, 3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] send = new byte[3];
            send[0] = 5;
            send[1] = byte.Parse(textBox10.Text);
            send[2] = 0;

            serialPort1.Write(send, 0, 3);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] send = new byte[3];
            send[0] = 6;
            send[1] = byte.Parse(textBox9.Text);
            send[2] = 0;
            serialPort1.Write(send, 0, 3);
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[3];
                serialPort1.Read(recv, 0, 3);

                if(recv[0] == 1)
                {
                    //1번모터
                    //1이면 정방향 2이면 역방향
                    if (recv[2] == 1) label1.Text = "방향 : 정방향";
                    else label1.Text = "방향 : 역방향";
                    label2.Text = "파워 : " + recv[1].ToString();

                }
                else if (recv[0] == 2)
                {
                    //2번모터
                    if (recv[2] == 1) label4.Text = "방향 : 정방향";
                    else label4.Text = "방향 : 역방향";
                    label3.Text = "파워 : " + recv[1].ToString();
                }
                else if (recv[0] == 3)
                {
                    //3번모터
                    if (recv[2] == 1) label6.Text = "방향 : 정방향";
                    else label6.Text = "방향 : 역방향";
                    label5.Text = "파워 : " + recv[1].ToString();
                }
                else if (recv[0] == 4)
                {
                    //4번모터
                    if (recv[2] == 1) label8.Text = "방향 : 정방향";
                    else label8.Text = "방향 : 역방향";
                    label7.Text = "파워 : " + recv[1].ToString();
                }
                else if (recv[0] == 5)
                {
                    //1번서보
                    label10.Text = "각도 : " + recv[1].ToString();
                }
                else if (recv[0] == 6)
                {
                    //2번서보
                    label9.Text = "각도 : " + recv[1].ToString();
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
