﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NAudio.Wave;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Recorder recorder;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox2.Text = kakao_trans(richTextBox1.Text, comboBox1.SelectedItem.ToString());

        }
        //출처 https://pythonq.com/so/c%23/744845
        public class Recorder
        {

            WaveIn sourceStream;
            WaveFileWriter waveWriter;
            readonly String FilePath;
            readonly String FileName;
            readonly int InputDeviceIndex;

            public Recorder(int inputDeviceIndex, String filePath, String fileName)
            {
                this.InputDeviceIndex = inputDeviceIndex;
                this.FileName = fileName;
                this.FilePath = filePath;
            }

            public void StartRecording()
            {
                sourceStream = new WaveIn
                {
                    DeviceNumber = this.InputDeviceIndex,
                    WaveFormat =
                        new WaveFormat(16000, 1)
                };

                sourceStream.DataAvailable += this.SourceStreamDataAvailable;

                if (!Directory.Exists(FilePath))
                {
                    Directory.CreateDirectory(FilePath);
                }

                waveWriter = new WaveFileWriter(FilePath + FileName, sourceStream.WaveFormat);
                sourceStream.StartRecording();
            }

            public void SourceStreamDataAvailable(object sender, WaveInEventArgs e)
            {
                if (waveWriter == null) return;
                waveWriter.Write(e.Buffer, 0, e.BytesRecorded);
                waveWriter.Flush();
            }

            public void RecordEnd()
            {
                if (sourceStream != null)
                {
                    sourceStream.StopRecording();
                    sourceStream.Dispose();
                    sourceStream = null;
                }
                if (this.waveWriter == null)
                {
                    return;
                }
                this.waveWriter.Dispose();
                this.waveWriter = null;

            }
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            //레코딩 시작
            label6.Text = "음성녹음을 시작합니다!";
            recorder = new Recorder(0, "./voice/", "test.wave");
            recorder.StartRecording();
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            //레코딩 종료
            label6.Text = "음성녹음을 종료합니다!";
            recorder.RecordEnd();

            //OPENAPI
            string url = "https://kakaoi-newtone-openapi.kakao.com/v1/recognize";


            string your_key = textBox1.Text;

            WebRequest wr = WebRequest.Create(url);
            wr.Method = "POST";
            wr.ContentType = "application/octet-stream";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);

            FileStream fs = new FileStream("./voice/test.wave", FileMode.Open);

            Stream s1 = wr.GetRequestStream();

            fs.CopyTo(s1);

            fs.Close();
            fs.Dispose();
            s1.Close();

            ///response
            WebResponse wrs = wr.GetResponse();
            Stream s2 = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s2);

            string response = sr.ReadToEnd();

            string start = "\"finalResult\",\"value\":\"";
            string end = "\",\"nBest\":[{";

            int ss1 = response.IndexOf(start) + start.Length;
            int ee1 = response.IndexOf(end);

            string text = response.Substring(ss1, ee1 - ss1);
            richTextBox3.Text = text;

            //번역작업을 시작
            string output = kakao_trans(text, comboBox2.SelectedItem.ToString());
            richTextBox4.Text = output;
        }
        
        string kakao_trans(string input,string code)
        {
            string url = "https://dapi.kakao.com/v2/translation/translate?src_lang=kr&target_lang=" + code + "&query=" + input;
            string your_key = textBox1.Text;


            WebRequest wr = WebRequest.Create(url);
            wr.Method = "GET";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);

            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();
            sr.Close();
            s.Close();

            JObject jo = JObject.Parse(response);
            JToken jt = jo["translated_text"];

            string output = "";
            for (int i = 0; i < jt.Count(); i++)
            {
                output += jt[i][0].ToString() + " ";
            }

            return output;
        }
    }
}
