﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example89
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = hScrollBar1.Value.ToString();
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar2.Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/fnd1/"+hScrollBar1.Value.ToString());
            MessageBox.Show(response);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/fnd2/" + hScrollBar2.Value.ToString());
            MessageBox.Show(response);
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            label4.Text = hScrollBar3.Value.ToString();
        }

        private void hScrollBar4_Scroll(object sender, ScrollEventArgs e)
        {
            label5.Text = hScrollBar4.Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("fnd1", hScrollBar3.Value.ToString());
            nvc.Add("fnd2", hScrollBar4.Value.ToString());

            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

    }
}
