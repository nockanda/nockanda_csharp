﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example44
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[6];
                serialPort1.Read(recv, 0, 6);
                //0 1 온도
                //2 3 습도
                //4 5 먼지
                double t = ((recv[0] * 256) + recv[1])/100.0;
                double h = ((recv[2] * 256) + recv[3])/100.0;
                double m = ((recv[4] * 256) + recv[5])/100.0;
                label4.Text = t.ToString();
                label5.Text = h.ToString();
                label6.Text = m.ToString();

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(t.ToString());
                lvi.SubItems.Add(h.ToString());
                lvi.SubItems.Add(m.ToString());

                listView1.Items.Add(lvi);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) serialPort1.Close();

            FileStream fs = new FileStream("output.csv", FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fs);

            for(int i = 0; i < listView1.Items.Count; i++)
            {
                //lv.Items[i].SubItems
                for(int j = 0;j< listView1.Items[i].SubItems.Count; j++)
                {
                    sw.Write(listView1.Items[i].SubItems[j].Text);
                    if(j != listView1.Items[i].SubItems.Count-1) sw.Write(",");
                }
                sw.WriteLine();
            }

            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();
            MessageBox.Show("파일 출력 완료!");
        }
    }
}
