﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string output = "";
            /* 체크드리스트박스를 안쓸경우(불편)
            if (checkBox1.Checked)
            {
                output += checkBox1.Text + "\n";
            }
            if (checkBox2.Checked)
            {
                output += checkBox2.Text + "\n";
            }
            if (checkBox3.Checked)
            {
                output += checkBox3.Text + "\n";
            }
            if (checkBox4.Checked)
            {
                output += checkBox4.Text + "\n";
            }
            */
            //체크드리스트박스의 전체 항목을 불러옴
            //for(int i = 0; i < checkedListBox1.Items.Count; i++)
            //{
            //    output += checkedListBox1.Items[i].ToString() + "\n";
            //}

            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
            {
                output += checkedListBox1.CheckedItems[i].ToString() + "\n";
            }
            richTextBox1.Text = output;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //체크드리스트박스 아이템추가
            checkedListBox1.Items.Add(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //체크드리스트박스 아이템삭제
            checkedListBox1.Items.Remove(checkedListBox1.SelectedItem);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //콤보박스에 이벤트를 이용한 방법
            //richTextBox1.Text = comboBox1.SelectedItem.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                richTextBox1.Text = comboBox1.SelectedItem.ToString();
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //콤보박스에 아이템 추가
            comboBox1.Items.Add(textBox2.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                comboBox1.Items.Remove(comboBox1.SelectedItem);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = numericUpDown1.Value.ToString();
        }
    }
}
