﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example70
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Pen p = new Pen(Color.Red);
            
            Point p1 = new Point(10, 10);
            Point p2 = new Point(200, 200);
            //g.DrawLine(p, p1, p2);
            g.DrawLine(Pens.Red, p1, p2);

            g.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Pen p = new Pen(Color.Red, 10);

            Point p1 = new Point(10, 10);
            Point p2 = new Point(200, 200);
            g.DrawLine(p, p1, p2);

            g.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen p = new Pen(Color.Red);

            //g.DrawRectangle(p, 10, 10, 100, 100);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            g.DrawRectangle(p, r);

            g.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            SolidBrush sb = new SolidBrush(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            //g.FillRectangle(sb, r);
            g.FillRectangle(Brushes.Red, r);
            g.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            SolidBrush sb = new SolidBrush(SystemColors.Control);
            g.FillRectangle(sb, 0, 0, pictureBox1.Width, pictureBox1.Height);
            g.Dispose();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen p = new Pen(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            g.DrawEllipse(p, r);
            g.Dispose();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            SolidBrush sb = new SolidBrush(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            g.FillEllipse(sb, r);
            g.Dispose();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen p = new Pen(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            g.DrawPie(p, r, 0, -180);
            g.Dispose();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            SolidBrush sb = new SolidBrush(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            g.FillPie(sb, r, 0, -180);
            g.Dispose();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen p = new Pen(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            g.DrawArc(p, r, 0, -180);
            g.Dispose();
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            SolidBrush sb = new SolidBrush(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            Point[] mypoint =
            {
                new Point(100,100),
                new Point(150,60),
                new Point(130,10),
                new Point(80,10),
                new Point(50,60)
            };
            g.FillPolygon(sb, mypoint);
            g.Dispose();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen p = new Pen(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            Point[] mypoint =
            {
                new Point(100,100),
                new Point(150,60),
                new Point(130,10),
                new Point(80,10),
                new Point(50,60)
            };
            g.DrawPolygon(p, mypoint);
            g.Dispose();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Bitmap bt = new Bitmap("./img.jpg");
            Graphics g = Graphics.FromImage(bt);
            SolidBrush sb = new SolidBrush(Color.Red);
            Rectangle r = new Rectangle(10, 10, 100, 100);
            //g.FillRectangle(sb, r);
            g.FillRectangle(Brushes.Red, r);
            g.Dispose();

            pictureBox1.Image = bt;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Bitmap bt = new Bitmap("./img.jpg");
            //g.DrawImage(bt, 0, 0);
            Rectangle r = new Rectangle(0, 0, 320, 240);
            g.DrawImage(bt, r);
            g.Dispose();
        }
    }
}
