﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenCvSharp;

namespace example78
{
    public partial class Form1 : Form
    {
        //timer1 : 영상스트링용(CAM1)
        //timer2 : 영상다시보기용

        //opencv 비디오캡쳐 클래스
        VideoCapture vc = new VideoCapture(); //cam1스트리밍용
        VideoWriter vw = new VideoWriter();

        VideoCapture play_vc = new VideoCapture(); //다시보기용

        //카메라를 로드할때 사용할 스레드!
        Thread camera_load_thread;

        //카메라1번의 스레드
        Thread cam1_thread;
        DateTime cam1_timer;


        public Form1()
        {
            InitializeComponent();
        }

        private void camera_load()
        {
            vc = new VideoCapture();
            //rtsp주소
            //string rtsp_path = "rtsp://192.168.0.15:8554/mjpeg/1";
            string rtsp_path = "rtsp://" + textBox1.Text + ":8554/mjpeg/1"; //rtsp주소
            //스트리밍시작버튼을 눌렀을떄~
            //지정된 rstp주소로 접속을 시도!
            vc.Open(rtsp_path); //접속이 완료될때까지 일정 시간이 소요 
            if (vc.IsOpened())
            {
                //MessageBox.Show("성공!");
                cam1_thread.Start();
                //저정할 파일명을 지정하고
                //영상을 녹화할 수있는 스레드를 작동시킨다!
                DateTime dt = DateTime.Now;
                cam1_timer = DateTime.Now;
                string file_name = dt.Year + "_" + dt.Month + "_" + dt.Day + "_" + dt.Hour + "_" + dt.Minute + "_" + dt.Second + "_cam1.mp4";
                string file_path = "./CCTV/" + file_name;
                vw.Open(file_path, FourCC.DIVX, 10, new OpenCvSharp.Size(vc.FrameWidth, vc.FrameHeight));
            }
            else
            {
                //MessageBox.Show("실패!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //rtsp주소
            //string rtsp_path = "rtsp://192.168.0.15:8554/mjpeg/1";
            string rtsp_path = textBox1.Text; //rtsp주소
            //스트리밍시작버튼을 눌렀을떄~
            //지정된 rstp주소로 접속을 시도!
            vc.Open(rtsp_path);

            //캡쳐버튼을 눌렀을떄~
            //스틸이미지를 저장할 공간을 만든다
            Mat image = new Mat();
            //스틸이미지 한장을 읽어온다
            vc.Read(image);

            //읽어온 이미지를 픽쳐박스에 드로잉한다
            pictureBoxIpl1.ImageIpl = image;

            vc.Release();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] files = Directory.GetFiles("./CCTV");
            
            for(int i = 0; i < files.Length; i++)
            {
                ListViewItem lvi = new ListViewItem();
                if(files[i].IndexOf("cam1") != -1)
                {
                    //파일명에 cam1이라는 패턴이 존재한다!
                    lvi.Text = "CAM1";
                }
                lvi.SubItems.Add(files[i]);
                listView1.Items.Add(lvi);
            }

            //cam1_thread = new Thread(new ThreadStart(cam1));
        }
        
        

        private void button2_Click(object sender, EventArgs e)
        {
            
            
            vc = new VideoCapture();
            //rtsp주소
            //string rtsp_path = "rtsp://192.168.0.15:8554/mjpeg/1";
            string rtsp_path = "rtsp://" + textBox1.Text + ":8554/mjpeg/1"; //rtsp주소
            //스트리밍시작버튼을 눌렀을떄~
            //지정된 rstp주소로 접속을 시도!
            vc.Open(rtsp_path); //접속이 완료될때까지 일정 시간이 소요
        
            //접속이 잘되었느냐?
            if (vc.IsOpened())
            {
                //접속이 잘된경우!
                //타이머가 멈춰있으면...
                if (timer1.Enabled == false)
                {
                    //작동시키겠다..!
                    timer1.Start();
                }
            }
            else
            {
                //접속에 실패한경우!
                MessageBox.Show("접속에 실패했습니다!");
            }
            
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                timer1.Stop();
                //cam1_thread.Abort();
                vw.Release();
                vc.Release();
                vc.Dispose();
            }
            
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
            //스틸이미지를 저장할 공간을 만든다
            Mat image = new Mat();
            //스틸이미지 한장을 읽어온다
            if (vc.Read(image))
            {
                //만약에 동영상파일을 녹화한 시간이 20초가 경과했다면..
                //새로운 파일로 다시 저장하겠다!
                if ((DateTime.Now - cam1_timer).TotalMilliseconds > 10000)
                {
                    cam1_timer = DateTime.Now;

                    //이전에 기록하고 있던 파일을 list view에 추가하겠다!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = "CAM1";
                    lvi.SubItems.Add(vw.FileName);
                    listView1.Items.Add(lvi);

                    //20초가 경과되었다!
                    //새로운 파일로 만들어서 새로 녹화를 시작해야겠다!
                    vw.Release(); //녹화중지!
                    string file_name = cam1_timer.Year + "_" + cam1_timer.Month + "_" + cam1_timer.Day + "_" + cam1_timer.Hour + "_" + cam1_timer.Minute + "_" + cam1_timer.Second + "_cam1.mp4";
                    string file_path = "./CCTV/" + file_name;
                    vw.Open(file_path, FourCC.DIVX, 10, new OpenCvSharp.Size(vc.FrameWidth, vc.FrameHeight));
                    vw.Write(image);
                }
                else
                {
                    vw.Write(image);
                }
                //vc.FrameCount
                //vc.FrameHeight
                //vc.FrameWidth
                label1.Text = "너비 : " + vc.FrameWidth.ToString();
                label2.Text = "높이 : " + vc.FrameHeight.ToString();

                //읽어온 이미지를 픽쳐박스에 드로잉한다
                pictureBoxIpl1.ImageIpl = image;

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //카메라세팅가져오기 버튼을 눌렀다!
            WebClient wc = new WebClient();
            string response = wc.UploadString("http://"+textBox1.Text+"/camget", "HELLO");

            //데이터간은 슬러시로 구분
            //키밸류는 콜론으로 구분
            string[] datas = response.Split('/');

            for (int i = 0; i < datas.Length; i++)
            {
                string[] key_value = datas[i].Split(':');

                if(key_value[0] == "framesize")
                {
                    if (key_value[1] == "3")
                    {
                        radioButton1.Checked = true;
                    }
                    if (key_value[1] == "7")
                    {
                        radioButton2.Checked = true;
                    }
                }

                if (key_value[0] == "quality")
                {
                    label3.Text = key_value[1];
                    hScrollBar1.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "brightness")
                {
                    label4.Text = key_value[1];
                    hScrollBar2.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "contrast")
                {
                    label5.Text = key_value[1];
                    hScrollBar3.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "saturation")
                {
                    label6.Text = key_value[1];
                    hScrollBar4.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "special_effect")
                {
                    label7.Text = key_value[1];
                    hScrollBar5.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "wb_mode")
                {
                    label8.Text = key_value[1];
                    hScrollBar6.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "ae_level")
                {
                    label9.Text = key_value[1];
                    hScrollBar7.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "agc_gain")
                {
                    label10.Text = key_value[1];
                    hScrollBar8.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "aec_value")
                {
                    label11.Text = key_value[1];
                    hScrollBar9.Value = int.Parse(key_value[1]);
                }
                if (key_value[0] == "set_gainceiling")
                {
                    label12.Text = key_value[1];
                    hScrollBar10.Value = int.Parse(key_value[1]);
                }

                if (key_value[0] == "awb_gain")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton4.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton3.Checked = true;
                    }
                }
                if (key_value[0] == "aec2")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton6.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton5.Checked = true;
                    }
                }
                if (key_value[0] == "bpc")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton8.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton7.Checked = true;
                    }
                }

                if (key_value[0] == "wpc")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton10.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton9.Checked = true;
                    }
                }

                if (key_value[0] == "raw_gma")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton12.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton11.Checked = true;
                    }
                }

                if (key_value[0] == "lenc")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton14.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton13.Checked = true;
                    }
                }
                if (key_value[0] == "hmirror")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton16.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton15.Checked = true;
                    }
                }
                if (key_value[0] == "vflip")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton18.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton17.Checked = true;
                    }
                }
                if (key_value[0] == "dcw")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton20.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton19.Checked = true;
                    }
                }
                if (key_value[0] == "colorbar")
                {
                    if (key_value[1] == "0")
                    {
                        radioButton22.Checked = true;
                    }
                    if (key_value[1] == "1")
                    {
                        radioButton21.Checked = true;
                    }
                }
            }
            
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar1.Value.ToString();
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label4.Text = hScrollBar2.Value.ToString();
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            label5.Text = hScrollBar3.Value.ToString();
        }

        private void hScrollBar4_Scroll(object sender, ScrollEventArgs e)
        {
            label6.Text = hScrollBar4.Value.ToString();
        }

        private void hScrollBar5_Scroll(object sender, ScrollEventArgs e)
        {
            label7.Text = hScrollBar5.Value.ToString();
        }

        private void hScrollBar6_Scroll(object sender, ScrollEventArgs e)
        {
            label8.Text = hScrollBar6.Value.ToString();
        }

        private void hScrollBar7_Scroll(object sender, ScrollEventArgs e)
        {
            label9.Text = hScrollBar7.Value.ToString();
        }

        private void hScrollBar8_Scroll(object sender, ScrollEventArgs e)
        {
            label10.Text = hScrollBar8.Value.ToString();
        }

        private void hScrollBar9_Scroll(object sender, ScrollEventArgs e)
        {
            label11.Text = hScrollBar9.Value.ToString();
        }

        private void hScrollBar10_Scroll(object sender, ScrollEventArgs e)
        {
            label12.Text = hScrollBar10.Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //카메라세팅보내기버튼을 눌렀다!
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            if (radioButton1.Checked)
            {
                nvc.Add("framesize", "3");
            }
            else if (radioButton2.Checked)
            {
                nvc.Add("framesize", "7");
            }
           
            nvc.Add("quality", hScrollBar1.Value.ToString());
            nvc.Add("brightness", hScrollBar2.Value.ToString());
            nvc.Add("contrast", hScrollBar3.Value.ToString());
            nvc.Add("saturation", hScrollBar4.Value.ToString());
            nvc.Add("special_effect", hScrollBar5.Value.ToString());

            if (radioButton4.Checked)
            {
                nvc.Add("awb_gain", "0");
            }
            else if (radioButton3.Checked)
            {
                nvc.Add("awb_gain", "1");
            }
            
            nvc.Add("wb_mode", hScrollBar6.Value.ToString());

            if (radioButton6.Checked)
            {
                nvc.Add("aec2", "0");
            }
            else if (radioButton5.Checked)
            {
                nvc.Add("aec2", "1");
            }
            nvc.Add("ae_level", hScrollBar7.Value.ToString());
            nvc.Add("aec_value", hScrollBar9.Value.ToString());
            nvc.Add("agc_gain", hScrollBar8.Value.ToString());
            nvc.Add("gainceiling", hScrollBar10.Value.ToString());
            if (radioButton8.Checked)
            {
                nvc.Add("bpc", "0");
            }
            else if (radioButton7.Checked)
            {
                nvc.Add("bpc", "1");
            }
            if (radioButton10.Checked)
            {
                nvc.Add("wpc", "1");
            }
            else if (radioButton9.Checked)
            {
                nvc.Add("wpc", "1");
            }
            if (radioButton12.Checked)
            {
                nvc.Add("raw_gma", "0");
            }
            else if (radioButton11.Checked)
            {
                nvc.Add("raw_gma", "1");
            }
            if (radioButton14.Checked)
            {
                nvc.Add("lenc", "1");
            }
            else if (radioButton13.Checked)
            {
                nvc.Add("lenc", "1");
            }
            if (radioButton16.Checked)
            {
                nvc.Add("hmirror", "0");
            }
            else if (radioButton15.Checked)
            {
                nvc.Add("hmirror", "1");
            }
            if (radioButton18.Checked)
            {
                nvc.Add("vflip", "0");
            }
            else if (radioButton17.Checked)
            {
                nvc.Add("vflip", "1");
            }
            if (radioButton20.Checked)
            {
                nvc.Add("dcw", "0");
            }
            else if (radioButton19.Checked)
            {
                nvc.Add("dcw", "1");
            }
            if (radioButton22.Checked)
            {
                nvc.Add("colorbar", "0");
            }
            else if (radioButton21.Checked)
            {
                nvc.Add("colorbar", "1");
            }

            button5.BackColor = Color.Red;
            byte[] response = wc.UploadValues("http://" + textBox1.Text + "/camset", nvc);

            if(response[0] == 'O' && response[1] == 'K')
            {
                button5.BackColor = SystemColors.Control;
            }
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count == 1)
            {
                //만약 스트리밍이 진행중이었다면..
                //강제로 종료해버리겠다!
                if(timer1.Enabled == true)
                {
                    timer1.Stop();
                    vc.Release();
                    vw.Release();
                }

                //play_thread
                //play_vc
                play_vc.Open(listView1.SelectedItems[0].SubItems[1].Text);
                if (play_vc.IsOpened())
                {
                    trackBar1.Maximum = play_vc.FrameCount-1;
                    trackBar1.Value = 0;
                    //richTextBox1.Text += "전체프레임수;"+play_vc.FrameCount + "\n";
                    //richTextBox1.Text += "이미지 폭:" + play_vc.FrameWidth + "\n";
                    //richTextBox1.Text += "이미지 높이:" + play_vc.FrameHeight;

                    //timer2를 작동시키겠다!
                    if(timer2.Enabled == true)
                    {
                        timer2.Stop();
                    }
                    timer2.Start();
                }

            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            play_vc.PosFrames = trackBar1.Value;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Mat image = new Mat();
            if (play_vc.Read(image) && play_vc.PosFrames < play_vc.FrameCount)
            {
                pictureBoxIpl1.ImageIpl = image;
                trackBar1.Value = play_vc.PosFrames;
            }
            else
            {
                timer2.Stop();
                play_vc.Release();
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (timer2.Enabled == true)
            {
                timer2.Stop();
                play_vc.Release();
            }
        }
    }
}
