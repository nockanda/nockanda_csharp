﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example119
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example119;Uid=root;Pwd=qwer1234;";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                MessageBox.Show("PORT번호를 입력해주세요!");
            }
            else
            {
                serialPort1.PortName = textBox1.Text;
                if(serialPort1.IsOpen == false)
                {
                    serialPort1.Open();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen == true)
            {
                serialPort1.Close();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string data = serialPort1.ReadLine();
            DateTime dt = DateTime.Now;
            string date = dt.ToString() + ".";

            if(dt.Millisecond.ToString().Length < 3)
            {
                date = date + "0" + dt.Millisecond;
            }
            else
            {
                date = date + dt.Millisecond;
            }

            label2.Text = "Data : " + data;

            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into example119_1(data,date) values("+ data + ",'"+ date + "')", conn);
                msc.ExecuteNonQuery();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from example119_1 order by date desc limit 30";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "example119_1");

                
                listView1.Items.Clear();
                chart1.Series[0].Points.Clear();

                for(int i = 0;i< ds.Tables[0].Rows.Count; i++)
                {
                    //리스트뷰에 데이터를 집어넣는 부분
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ds.Tables[0].Rows[i]["num"].ToString();

                    string data = ds.Tables[0].Rows[i]["data"].ToString();

                    lvi.SubItems.Add(data);
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["date"].ToString());

                    listView1.Items.Add(lvi);

                    //그래프를 그리부분
                    chart1.Series[0].Points.AddXY(i, int.Parse(data));
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(listView1.Items.Count > 0)
            {
                string path = "./output.csv";
                FileStream fs = new FileStream(path, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);

                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    //listView1.Items[i].SubItems[0].Text
                    //listView1.Items[i].SubItems[1].Text
                    //listView1.Items[i].SubItems[2].Text
                    sw.WriteLine(listView1.Items[i].SubItems[0].Text+","+ listView1.Items[i].SubItems[1].Text+","+ listView1.Items[i].SubItems[2].Text);
                }
                

                sw.Close();
                sw.Dispose();
                fs.Close();
                fs.Dispose();
            }
        }
    }
}
