﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenCvSharp;

namespace example78
{
    public partial class Form1 : Form
    {
        //일단! 카메라는 최대 2개라는 제약조건을 둔다!
        //timer1 : 영상스트링용(CAM1)
        //timer2 : 영상다시보기용
        //timer3 : 영상스트링용(CAM2)
        const int camera_count = 2;

        System.Windows.Forms.Timer[] cam_timer = new System.Windows.Forms.Timer[camera_count];



        //opencv 비디오캡쳐 클래스
        VideoCapture[] vc = new VideoCapture[camera_count]; //cam스트리밍용

        VideoWriter[] vw = new VideoWriter[camera_count];

        Mat[] image = new Mat[2];

        VideoCapture play_vc = new VideoCapture(); //다시보기용

        //카메라를 로드할때 사용할 스레드!
        Thread camera_load_thread;

        //카메라타이머
        DateTime[] cam_watch = new DateTime[camera_count];


        public Form1()
        {
            InitializeComponent();
        }

        private void camera_load()
        {
            //vc = new VideoCapture();
            //vc2 = new VideoCapture();
            //rtsp주소
            //string rtsp_path = "rtsp://192.168.0.15:8554/mjpeg/1";

            for (int i = 0; i < listView2.Items.Count; i++)
            {
                vc[i] = new VideoCapture();
                vw[i] = new VideoWriter();
                string rtsp_path = "rtsp://" + listView2.Items[i].SubItems[0].Text + ":8554/mjpeg/1"; //rtsp주소

                //richTextBox1.Text += rtsp_path + "\n";
                //스트리밍시작버튼을 눌렀을떄~
                //지정된 rstp주소로 접속을 시도!

                vc[i].Open(rtsp_path); //접속이 완료될때까지 일정 시간이 소요

                if (vc[i].IsOpened())
                {
                    //리스트뷰에 접속상황을 업데이트한다!
                    listView2.Items[i].SubItems[1].Text = "YES!";
                    //richTextBox1.Text += (i+1).ToString()+"YES!";
                }
                else
                {
                    listView2.Items[i].SubItems[1].Text = "NO!";
                    //richTextBox1.Text += (i + 1).ToString()+"NO!";
                }

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //rtsp주소
            //string rtsp_path = "rtsp://192.168.0.15:8554/mjpeg/1";
            string rtsp_path = textBox1.Text; //rtsp주소
            //스트리밍시작버튼을 눌렀을떄~
            //지정된 rstp주소로 접속을 시도!
            vc[0].Open(rtsp_path);

            //캡쳐버튼을 눌렀을떄~
            //스틸이미지를 저장할 공간을 만든다
            Mat image = new Mat();
            //스틸이미지 한장을 읽어온다
            vc[0].Read(image);

            //읽어온 이미지를 픽쳐박스에 드로잉한다
            pictureBoxIpl1.ImageIpl = image;

            vc[0].Release();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] files = Directory.GetFiles("./CCTV");

            for (int i = 0; i < files.Length; i++)
            {
                ListViewItem lvi = new ListViewItem();
                if (files[i].IndexOf("cam1") != -1)
                {
                    //파일명에 cam1이라는 패턴이 존재한다!
                    lvi.Text = "CAM1";
                }
                lvi.SubItems.Add(files[i]);
                listView1.Items.Add(lvi);
            }


            cam_timer[0] = timer1;
            cam_timer[1] = timer3;
            //cam1_thread = new Thread(new ThreadStart(cam1));
        }



        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView2.Items.Count; i++)
            {

                //접속이 잘되었느냐?
                if (vc[i].IsOpened())
                {
                    //접속이 잘된경우!
                    //타이머가 멈춰있으면...
                    if (cam_timer[i].Enabled == false)
                    {
                        //작동시키겠다..!
                        cam_timer[i].Start();
                        cam_watch[i] = DateTime.Now;
                    }
                }
                else
                {
                    //접속에 실패한경우!
                    //MessageBox.Show("접속에 실패했습니다!");

                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView2.Items.Count; i++)
            {
                if (cam_timer[i].Enabled == true)
                {
                    cam_timer[i].Stop();
                    //cam1_thread.Abort();
                    vw[i].Release();
                    //vc[i].Release();
                }
            }

        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            int camera_id = 0;
            //스틸이미지를 저장할 공간을 만든다
            image[camera_id] = new Mat();
            //스틸이미지 한장을 읽어온다
            if (vc[camera_id].Read(image[camera_id]))
            {

                //만약에 동영상파일을 녹화한 시간이 20초가 경과했다면..
                //새로운 파일로 다시 저장하겠다!
                if ((DateTime.Now - cam_watch[camera_id]).TotalMilliseconds > 10000)
                {
                    cam_watch[camera_id] = DateTime.Now;

                    //이전에 기록하고 있던 파일을 list view에 추가하겠다!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = "CAM" + (camera_id + 1).ToString();
                    lvi.SubItems.Add(vw[camera_id].FileName);
                    listView1.Items.Add(lvi);

                    //20초가 경과되었다!
                    //새로운 파일로 만들어서 새로 녹화를 시작해야겠다!
                    vw[camera_id].Release(); //녹화중지!
                    string file_name = cam_watch[camera_id].Year + "_" + cam_watch[camera_id].Month + "_" + cam_watch[camera_id].Day + "_" + cam_watch[camera_id].Hour + "_" + cam_watch[camera_id].Minute + "_" + cam_watch[camera_id].Second + "_cam" + (camera_id + 1) + ".mp4";
                    string file_path = "./CCTV/" + file_name;
                    vw[camera_id].Open(file_path, FourCC.DIVX, 10, new OpenCvSharp.Size(vc[camera_id].FrameWidth, vc[camera_id].FrameHeight));
                    vw[camera_id].Write(image[camera_id]);
                }
                else
                {
                    vw[camera_id].Write(image[camera_id]);
                }
                //vc.FrameCount
                //vc.FrameHeight
                //vc.FrameWidth
                //label1.Text = "너비 : " + vc[0].FrameWidth.ToString();
                //label2.Text = "높이 : " + vc[0].FrameHeight.ToString();

                //읽어온 이미지를 픽쳐박스에 드로잉한다

                if (listView2.SelectedItems.Count == 1)
                {
                    if (listView2.SelectedIndices[0] == camera_id)
                    {
                        if (radioButton23.Checked)
                        {
                            //1채널모드
                            pictureBoxIpl1.ImageIpl = image[camera_id];
                        }
                        else if (radioButton24.Checked)
                        {
                            //2채널모드
                            //image[0] image[1]
                            Mat output = new Mat();
                            int w = image[0].Width;
                            int h = image[0].Height;

                            OpenCvSharp.Size s = new OpenCvSharp.Size(2 * w, h);
                            Mat dummy = new Mat(s, image[0].Type());

                            Cv2.HConcat(image[0], image[1], output);
                            Cv2.VConcat(output, dummy, output);
                            pictureBoxIpl1.ImageIpl = output;
                        }
                    }
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                //카메라세팅가져오기 버튼을 눌렀다!
                WebClient wc = new WebClient();
                string response = wc.UploadString("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/camget", "HELLO");

                //데이터간은 슬러시로 구분
                //키밸류는 콜론으로 구분
                string[] datas = response.Split('/');

                for (int i = 0; i < datas.Length; i++)
                {
                    string[] key_value = datas[i].Split(':');

                    if (key_value[0] == "framesize")
                    {
                        if (key_value[1] == "3")
                        {
                            radioButton1.Checked = true;
                        }
                        if (key_value[1] == "7")
                        {
                            radioButton2.Checked = true;
                        }
                    }

                    if (key_value[0] == "quality")
                    {
                        label3.Text = key_value[1];
                        hScrollBar1.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "brightness")
                    {
                        label4.Text = key_value[1];
                        hScrollBar2.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "contrast")
                    {
                        label5.Text = key_value[1];
                        hScrollBar3.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "saturation")
                    {
                        label6.Text = key_value[1];
                        hScrollBar4.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "special_effect")
                    {
                        label7.Text = key_value[1];
                        hScrollBar5.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "wb_mode")
                    {
                        label8.Text = key_value[1];
                        hScrollBar6.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "ae_level")
                    {
                        label9.Text = key_value[1];
                        hScrollBar7.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "agc_gain")
                    {
                        label10.Text = key_value[1];
                        hScrollBar8.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "aec_value")
                    {
                        label11.Text = key_value[1];
                        hScrollBar9.Value = int.Parse(key_value[1]);
                    }
                    if (key_value[0] == "set_gainceiling")
                    {
                        label12.Text = key_value[1];
                        hScrollBar10.Value = int.Parse(key_value[1]);
                    }

                    if (key_value[0] == "awb_gain")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton4.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton3.Checked = true;
                        }
                    }
                    if (key_value[0] == "aec2")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton6.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton5.Checked = true;
                        }
                    }
                    if (key_value[0] == "bpc")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton8.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton7.Checked = true;
                        }
                    }

                    if (key_value[0] == "wpc")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton10.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton9.Checked = true;
                        }
                    }

                    if (key_value[0] == "raw_gma")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton12.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton11.Checked = true;
                        }
                    }

                    if (key_value[0] == "lenc")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton14.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton13.Checked = true;
                        }
                    }
                    if (key_value[0] == "hmirror")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton16.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton15.Checked = true;
                        }
                    }
                    if (key_value[0] == "vflip")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton18.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton17.Checked = true;
                        }
                    }
                    if (key_value[0] == "dcw")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton20.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton19.Checked = true;
                        }
                    }
                    if (key_value[0] == "colorbar")
                    {
                        if (key_value[1] == "0")
                        {
                            radioButton22.Checked = true;
                        }
                        if (key_value[1] == "1")
                        {
                            radioButton21.Checked = true;
                        }
                    }
                }
            }
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar1.Value.ToString();
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label4.Text = hScrollBar2.Value.ToString();
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            label5.Text = hScrollBar3.Value.ToString();
        }

        private void hScrollBar4_Scroll(object sender, ScrollEventArgs e)
        {
            label6.Text = hScrollBar4.Value.ToString();
        }

        private void hScrollBar5_Scroll(object sender, ScrollEventArgs e)
        {
            label7.Text = hScrollBar5.Value.ToString();
        }

        private void hScrollBar6_Scroll(object sender, ScrollEventArgs e)
        {
            label8.Text = hScrollBar6.Value.ToString();
        }

        private void hScrollBar7_Scroll(object sender, ScrollEventArgs e)
        {
            label9.Text = hScrollBar7.Value.ToString();
        }

        private void hScrollBar8_Scroll(object sender, ScrollEventArgs e)
        {
            label10.Text = hScrollBar8.Value.ToString();
        }

        private void hScrollBar9_Scroll(object sender, ScrollEventArgs e)
        {
            label11.Text = hScrollBar9.Value.ToString();
        }

        private void hScrollBar10_Scroll(object sender, ScrollEventArgs e)
        {
            label12.Text = hScrollBar10.Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {


            if (listView2.SelectedItems.Count == 1)
            {
                //카메라세팅보내기버튼을 눌렀다!
                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                if (radioButton1.Checked)
                {
                    nvc.Add("framesize", "3");
                }
                else if (radioButton2.Checked)
                {
                    nvc.Add("framesize", "7");
                }

                nvc.Add("quality", hScrollBar1.Value.ToString());
                nvc.Add("brightness", hScrollBar2.Value.ToString());
                nvc.Add("contrast", hScrollBar3.Value.ToString());
                nvc.Add("saturation", hScrollBar4.Value.ToString());
                nvc.Add("special_effect", hScrollBar5.Value.ToString());

                if (radioButton4.Checked)
                {
                    nvc.Add("awb_gain", "0");
                }
                else if (radioButton3.Checked)
                {
                    nvc.Add("awb_gain", "1");
                }

                nvc.Add("wb_mode", hScrollBar6.Value.ToString());

                if (radioButton6.Checked)
                {
                    nvc.Add("aec2", "0");
                }
                else if (radioButton5.Checked)
                {
                    nvc.Add("aec2", "1");
                }
                nvc.Add("ae_level", hScrollBar7.Value.ToString());
                nvc.Add("aec_value", hScrollBar9.Value.ToString());
                nvc.Add("agc_gain", hScrollBar8.Value.ToString());
                nvc.Add("gainceiling", hScrollBar10.Value.ToString());
                if (radioButton8.Checked)
                {
                    nvc.Add("bpc", "0");
                }
                else if (radioButton7.Checked)
                {
                    nvc.Add("bpc", "1");
                }
                if (radioButton10.Checked)
                {
                    nvc.Add("wpc", "1");
                }
                else if (radioButton9.Checked)
                {
                    nvc.Add("wpc", "1");
                }
                if (radioButton12.Checked)
                {
                    nvc.Add("raw_gma", "0");
                }
                else if (radioButton11.Checked)
                {
                    nvc.Add("raw_gma", "1");
                }
                if (radioButton14.Checked)
                {
                    nvc.Add("lenc", "1");
                }
                else if (radioButton13.Checked)
                {
                    nvc.Add("lenc", "1");
                }
                if (radioButton16.Checked)
                {
                    nvc.Add("hmirror", "0");
                }
                else if (radioButton15.Checked)
                {
                    nvc.Add("hmirror", "1");
                }
                if (radioButton18.Checked)
                {
                    nvc.Add("vflip", "0");
                }
                else if (radioButton17.Checked)
                {
                    nvc.Add("vflip", "1");
                }
                if (radioButton20.Checked)
                {
                    nvc.Add("dcw", "0");
                }
                else if (radioButton19.Checked)
                {
                    nvc.Add("dcw", "1");
                }
                if (radioButton22.Checked)
                {
                    nvc.Add("colorbar", "0");
                }
                else if (radioButton21.Checked)
                {
                    nvc.Add("colorbar", "1");
                }

                button5.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/camset", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button5.BackColor = SystemColors.Control;
                }
            }

        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                //만약 스트리밍이 진행중이었다면..
                //강제로 종료해버리겠다!
                for (int i = 0; i < listView2.Items.Count; i++)
                {
                    if (cam_timer[i].Enabled == true)
                    {
                        cam_timer[i].Stop();
                        //vc[i].Release();
                        vw[i].Release();
                    }
                }


                //play_thread
                //play_vc
                play_vc.Open(listView1.SelectedItems[0].SubItems[1].Text);
                if (play_vc.IsOpened())
                {
                    trackBar1.Maximum = play_vc.FrameCount - 1;
                    trackBar1.Value = 0;
                    //richTextBox1.Text += "전체프레임수;"+play_vc.FrameCount + "\n";
                    //richTextBox1.Text += "이미지 폭:" + play_vc.FrameWidth + "\n";
                    //richTextBox1.Text += "이미지 높이:" + play_vc.FrameHeight;

                    //timer2를 작동시키겠다!
                    if (timer2.Enabled == true)
                    {
                        timer2.Stop();
                    }
                    timer2.Start();
                }

            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            play_vc.PosFrames = trackBar1.Value;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Mat image = new Mat();
            if (play_vc.Read(image) && play_vc.PosFrames < play_vc.FrameCount)
            {
                pictureBoxIpl1.ImageIpl = image;
                trackBar1.Value = play_vc.PosFrames;
            }
            else
            {
                timer2.Stop();
                play_vc.Release();
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (timer2.Enabled == true)
            {
                timer2.Stop();
                play_vc.Release();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && listView2.Items.Count < 2)
            {
                //IP주소가 비어있지 않다면 진행하겠다~
                ListViewItem lvi = new ListViewItem();
                lvi.Text = textBox1.Text;
                lvi.SubItems.Add("-");

                listView2.Items.Add(lvi);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                //1개를 선택했다면~
                listView2.Items[listView2.SelectedIndices[0]].Remove();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            camera_load_thread = new Thread(new ThreadStart(camera_load));
            camera_load_thread.Start();



        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            int camera_id = 1;
            //스틸이미지를 저장할 공간을 만든다
            image[camera_id] = new Mat();
            //스틸이미지 한장을 읽어온다
            if (vc[camera_id].Read(image[camera_id]))
            {

                //만약에 동영상파일을 녹화한 시간이 20초가 경과했다면..
                //새로운 파일로 다시 저장하겠다!
                if ((DateTime.Now - cam_watch[camera_id]).TotalMilliseconds > 10000)
                {
                    cam_watch[camera_id] = DateTime.Now;

                    //이전에 기록하고 있던 파일을 list view에 추가하겠다!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = "CAM" + (camera_id + 1).ToString();
                    lvi.SubItems.Add(vw[camera_id].FileName);
                    listView1.Items.Add(lvi);

                    //20초가 경과되었다!
                    //새로운 파일로 만들어서 새로 녹화를 시작해야겠다!
                    vw[camera_id].Release(); //녹화중지!
                    string file_name = cam_watch[camera_id].Year + "_" + cam_watch[camera_id].Month + "_" + cam_watch[camera_id].Day + "_" + cam_watch[camera_id].Hour + "_" + cam_watch[camera_id].Minute + "_" + cam_watch[camera_id].Second + "_cam" + (camera_id + 1) + ".mp4";
                    string file_path = "./CCTV/" + file_name;
                    vw[camera_id].Open(file_path, FourCC.DIVX, 10, new OpenCvSharp.Size(vc[camera_id].FrameWidth, vc[camera_id].FrameHeight));
                    vw[camera_id].Write(image[camera_id]);
                }
                else
                {
                    vw[camera_id].Write(image[camera_id]);
                }
                //vc.FrameCount
                //vc.FrameHeight
                //vc.FrameWidth
                //label1.Text = "너비 : " + vc[0].FrameWidth.ToString();
                //label2.Text = "높이 : " + vc[0].FrameHeight.ToString();

                //읽어온 이미지를 픽쳐박스에 드로잉한다
                if (listView2.SelectedItems.Count == 1)
                {
                    if (listView2.SelectedIndices[0] == camera_id)
                    {
                        if (radioButton23.Checked)
                        {
                            //1채널모드
                            pictureBoxIpl1.ImageIpl = image[camera_id];
                        }
                        else if (radioButton24.Checked)
                        {
                            //2채널모드
                            //image[0] image[1]
                            Mat output = new Mat();
                            int w = image[0].Width;
                            int h = image[0].Height;

                            OpenCvSharp.Size s = new OpenCvSharp.Size(2 * w, h);
                            Mat dummy = new Mat(s, image[0].Type());

                            Cv2.HConcat(image[0], image[1], output);
                            Cv2.VConcat(output, dummy, output);
                            pictureBoxIpl1.ImageIpl = output;
                        }
                    }
                }
            }
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if(listView2.SelectedItems.Count == 1)
            // richTextBox1.Text = listView2.SelectedIndices[0].ToString();
        }

        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            if (listView2.Items.Count < 2)
            {
                radioButton23.Checked = true;
            }
        }

        private void hScrollBar11_Scroll(object sender, ScrollEventArgs e)
        {
            label13.Text = hScrollBar11.Value.ToString();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("servo1", hScrollBar11.Value.ToString());
                //wc.UploadValues()
                button10.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servo", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button10.BackColor = SystemColors.Control;
                }
            }
        }

        private void hScrollBar12_Scroll(object sender, ScrollEventArgs e)
        {
            label14.Text = hScrollBar12.Value.ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("servo2", hScrollBar12.Value.ToString());
                //wc.UploadValues()
                button11.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servo", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button11.BackColor = SystemColors.Control;
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                int degree = hScrollBar11.Value;
                degree -= 10;
                if (degree < 0) degree = 0;

                hScrollBar11.Value = degree;
                label13.Text = degree.ToString();

                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("servo1", degree.ToString());
                //wc.UploadValues()
                button10.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servo", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button10.BackColor = SystemColors.Control;
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                int degree = hScrollBar11.Value;
                degree += 10;
                if (degree > 180) degree = 180;

                hScrollBar11.Value = degree;
                label13.Text = degree.ToString();

                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("servo1", degree.ToString());
                //wc.UploadValues()
                button10.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servo", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button10.BackColor = SystemColors.Control;
                }
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                int degree = hScrollBar12.Value;
                degree -= 10;
                if (degree < 0) degree = 0;

                hScrollBar12.Value = degree;
                label14.Text = degree.ToString();

                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("servo2", degree.ToString());
                //wc.UploadValues()
                button11.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servo", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button11.BackColor = SystemColors.Control;
                }
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                int degree = hScrollBar12.Value;
                degree += 10;
                if (degree > 180) degree = 180;

                hScrollBar12.Value = degree;
                label14.Text = degree.ToString();

                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("servo2", degree.ToString());
                //wc.UploadValues()
                button11.BackColor = Color.Red;
                byte[] response = wc.UploadValues("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servo", nvc);

                if (response[0] == 'O' && response[1] == 'K')
                {
                    button11.BackColor = SystemColors.Control;
                }
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 1)
            {
                //카메라세팅가져오기 버튼을 눌렀다!
                WebClient wc = new WebClient();
                string response = wc.UploadString("http://" + listView2.SelectedItems[0].SubItems[0].Text + "/servoget", "HELLO");
                if (response != "")
                {
                    //response example : 각도1/각도2
                    string[] data = response.Split('/');
                    label13.Text = data[0];
                    label14.Text = data[1];
                    hScrollBar11.Value = int.Parse(data[0]);
                    hScrollBar12.Value = int.Parse(data[1]);
                }
            }
        }
    }
}
