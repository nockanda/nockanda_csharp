﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example106
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            //client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text.Length > 16)
            {
                MessageBox.Show("메시지 길이가 16을 넘습니다..!");
            }else if(textBox1.Text == "")
            {
                MessageBox.Show("메시지를 입력해주세요!");
            }
            else
            {
                //publish!
                client.Publish("nockanda/line1", Encoding.UTF8.GetBytes(textBox1.Text), 0, true);

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add("1");
                lvi.SubItems.Add(textBox1.Text);

                listView1.Items.Add(lvi);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Length > 16)
            {
                MessageBox.Show("메시지 길이가 16을 넘습니다..!");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("메시지를 입력해주세요!");
            }
            else
            {
                //publish!
                client.Publish("nockanda/line2", Encoding.UTF8.GetBytes(textBox2.Text), 0, true);

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add("2");
                lvi.SubItems.Add(textBox2.Text);

                listView1.Items.Add(lvi);
            }
        }
    }
}
