﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example99
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/ON");
            MessageBox.Show(response);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/OFF");
            MessageBox.Show(response);
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = hScrollBar1.Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("mosfet", hScrollBar1.Value.ToString());
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            if (radioButton1.Checked)
            {
                //정방향
                nvc.Add("DIRECT", "FORWARD");
            }
            else if (radioButton2.Checked)
            {
                //역방향
                nvc.Add("DIRECT", "BACKWARD");
            }
            nvc.Add("POWER", hScrollBar2.Value.ToString());
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar2.Value.ToString();
        }
    }
}
