﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example64
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
                MessageBox.Show("정상적으로 연결되었습니다!");
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[1];
                serialPort1.Read(recv, 0, 1);
                
                //richTextBox1.Text += recv[0] + "\n";
                if(recv[0] == 0)
                {
                    //수위가 낮은상태
                    label1.Text = "수위낮아짐";
                    richTextBox1.Text += DateTime.Now.ToString() + " 수위낮아짐\n";
                }
                else
                {
                    //수위가 높은상태
                    label1.Text = "수위높아짐";
                    richTextBox1.Text += DateTime.Now.ToString() + " 수위높아짐\n";
                }
            }
        }
    }
}
