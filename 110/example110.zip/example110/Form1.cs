﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example110
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독정보지정
            string[] topic = { "nockanda/out1", "nockanda/out2", "nockanda/out3" };
            byte[] qos = { 0, 0, 0 };
            client.Subscribe(topic, qos);
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            //TOPIC, VALUE
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/out1")
            {
                label1.Text = ReceivedMessage;
            }
            else if(e.Topic == "nockanda/out2")
            {
                label2.Text = ReceivedMessage;
            }
            else if(e.Topic == "nockanda/out3")
            {
                label4.Text = ReceivedMessage;
            }

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //nockanda/relay
            client.Publish("nockanda/relay", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/relay", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar1.Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/mosfet", Encoding.UTF8.GetBytes(hScrollBar1.Value.ToString()), 0, true);
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label5.Text = hScrollBar2.Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/direct", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/direct", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/power", Encoding.UTF8.GetBytes(hScrollBar2.Value.ToString()), 0, true);
        }
    }
}
