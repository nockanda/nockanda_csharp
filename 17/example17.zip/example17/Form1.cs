﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime time2 = DateTime.Now;
           
            label1.Text = (time2 - time1).TotalSeconds.ToString();
            
        }
        DateTime time1;
        private void button1_Click(object sender, EventArgs e)
        {
            time1 = DateTime.Now;
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ListViewItem lvi = new ListViewItem();
            lvi.Text = DateTime.Now.ToString();
            lvi.SubItems.Add(label1.Text);
            listView1.Items.Add(lvi);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(timer2.Enabled == true)
            {
                //실행
                timer2.Stop();
            }
            else
            {
                //멈춤
                timer2.Start();
                
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            ListViewItem lvi = new ListViewItem();
            lvi.Text = DateTime.Now.ToString();
            lvi.SubItems.Add(label1.Text);
            listView1.Items.Add(lvi);
        }
    }
}
