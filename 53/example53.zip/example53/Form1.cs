﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example53
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        String[] morsecode =
{
  "-----",//0
  "*----",//1
  "**---",//2
  "***--",//3
  "****-",//4
  "*****",//5
  "-****",//6
  "--***",//7
  "---**",//8
  "----*",//9
  "", //:
  "", //;
  "", //<
  "", //=
  "", //>
  "", //?
  "", //@
  "*-", //a
  "-***", //b
  "-*-*",//c
  "-**",//d
  "*",//e
  "**-*",//f
  "--*",//g
  "****",//h
  "**",//i
  "*---",//j
  "-*-",//k
  "*-**",//l
  "--",//m
  "-*",//n
  "---",//o
  "*--*",//p
  "--*-",
  "*-*",
  "***",
  "-",
  "**-",
  "***-",
  "*--",
  "-**-",
  "-*--",
  "--**"
        };

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "")
            {
                //공백은 ox20
                textBox3.Text = "";
                textBox3.Text = text2morse(textBox2.Text);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                string send = textBox2.Text;
                serialPort1.WriteLine(send);
                listBox1.Items.Add(DateTime.Now.ToString() + "/" + send + "/" + text2morse(send));
            }
        }

        string text2morse(string input)
        {
            string temp = "";
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == ' ')
                {
                    //i번째 문자가 sapce다
                    temp += " ";
                }
                else
                {
                    temp += morsecode[input[i] - '0'] + " ";
                }
            }
            return temp;
        }
    }
}
