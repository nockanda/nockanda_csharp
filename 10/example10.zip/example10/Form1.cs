﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            //5번 예제 체크박스를 45개 만들어서 로또 번호 6개를 고르고 버튼을 누르면 선택한 번호가 리치텍스트박스에 나오게 해보자!
            lottoset[0] = checkBox3;
            lottoset[1] = checkBox4;
            lottoset[2] = checkBox5;
            lottoset[3] = checkBox6;
            lottoset[4] = checkBox7;
            lottoset[5] = checkBox8;
            lottoset[6] = checkBox9;
            lottoset[7] = checkBox10;
            lottoset[8] = checkBox11;
            lottoset[9] = checkBox12;
            lottoset[10] = checkBox13;
            lottoset[11] = checkBox14;
            lottoset[12] = checkBox15;
            lottoset[13] = checkBox16;
            lottoset[14] = checkBox17;
            lottoset[15] = checkBox18;
            lottoset[16] = checkBox19;
            lottoset[17] = checkBox20;
            lottoset[18] = checkBox21;
            lottoset[19] = checkBox22;
            lottoset[20] = checkBox23;
            lottoset[21] = checkBox24;
            lottoset[22] = checkBox25;
            lottoset[23] = checkBox26;
            lottoset[24] = checkBox27;
            lottoset[25] = checkBox28;
            lottoset[26] = checkBox29;
            lottoset[27] = checkBox30;
            lottoset[28] = checkBox31;
            lottoset[29] = checkBox32;
            lottoset[30] = checkBox33;
            lottoset[31] = checkBox34;
            lottoset[32] = checkBox35;
            lottoset[33] = checkBox36;
            lottoset[34] = checkBox37;
            lottoset[35] = checkBox38;
            lottoset[36] = checkBox39;
            lottoset[37] = checkBox40;
            lottoset[38] = checkBox41;
            lottoset[39] = checkBox42;
            lottoset[40] = checkBox43;
            lottoset[41] = checkBox44;
            lottoset[42] = checkBox45;
            lottoset[43] = checkBox46;
            lottoset[44] = checkBox47;

            for(int i = 0; i < lottoset.Length; i++)
            {
                lottoset[i].Text = $"{i + 1}";
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                //체크된거
                label1.Text = checkBox1.Text + "를 선택했네요!";
            }
            else
            {
                //체크풀린거
                label1.Text = "결과";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                //체크된거
                label1.Text = checkBox2.Text + "를 선택했네요!";
            }
            else
            {
                //체크풀린거
                label1.Text = "결과";
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        CheckBox[] lottoset = new CheckBox[45];

        private void button1_Click(object sender, EventArgs e)
        {
            //1번예제 라디오버튼예제
            if (radioButton1.Checked)
            {
                //1번 체크
                label1.Text = radioButton1.Text;
            }
            else if (radioButton2.Checked)
            {
                //2번 체크
                label1.Text = radioButton2.Text;
            }

            //3번예제 체크박스예제
            richTextBox1.Text = "";
            if (checkBox1.Checked)
            {
                richTextBox1.Text += "체크박스1\n";
            }
            if (checkBox2.Checked)
            {
                richTextBox1.Text += "체크박스2\n";
            }

            //4번예제
            if (radioButton1.Checked)
            {
                richTextBox1.Text += "라디오버튼1\n";
            }else if (radioButton2.Checked)
            {
                richTextBox1.Text += "라디오버튼2\n";
            }

            //5번 예제 체크박스를 45개 만들어서 로또 번호 6개를 고르고 버튼을 누르면 선택한 번호가 리치텍스트박스에 나오게 해보자!
            //체크박스 3~47
            int count = 0;
            for(int i = 0; i < lottoset.Length; i++)
            {
                if (lottoset[i].Checked)
                {
                    count++;
                }
            }
            if (count == 6)
            {
                for (int i = 0; i < lottoset.Length; i++)
                {
                    if (lottoset[i].Checked)
                    {
                        //임의의 체크박스가 체크가 된 경우
                        richTextBox1.Text += lottoset[i].Text + "\n";
                    }
                }
                richTextBox1.Text += "결과 = " + count;
            }
            else
            {
                MessageBox.Show("6개만 선택하세요!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //(스몰프로젝트) 체크박스 4개에 사칙연산기호(+,-,*,/)가 각각있고 하나를 선택한다음 버튼을 눌렀을때 텍스트박스 2개에 있는 값이 연산되어서 메시지박스로 결과를 출력하라!
            //체크박스를 복수개 선택하면 복수개 결과가 나오도록하고 라디오버튼을 2개 만든다음 첫번쨰는 정수출력 두번쨰는 실수출력이 가능하도록해라!
            double num1 = double.Parse(textBox1.Text);
            double num2 = double.Parse(textBox2.Text);
            double[] result = new double[4];
            richTextBox1.Text = "";
            if (checkBox48.Checked)
            {
                //+
                result[0] = num1 + num2;
            }
            if (checkBox49.Checked)
            {
                //-
                result[1] = num1 - num2;
            }
            if (checkBox50.Checked)
            {
                //*
                result[2] = num1 * num2;
            }
            if (checkBox51.Checked)
            {
                //'/'
                result[3] = num1 / num2;
            }

            if (radioButton3.Checked)
            {
                //정수출력
                for(int i = 0; i < result.Length; i++)
                {
                    if (result[i] == 0) continue;
                    richTextBox1.Text += $"{(int)result[i]}\n";
                }
            }
            else if(radioButton4.Checked)
            {
                //실수출력
                for (int i = 0; i < result.Length; i++)
                {
                    if (result[i] == 0) continue;
                    richTextBox1.Text += $"{result[i]}\n";
                }
            }
        }
    }
}
