﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using MySql.Data.MySqlClient;

namespace example143
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example148;Uid=root;Pwd=qwer1234;";
        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;

                richTextBox1.Text += request.RawUrl + "\n";

                //RFID 태그의 ID 
                //request.RawUrl : /d46da22a

                //DB를 뒤져서 권한유무를 클라이언트에게 알려줘야한다!
                string tag_id = request.RawUrl.Replace("/", "");

                //검색구문
                string responseString = "";

                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    DataSet ds = new DataSet();
                    string sql = "select * from apartment where tag='"+ tag_id + "'";
                    MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                    adpt.Fill(ds, "apartment");


                    //존재하지 않으면 0
                    //권한이 없으면 1
                    //권한이 있으면 2
                    
                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        //DB에 존재하지 않는 RFID태그
                        responseString = "<response>0\n";
                    }
                    else
                    {
                        //DB에 존재하는데 권한이 있는 카드
                        //DB에 존재하는데 권한이 없는 카드
                        string dong = ds.Tables[0].Rows[0]["dong"].ToString();
                        string ho = ds.Tables[0].Rows[0]["ho"].ToString();
                        string auto = ds.Tables[0].Rows[0]["auth"].ToString();

                        if(auto == "0")
                        {
                            //권한이 없는것
                            responseString = "<response>1\n";
                        }
                        else
                        {
                            //권한이 있는것
                            responseString = "<response>2\n";
                        }
                    }
                }

                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                // Construct a response.
                
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();

            fm2.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 fm3 = new Form3();
            fm3.ShowDialog();
        }
    }
}
