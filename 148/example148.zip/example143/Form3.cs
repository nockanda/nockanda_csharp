﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example143
{
    public partial class Form3 : Form
    {
        string Conn = "Server=localhost;Database=example148;Uid=root;Pwd=qwer1234;";
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from apartment where tag='" + textBox1.Text + "'";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "apartment");

                if (ds.Tables[0].Rows.Count == 0)
                {
                    MessageBox.Show("조회결과가 없습니다!");
                }
                else
                {
                    textBox2.Text = ds.Tables[0].Rows[0]["dong"].ToString();
                    textBox3.Text = ds.Tables[0].Rows[0]["ho"].ToString();
                    textBox4.Text = ds.Tables[0].Rows[0]["auth"].ToString();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from apartment where dong='"+textBox2.Text+"' and ho='"+textBox3.Text+"'";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "apartment");

                if (ds.Tables[0].Rows.Count == 0)
                {
                    MessageBox.Show("조회결과가 없습니다!");
                }
                else
                {
                    textBox1.Text = ds.Tables[0].Rows[0]["tag"].ToString();
                    textBox4.Text = ds.Tables[0].Rows[0]["auth"].ToString();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //수정구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("update apartment set auth="+textBox4.Text+" where tag='"+textBox1.Text+"'", conn);
                msc.ExecuteNonQuery();
            }

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}
