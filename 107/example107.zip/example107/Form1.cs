﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example107
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        int x_pos1 = 0;
        int x_pos2 = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);


            //구독정보 지정
            string[] topic = {"nockanda/analog", "nockanda/cds" };
            byte[] qos = { 0, 0 };
            client.Subscribe(topic, qos);
        }
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/analog")
            {
                label1.Text = ReceivedMessage;
                listBox1.Items.Add(ReceivedMessage);

                //chart drawing!
                double y_pos = double.Parse(ReceivedMessage);
                chart1.Series[0].Points.AddXY(x_pos1, y_pos);

                //윈도우 사이즈는 10
                if(chart1.Series[0].Points.Count > 10)
                {
                    chart1.Series[0].Points.RemoveAt(0);
                }

                chart1.ChartAreas[0].AxisX.Maximum = x_pos1;
                chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;

                chart1.ChartAreas[0].AxisY.Maximum = 1024;

                x_pos1++;
            }else if(e.Topic == "nockanda/cds")
            {
                label2.Text = ReceivedMessage;
                listBox2.Items.Add(ReceivedMessage);

                //chart drawing!
                double y_pos = double.Parse(ReceivedMessage);
                chart2.Series[0].Points.AddXY(x_pos2, y_pos);

                //윈도우 사이즈는 10
                if (chart2.Series[0].Points.Count > 10)
                {
                    chart2.Series[0].Points.RemoveAt(0);
                }

                chart2.ChartAreas[0].AxisX.Maximum = x_pos2;
                chart2.ChartAreas[0].AxisX.Minimum = chart2.Series[0].Points[0].XValue;

                chart2.ChartAreas[0].AxisY.Maximum = 1024;

                x_pos2++;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
