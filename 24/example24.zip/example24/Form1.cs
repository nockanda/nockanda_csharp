﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example24
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        Point location = new Point(437, 251); //원래 고양이의 위치
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] data = new byte[4];
                serialPort1.Read(data, 0, 4);
                //2바이트 = 16비트
                //0000 0000 0000 0000
                //0~1023
                int x = data[0] * 256 + data[1];
                int y = data[2] * 256 + data[3];
                if (x > 512)
                {
                    //오른쪽으로 제낌
                    int x2 = (x - 512) / 2;
                    button2.Location = new Point(location.X + x2, button2.Location.Y);
                }
                else
                {
                    //왼쪽으로 제낌
                    int x2 = (512 - x) / 2;
                    button2.Location = new Point(location.X - x2, button2.Location.Y);
                }
                if (y > 512)
                {
                    //위로 제낌
                    int y2 = (y - 512) / 2;
                    button2.Location = new Point(button2.Location.X, location.Y + y2);
                }
                else
                {
                    //아래로 제낌
                    int y2 = (512 - y) / 2;
                    button2.Location = new Point(button2.Location.X, location.Y - y2);
                }
                label1.Text = x.ToString();
                label2.Text = y.ToString();
                hScrollBar1.Value = x;
                vScrollBar1.Value = y;
            }
        }
    }
}
