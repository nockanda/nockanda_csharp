﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example102
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //Nockanda_key nk = new Nockanda_key();
            //string yourkey = nk.potal_key;
            string yourkey = textBox1.Text;
            string query = "http://openapi.tago.go.kr/openapi/service/ArvlInfoInqireService/getSttnAcctoArvlPrearngeInfoList?serviceKey="+yourkey+"&cityCode="+textBox2.Text+"&nodeId="+textBox3.Text;
            WebRequest wr = WebRequest.Create(query);
            wr.Method = "GET";

            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);
            string response = sr.ReadToEnd();
            
            //string response = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><response><header><resultCode>00</resultCode><resultMsg>NORMAL SERVICE.</resultMsg></header><body><items><item><arrprevstationcnt>3</arrprevstationcnt><arrtime>308</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000002</routeid><routeno>2</routeno><routetp>간선버스</routetp><vehicletp>저상버스</vehicletp></item><item><arrprevstationcnt>1</arrprevstationcnt><arrtime>67</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000002</routeid><routeno>2</routeno><routetp>간선버스</routetp><vehicletp>일반차량</vehicletp></item><item><arrprevstationcnt>3</arrprevstationcnt><arrtime>124</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000014</routeid><routeno>11</routeno><routetp>간선버스</routetp><vehicletp>저상버스</vehicletp></item><item><arrprevstationcnt>15</arrprevstationcnt><arrtime>1220</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000014</routeid><routeno>11</routeno><routetp>간선버스</routetp><vehicletp>저상버스</vehicletp></item><item><arrprevstationcnt>10</arrprevstationcnt><arrtime>845</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000030</routeid><routeno>28</routeno><routetp>간선버스</routetp><vehicletp>저상버스</vehicletp></item><item><arrprevstationcnt>3</arrprevstationcnt><arrtime>213</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000030</routeid><routeno>28</routeno><routetp>간선버스</routetp><vehicletp>저상버스</vehicletp></item><item><arrprevstationcnt>17</arrprevstationcnt><arrtime>1504</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000056</routeid><routeno>103</routeno><routetp>좌석버스</routetp><vehicletp>일반차량</vehicletp></item><item><arrprevstationcnt>3</arrprevstationcnt><arrtime>208</arrtime><nodeid>ICB166000378</nodeid><nodenm>미산초등학교</nodenm><routeid>ICB165000056</routeid><routeno>103</routeno><routetp>좌석버스</routetp><vehicletp>일반차량</vehicletp></item></items><numOfRows>10</numOfRows><pageNo>1</pageNo><totalCount>8</totalCount></body></response>";

            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["response"]["body"]["items"];

            listView1.Items.Clear();
            listView2.Items.Clear();
            for (int i = 0; i < xn.ChildNodes.Count; i++)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = xn.ChildNodes[i]["routeno"].InnerText;
                lvi.SubItems.Add(xn.ChildNodes[i]["arrprevstationcnt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["arrtime"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["nodeid"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["nodenm"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["routeid"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["routetp"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["vehicletp"].InnerText);

                int arrtime = int.Parse(xn.ChildNodes[i]["arrtime"].InnerText);
                if (arrtime < 180)
                {
                    listView2.Items.Add(lvi);
                }
                else
                {
                    listView1.Items.Add(lvi);
                }
                //richTextBox1.Text += xn.ChildNodes[i]["routeno"].InnerText + "\n";
            }
        }
    }
}
