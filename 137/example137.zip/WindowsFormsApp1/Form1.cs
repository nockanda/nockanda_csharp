﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using NAudio.Wave;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Xml;
using MediaPlayer;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Recorder recorder;

        public Form1()
        {
            InitializeComponent();
        }


        //출처 https://pythonq.com/so/c%23/744845
        public class Recorder
        {

            WaveIn sourceStream;
            WaveFileWriter waveWriter;
            readonly String FilePath;
            readonly String FileName;
            readonly int InputDeviceIndex;

            public Recorder(int inputDeviceIndex, String filePath, String fileName)
            {
                this.InputDeviceIndex = inputDeviceIndex;
                this.FileName = fileName;
                this.FilePath = filePath;
            }

            public void StartRecording()
            {
                sourceStream = new WaveIn
                {
                    DeviceNumber = this.InputDeviceIndex,
                    WaveFormat =
                        new WaveFormat(16000, 1)
                };

                sourceStream.DataAvailable += this.SourceStreamDataAvailable;

                if (!Directory.Exists(FilePath))
                {
                    Directory.CreateDirectory(FilePath);
                }

                waveWriter = new WaveFileWriter(FilePath + FileName, sourceStream.WaveFormat);
                sourceStream.StartRecording();
            }

            public void SourceStreamDataAvailable(object sender, WaveInEventArgs e)
            {
                if (waveWriter == null) return;
                waveWriter.Write(e.Buffer, 0, e.BytesRecorded);
                waveWriter.Flush();
            }

            public void RecordEnd()
            {
                if (sourceStream != null)
                {
                    sourceStream.StopRecording();
                    sourceStream.Dispose();
                    sourceStream = null;
                }
                if (this.waveWriter == null)
                {
                    return;
                }
                this.waveWriter.Dispose();
                this.waveWriter = null;

            }
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            //레코딩 시작
            label1.Text = "음성녹음을 시작합니다!";
            recorder = new Recorder(0, "./voice/", "test.wave");
            recorder.StartRecording();
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            //레코딩 종료
            label1.Text = "음성녹음을 종료합니다!";
            recorder.RecordEnd();

            //OPENAPI
            string url = "https://kakaoi-newtone-openapi.kakao.com/v1/recognize";
            string your_key = textBox1.Text;


            WebRequest wr = WebRequest.Create(url);
            wr.Method = "POST";
            wr.ContentType = "application/octet-stream";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);

            FileStream fs = new FileStream("./voice/test.wave", FileMode.Open);

            Stream s1 = wr.GetRequestStream();

            fs.CopyTo(s1);

            fs.Close();
            fs.Dispose();
            s1.Close();

            ///response
            WebResponse wrs = wr.GetResponse();
            Stream s2 = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s2);

            string response = sr.ReadToEnd();

            string start = "\"finalResult\",\"value\":\"";
            string end = "\",\"nBest\":[{";

            int ss1 = response.IndexOf(start) + start.Length;
            int ee1 = response.IndexOf(end);

            string text = response.Substring(ss1, ee1 - ss1);

            label3.Text = "인식결과 = " + text;

            //계산기켜줘
            if(text.IndexOf("계산기") != -1 && text.IndexOf("켜") != -1)
            {
                //음성인식 결과에 계산기와 켜라는 키워드가 모두 존재하는!
                System.Diagnostics.Process.Start("calc");
            }

            if (text.IndexOf("그림판") != -1 && text.IndexOf("켜") != -1)
            {
                System.Diagnostics.Process.Start("mspaint");
            }

            if (text.IndexOf("메모장") != -1 && text.IndexOf("켜") != -1)
            {
                System.Diagnostics.Process.Start("notepad");
            }

            if (text.IndexOf("아두이노") != -1 && text.IndexOf("켜") != -1)
            {
                System.Diagnostics.Process.Start(@"C:\Program Files (x86)\Arduino\arduino.exe");
            }

            //내일 날씨 어떄?(134편에서 했던 내용이랑 짬뽕)
            if (text.IndexOf("내일") != -1 && text.IndexOf("날씨") != -1)
            {
                string data = get_rss();
                tts("녹칸다님! 내일 날씨 예보 안내해드리겠습니다." + data);
            }

            //지금 몇시야?
            if (text.IndexOf("몇") != -1 && text.IndexOf("시") != -1)
            {
                
                tts(DateTime.Now.ToString());
            }
        }

        void tts(string input)
        {
            string url = "https://kakaoi-newtone-openapi.kakao.com/v1/synthesize";
            
            string your_key = textBox1.Text;
           


            //웹클라이언트에서 정성스럽게 요청을 해야한다!
            WebRequest wr = WebRequest.Create(url);
            wr.Method = "POST";
            wr.ContentType = "application/xml";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);


            string text = "<speak>" + input + "</speak>";

            byte[] request = Encoding.UTF8.GetBytes(text);
            Stream request_stream = wr.GetRequestStream();
            request_stream.Write(request, 0, request.Length);

            request_stream.Close();


            WebResponse wrs = wr.GetResponse();
            Stream response_stream = wrs.GetResponseStream();
            //응답데이터가 mp3인 상황이라서!
            //이것을 파일로 저장해야한다!

            string path = "./output.mp3";
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            FileStream fs = new FileStream("./output.mp3", FileMode.Create);

            response_stream.CopyTo(fs);

            fs.Close();
            fs.Dispose();
            response_stream.Close();
            response_stream.Dispose();
            wrs.Close();


            MediaPlayerClass mpc = new MediaPlayerClass();
            mpc.FileName = "./output.mp3";
            mpc.Play();
        }

        string get_rss()
        {
            string url = "https://www.weather.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=108";

            WebRequest wr = WebRequest.Create(url);
            wr.Method = "GET";

            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            //xml파싱을 해야겠다!
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["rss"]["channel"]["item"]["description"]["header"]["wf"];

            string data = xn.InnerText;
            data = data.Replace("○", "");
            data = data.Replace("<br />", "");


            return data;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

    }
}
