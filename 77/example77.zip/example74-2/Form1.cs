﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example74_2
{
    public partial class Form1 : Form
    {
        bool is_received = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] port = SerialPort.GetPortNames();

            for(int i = 0; i < port.Length; i++)
            {
                comboBox1.Items.Add(port[i]);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
            {
                //시리얼포트가 닫혀있다면~
                if(comboBox1.SelectedIndex != -1)
                {
                    serialPort1.PortName = comboBox1.SelectedItem.ToString();
                    serialPort1.Open();

                    richTextBox1.Text += "시리얼포트가 열렸습니다!\n";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte relay_state = 0;

                byte[] send = new byte[10];
                send[0] = 0x01; //릴레이가 연결된 아두이노의 ID
                send[1] = 0x00; //지금은 의미가 없는 command id
                send[2] = relay_state; //0:off / 1:on
                send[3] = 0;
                send[4] = 0;
                send[5] = 0;
                send[6] = 0;
                send[7] = 0;
                send[8] = 0;
                send[9] = 0;

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                DateTime timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }

                //led가 달린 아두이노에게도 보내보자!
                send[0] = 0x00; //LED가 연결된 아두이노의 ID
                send[1] = 0x00; //지금은 의미가 없는 command id
                send[2] = relay_state; //0:off / 1:on
                send[3] = 0;
                send[4] = 0;
                send[5] = 0;
                send[6] = 0;
                send[7] = 0;
                send[8] = 0;
                send[9] = 0;

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            is_received = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = textBox1.Text;
                lvi.SubItems.Add("-");

                listView1.Items.Add(lvi);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count == 1)
            {
                //richTextBox1.Text = listView1.SelectedIndices[0].ToString();
                listView1.Items.RemoveAt(listView1.SelectedIndices[0]);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                byte[] send = new byte[10];
                send[0] = byte.Parse(listView1.SelectedItems[0].Text);
                send[1] = 0x00;
                send[2] = byte.Parse(textBox2.Text);
                send[3] = byte.Parse(textBox3.Text);
                send[4] = byte.Parse(textBox4.Text);
                send[5] = byte.Parse(textBox5.Text);
                send[6] = byte.Parse(textBox6.Text);
                send[7] = byte.Parse(textBox7.Text);
                send[8] = byte.Parse(textBox8.Text);
                send[9] = byte.Parse(textBox9.Text);

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                DateTime timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        listView1.SelectedItems[0].SubItems[1].Text = "FALSE";
                        
                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for(int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte relay_state = 1;

                byte[] send = new byte[10];
                send[0] = 0x01; //릴레이가 연결된 아두이노의 ID
                send[1] = 0x00; //지금은 의미가 없는 command id
                send[2] = relay_state; //0:off / 1:on
                send[3] = 0;
                send[4] = 0;
                send[5] = 0;
                send[6] = 0;
                send[7] = 0;
                send[8] = 0;
                send[9] = 0;

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                DateTime timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }

                //led가 달린 아두이노에게도 보내보자!
                send[0] = 0x00; //LED가 연결된 아두이노의 ID
                send[1] = 0x00; //지금은 의미가 없는 command id
                send[2] = relay_state; //0:off / 1:on
                send[3] = 0;
                send[4] = 0;
                send[5] = 0;
                send[6] = 0;
                send[7] = 0;
                send[8] = 0;
                send[9] = 0;

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte relay_state = 1;

                byte[] send = new byte[10];
                send[0] = 0x02; //홀센서가 연결된 아두이노의 ID
                send[1] = 0x00; //지금은 의미가 없는 command id
                send[2] = 0; //0:off / 1:on
                send[3] = 0;
                send[4] = 0;
                send[5] = 0;
                send[6] = 0;
                send[7] = 0;
                send[8] = 0;
                send[9] = 0;

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                DateTime timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //recv[2], recv[3]
                        int rpm = recv[2] * 256 + recv[3];

                        label2.Text = "RPM=" + rpm.ToString();

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {
                timer1.Start();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //RPM요청하는 코드
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[10];
                send[0] = 0x02; //홀센서가 연결된 아두이노의 ID
                send[1] = 0x00; //지금은 의미가 없는 command id
                send[2] = 0; //0:off / 1:on
                send[3] = 0;
                send[4] = 0;
                send[5] = 0;
                send[6] = 0;
                send[7] = 0;
                send[8] = 0;
                send[9] = 0;

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                DateTime timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //recv[2], recv[3]
                        int rpm = recv[2] * 256 + recv[3];

                        label2.Text = "RPM=" + rpm.ToString();

                        ListViewItem lvi2 = new ListViewItem();
                        lvi2.Text = DateTime.Now.ToString();
                        lvi2.SubItems.Add(rpm.ToString());

                        listView3.Items.Add(lvi2);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }
            }
        }
    }
}
