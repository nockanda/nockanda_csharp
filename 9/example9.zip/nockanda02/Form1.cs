﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nockanda02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = $"{double.Parse(textBox1.Text)+ double.Parse(textBox2.Text)}";
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            //textBox2.Text = "안녕?";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //this.Text = textBox1.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("폼로드 이벤트!");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //MessageBox.Show("폼클로징 이벤트!");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //MessageBox.Show("폼클로즈드 이벤트!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = $"{double.Parse(textBox1.Text) - double.Parse(textBox2.Text)}";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = $"{double.Parse(textBox1.Text) * double.Parse(textBox2.Text)}";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = $"{double.Parse(textBox1.Text) / double.Parse(textBox2.Text)}";
        }
    }
}
