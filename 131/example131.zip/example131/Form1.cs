﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example131
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=pos;Uid=root;Pwd=qwer1234;";

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            /*
            if(e.KeyCode == Keys.Enter)
            {
                string barcode = textBox1.Text;
                textBox1.Text = "";

                //MessageBox.Show(barcode);
                //바코드 찍으면 뭐할래?
            }
            */
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox3.Text != "")
            {
                //MYSQL에 조회해서 그 결과를 textbox2에 띄우면 끝!
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    DataSet ds = new DataSet();
                    string sql = "select * from casher where code='"+ textBox3.Text + "'";
                    MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                    adpt.Fill(ds, "casher");

                    //조회했더니 결과가 존재하더라 아니더라!
                    if(ds.Tables[0].Rows.Count == 1)
                    {
                        //조회에 성공
                        textBox2.Text = ds.Tables[0].Rows[0]["name"].ToString();
                    }
                    else
                    {
                        //조회에 실패
                        MessageBox.Show("없는 직원번호입니다!");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //insert into product values('12341234','녹칸다스낵',5000)

            if(textBox1.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                //MYSQL에 상품정보를 저장하겠다!
                string barcode = textBox1.Text;
                string name = textBox4.Text;
                string price = textBox5.Text;

                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into product values('" + barcode + "','" + name + "'," + price + ")", conn);
                    //return == 1 성공
                    msc.ExecuteNonQuery();

                    textBox1.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    MessageBox.Show("등록되었습니다!");
                }
            }
        }

        private void textBox6_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //바코드리더기로부터 바코드 13자리 수를 입력받았다!
                string barcode = textBox6.Text;
                textBox6.Text = "";
                //DB에서 상품정보를 가지고와서
                //리스트뷰에 출력
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    DataSet ds = new DataSet();
                    string sql = "select * from product where barcode='" + barcode + "'";
                    MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                    adpt.Fill(ds, "product");

                    //string barcode
                    string name = ds.Tables[0].Rows[0]["name"].ToString();
                    string price = ds.Tables[0].Rows[0]["price"].ToString();


                    bool is_matched = false;
                    //기존에 있는 것이면 수량이 1씩 올라가고
                    //기존에 없는 것이면 1이 저장이된다!
                    for (int i = 0; i < listView1.Items.Count; i++)
                    {
                        if (barcode == listView1.Items[i].SubItems[5].Text)
                        {
                            //수정
                            //수량필드를 1올린다!
                            int count = int.Parse(listView1.Items[i].SubItems[3].Text);
                            int price2 = int.Parse(listView1.Items[i].SubItems[2].Text);
                            count++;
                            listView1.Items[i].SubItems[3].Text = count.ToString();
                            listView1.Items[i].SubItems[4].Text = (count * price2).ToString();
                            is_matched = true;
                            break;
                        }
                    }

                    if (is_matched)
                    {
                        //아무것도 하지 않음
                    }
                    else
                    {
                        //등록
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = (listView1.Items.Count + 1).ToString();

                        lvi.SubItems.Add(name);
                        lvi.SubItems.Add(price);
                        lvi.SubItems.Add("1");
                        lvi.SubItems.Add(price);
                        lvi.SubItems.Add(barcode);

                        listView1.Items.Add(lvi);
                    }



                }


                //전체 상품가격을 출력
                int total_price = 0;
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    total_price += int.Parse(listView1.Items[i].SubItems[4].Text);
                }

                textBox7.Text = total_price.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //insert into history values('1234',1,'과자',2,3,4)
            //DB에 구매내역을 저장한다!

            Random r = new Random();

            string id = DateTime.Now.ToString("yyyyMMddhhmmss") + r.Next(100,1000);
            
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();

                

                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    string num = listView1.Items[i].SubItems[0].Text;
                    string name = listView1.Items[i].SubItems[1].Text;
                    string price = listView1.Items[i].SubItems[2].Text;
                    string count = listView1.Items[i].SubItems[3].Text;
                    string price2 = listView1.Items[i].SubItems[4].Text;

                    //richTextBox1.Text += "insert into history values('" + id + "'," + num + ",'" + name + "'," + price + "," + count + "," + price2 + ")\n";
                    MySqlCommand msc = new MySqlCommand("insert into history values('" + id + "'," + num + ",'" + name + "'," + price + "," + count + "," + price2 + ")", conn);
                    msc.ExecuteNonQuery();
                }
            }
            

            listView1.Items.Clear();
            textBox7.Text = "";

            MessageBox.Show("감사합니다!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(textBox8.Text != "")
            {
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    //환불테이블을 조회한후
                    DataSet ds2 = new DataSet();
                    string sql2 = "select * from refund where refund_id='"+ textBox8.Text + "';";
                    MySqlDataAdapter adpt2 = new MySqlDataAdapter(sql2, conn);
                    adpt2.Fill(ds2, "refund");

                    if (ds2.Tables[0].Rows.Count == 1)
                    {
                        //환불내역이 존재
                        MessageBox.Show("이미 환불되었습니다!"+ds2.Tables[0].Rows[0]["date"].ToString());
                    }
                    else
                    {
                        //환불내역 없음



                        //환불내역이 없으면 환불절차를 진행한다!
                        DataSet ds = new DataSet();
                        string sql = "select * from history where id='" + textBox8.Text + "'";
                        MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                        adpt.Fill(ds, "history");

                        int total_refund = 0;
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            ListViewItem lvi = new ListViewItem();
                            lvi.Text = ds.Tables[0].Rows[i]["id"].ToString();

                            lvi.SubItems.Add(ds.Tables[0].Rows[i]["num"].ToString());
                            lvi.SubItems.Add(ds.Tables[0].Rows[i]["name"].ToString());
                            lvi.SubItems.Add(ds.Tables[0].Rows[i]["price"].ToString());
                            lvi.SubItems.Add(ds.Tables[0].Rows[i]["count"].ToString());

                            string price2 = ds.Tables[0].Rows[i]["price2"].ToString();
                            total_refund += int.Parse(price2);
                            lvi.SubItems.Add(price2);

                            listView2.Items.Add(lvi);
                        }

                        textBox9.Text = total_refund.ToString();
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //insert into refund(refund_id,refund_price,date) values('test',1234,'test2');
            if (listView2.Items.Count > 0 && textBox9.Text != "")
            {
                string refund_id = listView2.Items[0].SubItems[0].Text;
                string refund_price = textBox9.Text;
                string date = DateTime.Now.ToString();

                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into refund(refund_id,refund_price,date) values('"+ refund_id + "',"+ refund_price + ",'"+ date + "');", conn);
                    msc.ExecuteNonQuery();
                }


                MessageBox.Show("환불이 완료되었습니다!");
                listView2.Items.Clear();
                textBox9.Text = "";
            }
        }
    }
}
