﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example126
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example126;Uid=root;Pwd=qwer1234;";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && serialPort1.IsOpen == false)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen == true)
            {
                serialPort1.Close();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string rawdata = serialPort1.ReadLine();
            string[] data = rawdata.Split(',');

            textBox2.Text = data[0];
            textBox3.Text = data[1];
            textBox4.Text = data[3] + "'C";
            textBox5.Text = data[2] + "%";
            textBox6.Text = data[4] + "PPM";

            //MYSQL에 데이터가 들어갈부분!
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into sp(soil,cds,humi,temp,co2,date) values("+ data[0] + ","+ data[1] + ","+ data[2] + ","+ data[3] + ","+ data[4] + ",'"+DateTime.Now.ToString() +"')", conn);
                msc.ExecuteNonQuery();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();

            fm2.ShowDialog();
        }
    }
}
