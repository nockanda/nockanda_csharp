﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example126
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example126;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //MYSQL DB에서 최근데이터 20개를 조회해서
            //그래프로 출력하겠다!
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from sp order by date desc limit 20";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "sp");

                chart1.Series[0].LegendText = "토양습도";
                chart1.Series[1].LegendText = "광량";
                chart1.Series[2].LegendText = "습도(%)";
                chart1.Series[3].LegendText = "온도('C)";
                chart1.Series[4].LegendText = "C02농도(PPM)";

                //데이터셋에 DB로부터 리턴된 결과가 저장되어있다!
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string soil = ds.Tables[0].Rows[i]["soil"].ToString();
                    string cds = ds.Tables[0].Rows[i]["cds"].ToString();
                    string humi = ds.Tables[0].Rows[i]["humi"].ToString();
                    string temp = ds.Tables[0].Rows[i]["temp"].ToString();
                    string co2 = ds.Tables[0].Rows[i]["co2"].ToString();

                    chart1.Series[0].Points.AddXY(i, int.Parse(soil));
                    chart1.Series[1].Points.AddXY(i, int.Parse(cds));
                    chart1.Series[2].Points.AddXY(i, float.Parse(humi));
                    chart1.Series[3].Points.AddXY(i, float.Parse(temp));
                    chart1.Series[4].Points.AddXY(i, int.Parse(co2));
                }
            
            }
        }
    }
}

