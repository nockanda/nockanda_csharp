﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example100
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("PUMP", "ON");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            label2.Text = "워터펌프작동상태:" + Encoding.UTF8.GetString(response);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("PUMP", "OFF");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            label2.Text = "워터펌프작동상태:" + Encoding.UTF8.GetString(response);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {
                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("FLOW", "~");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            label3.Text = "토출량:"+Encoding.UTF8.GetString(response) + "ml";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Stop();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("CLEAR", "~");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            //label2.Text = Encoding.UTF8.GetString(response);
        }
    }
}
