﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example36
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        int pre_degree = 0;
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                byte[] recv = new byte[3];
                serialPort1.Read(recv, 0, 3);
                double distance = ((recv[0] * 256) + recv[1]) / 100.0;
                label1.Text = distance.ToString();
                label2.Text = recv[2].ToString();
                if (distance == 0) return;
                
                Graphics g = pictureBox1.CreateGraphics();
                //각도 길이
                //길이가 100px
                Point center = new Point(pictureBox1.Width / 2, pictureBox1.Height);
                int dist = 100;
                int now_degree = recv[2];

                if(Math.Abs(pre_degree - now_degree) == 1)
                {
                    if(now_degree == 0 || now_degree == 180)
                    {
                        g.Clear(Color.Pink);
                    }
                }
                pre_degree = now_degree;

                Rectangle r1 = new Rectangle(center.X - dist, center.Y - dist, dist * 2, dist * 2);
                dist = 200;
                Rectangle r2 = new Rectangle(center.X - dist, center.Y - dist, dist * 2, dist * 2);
                dist = 300;
                Rectangle r3 = new Rectangle(center.X - dist, center.Y - dist, dist * 2, dist * 2);

                g.DrawPie(Pens.Black, r1, 0, -180);
                g.DrawPie(Pens.Black, r2, 0, -180);
                g.DrawPie(Pens.Black, r3, 0, -180);

                dist = (int)distance*2;
                Pen p;
                if (dist < 10)
                {
                    p = Pens.Red;
                }else if(dist < 30)
                {
                    p = Pens.Blue;
                }
                else if (dist < 50)
                {
                    p = Pens.Green;
                }
                else if(dist < 100)
                {
                    p = Pens.Gold;
                }
                else
                {
                    p = Pens.Black;
                }
                Rectangle r4 = new Rectangle(center.X - dist, center.Y - dist, dist * 2, dist * 2);
                g.DrawPie(p, r4, -now_degree, +1);
                //g.DrawRectangle(Pens.Red, r4);


                g.Dispose();
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
