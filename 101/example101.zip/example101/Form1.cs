﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example101
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int x_pos = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            //서버가 post서버로 동작중입니다

            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("MOTOR", hScrollBar1.Value.ToString());
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = hScrollBar1.Value.ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {
                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("RPM", "~");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            string response2 = Encoding.UTF8.GetString(response);
            label3.Text = response2 + " RPM";

            //
            int rpm = int.Parse(response2);

            //그래프를 그려보자!
            chart1.Series[0].Points.AddXY(x_pos, rpm);

            //데이터의 갯수가 녹칸다가 원하는 갯수인가?
            if(chart1.Series[0].Points.Count > 15)
            {
                //지정된 갯수 이상이라면 제일 처음들어온 녀석을 방출한다!
                chart1.Series[0].Points.RemoveAt(0);
            }

            //그래프 축을 바꿔줘야한다!
            chart1.ChartAreas[0].AxisX.Maximum = x_pos;
            chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;

            //그래프의 데이터셋의 y값중에 가장 큰값이 몇인가?
            int y_max = 0;
            for(int i = 0; i < chart1.Series[0].Points.Count; i++)
            {
                if(y_max < chart1.Series[0].Points[i].YValues[0])
                {
                    y_max = (int)chart1.Series[0].Points[i].YValues[0];
                }
            }

            chart1.ChartAreas[0].AxisY.Maximum = y_max + 100;

            x_pos++;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }
    }
}
