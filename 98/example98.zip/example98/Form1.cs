﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example98
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int x_pos = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");

            string[] data = response.Split('/');
            label2.Text = data[0];
            label3.Text = data[1];
            //MessageBox.Show(response);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");

            string[] data = response.Split('/');
            label2.Text = data[0];
            label3.Text = data[1];

            ListViewItem lvi = new ListViewItem();
            lvi.Text = DateTime.Now.ToString();
            lvi.SubItems.Add(data[0]);
            lvi.SubItems.Add(data[1]);
            listView1.Items.Add(lvi);

            //실시간 그래프를 그려보자
            chart1.Series[0].Points.AddXY(x_pos, int.Parse(data[0]));
            chart2.Series[0].Points.AddXY(x_pos, int.Parse(data[1]));

            if(chart1.Series[0].Points.Count > 10)
            {
                chart1.Series[0].Points.RemoveAt(0);
            }
            if (chart2.Series[0].Points.Count > 10)
            {
                chart2.Series[0].Points.RemoveAt(0);
            }

            chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;
            chart1.ChartAreas[0].AxisX.Maximum = x_pos;

            chart2.ChartAreas[0].AxisX.Minimum = chart2.Series[0].Points[0].XValue;
            chart2.ChartAreas[0].AxisX.Maximum = x_pos;

            //y축의 max값을 측정해보자!
            int chart1_y_max = 0;
            for(int i = 0; i < chart1.Series[0].Points.Count; i++)
            {
                //내가알고있던 최대값보다 더큰값이 있다면 그게 최대값이다
                if(chart1_y_max < (int)chart1.Series[0].Points[i].YValues[0])
                {
                    chart1_y_max = (int)chart1.Series[0].Points[i].YValues[0];
                }
            }
            chart1.ChartAreas[0].AxisY.Maximum = chart1_y_max + 100;

            int chart2_y_max = 0;
            for(int i = 0; i < chart2.Series[0].Points.Count; i++)
            {
                if(chart2_y_max < (int)chart2.Series[0].Points[i].YValues[0])
                {
                    chart2_y_max = (int)chart2.Series[0].Points[i].YValues[0];
                }
            }
            chart2.ChartAreas[0].AxisY.Maximum = chart2_y_max + 10;

            x_pos++;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string path = "./output.csv";

            FileStream fs = new FileStream(path, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);

            for(int i = 0; i < listView1.Items.Count; i++)
            {
                sw.Write(listView1.Items[i].SubItems[0].Text);
                sw.Write(",");
                sw.Write(listView1.Items[i].SubItems[1].Text);
                sw.Write(",");
                sw.WriteLine(listView1.Items[i].SubItems[2].Text);
            }

            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();
        }
    }
}
