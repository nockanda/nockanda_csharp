﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Xml;

namespace example103
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //Nockanda_key nk = new Nockanda_key();
            //string yourkey = nk.potal_key;

            string yourkey = textBox1.Text;
            string date = DateTime.Now.ToString("yyyy-MM-dd");
            
            
            string query = "http://apis.data.go.kr/B500001/rwis/waterQuality/list?serviceKey="+ yourkey + "&stDt="+ date + "&stTm=00&edDt="+ date + "&edTm=24&sujCode="+textBox2.Text+"&liIndDiv=1&numOfRows=24";
            //string query = "http://apis.data.go.kr/B500001/rwis/waterQuality/list?serviceKey="+yourkey+"&stDt=2021-02-25&stTm=00&edDt=2021-02-25&edTm=24&sujCode=382&liIndDiv=1";
            
            
            WebRequest wr = WebRequest.Create(query);
            wr.Method = "GET";
            WebResponse wrs = wr.GetResponse();
            Stream st = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(st);
            string response = sr.ReadToEnd();

            
            //string response = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><response><header><resultCode>00</resultCode><resultMsg>NORMAL SERVICE.</resultMsg></header><body><items><item><clUnit>mg/L</clUnit><clVal>0.5178</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>20</no><occrrncDt>2021022520</occrrncDt><phUnit>pH</phUnit><phVal>6.9560</phVal><tbUnit>NTU</tbUnit><tbVal>0.0551</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5147</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>19</no><occrrncDt>2021022519</occrrncDt><phUnit>pH</phUnit><phVal>6.9589</phVal><tbUnit>NTU</tbUnit><tbVal>0.0548</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5185</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>18</no><occrrncDt>2021022518</occrrncDt><phUnit>pH</phUnit><phVal>6.9630</phVal><tbUnit>NTU</tbUnit><tbVal>0.0542</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5190</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>17</no><occrrncDt>2021022517</occrrncDt><phUnit>pH</phUnit><phVal>6.9703</phVal><tbUnit>NTU</tbUnit><tbVal>0.0529</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5212</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>16</no><occrrncDt>2021022516</occrrncDt><phUnit>pH</phUnit><phVal>6.9787</phVal><tbUnit>NTU</tbUnit><tbVal>0.0531</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5208</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>15</no><occrrncDt>2021022515</occrrncDt><phUnit>pH</phUnit><phVal>6.9847</phVal><tbUnit>NTU</tbUnit><tbVal>0.0527</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5166</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>14</no><occrrncDt>2021022514</occrrncDt><phUnit>pH</phUnit><phVal>6.9875</phVal><tbUnit>NTU</tbUnit><tbVal>0.0528</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5205</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>13</no><occrrncDt>2021022513</occrrncDt><phUnit>pH</phUnit><phVal>6.9906</phVal><tbUnit>NTU</tbUnit><tbVal>0.0531</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5170</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>12</no><occrrncDt>2021022512</occrrncDt><phUnit>pH</phUnit><phVal>6.9996</phVal><tbUnit>NTU</tbUnit><tbVal>0.0532</tbVal></item><item><clUnit>mg/L</clUnit><clVal>0.5180</clVal><fcltyAddr>경남 양산시 상북면</fcltyAddr><fcltyMngNm>양산정수장</fcltyMngNm><fcltyMngNo>4833012382</fcltyMngNo><liIndDivName>생활정수</liIndDivName><no>11</no><occrrncDt>2021022511</occrrncDt><phUnit>pH</phUnit><phVal>7.0035</phVal><tbUnit>NTU</tbUnit><tbVal>0.0536</tbVal></item></items><numOfRows>10</numOfRows><pageNo>1</pageNo><totalCount>20</totalCount></body></response>";

            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["response"]["body"]["items"];

            label3.Text = "시설관리명 : " + xn.ChildNodes[0]["fcltyMngNm"].InnerText;
            label4.Text = "시설주소 : " + xn.ChildNodes[0]["fcltyAddr"].InnerText;

            Chart[] nockanda_chart = { chart1, chart2, chart3 };
            string[] nockanda_field = {"clVal","phVal","tbVal" };
           
            for (int j = 0; j < nockanda_chart.Length; j++)
            {

                //원래있던 데이터셋과 축의 값을 지우고 시작해보자!
                nockanda_chart[j].Series.Clear();
                nockanda_chart[j].ChartAreas.Clear();

                Series s = new Series();
                s.ChartType = SeriesChartType.Line;
                //s.IsValueShownAsLabel = true;
                s.IsVisibleInLegend = false;
                ChartArea ca = new ChartArea();
                ca.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None;
                ca.AxisX.LabelStyle.Angle = 30;
                CustomLabel[] cl = new CustomLabel[xn.ChildNodes.Count];


                for (int i = 0; i < xn.ChildNodes.Count; i++)
                {
                    string data = xn.ChildNodes[(xn.ChildNodes.Count - 1) - i][nockanda_field[j]].InnerText;
                    double clVal = 0;
                    if (data != "점검중")
                    {
                        clVal = double.Parse(data);
                    }
                    
                    s.Points.AddXY(i + 1, clVal);
                    //clVal
                    //richTextBox1.Text += xn.ChildNodes[i]["occrrncDt"].InnerText + "\n";

                    cl[i] = new CustomLabel();
                    cl[i].Text = xn.ChildNodes[(xn.ChildNodes.Count - 1) - i]["occrrncDt"].InnerText;
                    cl[i].ToPosition = i;
                    cl[i].FromPosition = i + 2;

                    ca.AxisX.CustomLabels.Add(cl[i]);
                }

                nockanda_chart[j].ChartAreas.Add(ca);
                nockanda_chart[j].Series.Add(s);
            }
            
        }
    }
}
