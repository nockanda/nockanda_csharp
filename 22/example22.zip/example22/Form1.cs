﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        int[] led_state = new int[8]; //아두이노 LED의 점멸상태
        Button[] mybutton = new Button[8];
        private void button3_Click(object sender, EventArgs e)
        {
            int button_num = 1;
            if (serialPort1.IsOpen)
            {
                if(led_state[button_num-1] == 0)
                {
                    //꺼진상태
                    
                    serialPort1.WriteLine(button_num+" 1");
                    
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num+" 2");
                    
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int button_num = 2;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    //led_state[button_num - 1] = 1;
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    //led_state[button_num - 1] = 0;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int button_num = 3;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    //led_state[button_num - 1] = 1;
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    //led_state[button_num - 1] = 0;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int button_num = 4;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    //led_state[button_num - 1] = 1;
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    //led_state[button_num - 1] = 0;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int button_num = 5;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    //led_state[button_num - 1] = 1;
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    //led_state[button_num - 1] = 0;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int button_num = 6;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    //led_state[button_num - 1] = 1;
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    //led_state[button_num - 1] = 0;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int button_num = 7;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    //led_state[button_num - 1] = 1;
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    //led_state[button_num - 1] = 0;
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int button_num = 8;
            if (serialPort1.IsOpen)
            {
                if (led_state[button_num - 1] == 0)
                {
                    //꺼진상태
                    serialPort1.WriteLine(button_num + " 1");
                    
                }
                else
                {
                    //켜진상태
                    serialPort1.WriteLine(button_num + " 2");
                    
                }
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //0,0,0,0....
                string data = serialPort1.ReadLine();
                string[] data_split = data.Split(',');

                
                for(int i = 0; i < data_split.Length -1; i++)
                {
                    led_state[i] = int.Parse(data_split[i]);
                    
                    if(led_state[i] == 0)
                    {
                        //LED가 꺼진상태
                        mybutton[i].BackColor = SystemColors.Control;
                    }
                    else
                    {
                        //LED가 켜진상태
                        mybutton[i].BackColor = Color.Red;
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mybutton[0] = button3;
            mybutton[1] = button4;
            mybutton[2] = button5;
            mybutton[3] = button6;
            mybutton[4] = button7;
            mybutton[5] = button8;
            mybutton[6] = button9;
            mybutton[7] = button10;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //00000000
            string data = listBox1.SelectedItem.ToString();
            richTextBox1.Text = "";
            for (int i = 0; i < data.Length; i++)
            {
                richTextBox1.Text += data[i] + "\n";
                if (data[i] == '0')
                {
                    //LED를 끄라고 명령해야함
                    serialPort1.WriteLine((i + 1) + " 2");
                }
                else
                {
                    //LED를 켜라고 명령해야함
                    serialPort1.WriteLine((i + 1) + " 1");
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            
        }

        int seq = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            string data = listBox1.Items[seq].ToString();
            richTextBox1.Text = "";
            for (int i = 0; i < data.Length; i++)
            {
                richTextBox1.Text += data[i] + "\n";
                if (data[i] == '0')
                {
                    //LED를 끄라고 명령해야함
                    serialPort1.WriteLine((i + 1) + " 2");
                }
                else
                {
                    //LED를 켜라고 명령해야함
                    serialPort1.WriteLine((i + 1) + " 1");
                }
            }

            seq++;
            if(listBox1.Items.Count-1 < seq)
            {
                seq = 0;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
                timer1.Start();
            }
        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Stop();
            }
        }
    }
}
