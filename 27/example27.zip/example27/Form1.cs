﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example27
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy != true)
            {
                byte[] send = new byte[2];
                send[0] = (byte)(int.Parse(textBox2.Text) / 256);
                send[1] = (byte)(int.Parse(textBox2.Text) % 256);

                serialPort1.Write(send, 0, 2);
                isbusy = true;
                listBox1.Items.Add(textBox2.Text);
            }
        }
        bool isbusy = false;
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[2];
                serialPort1.Read(recv, 0, 2);
                isbusy = false;
                int data = (recv[0] * 256) + recv[1];
                data = data - 360;
                richTextBox1.Text += data.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy != true)
            {
                byte[] send = new byte[2];
                send[0] = (byte)((2048 + 32) / 256);
                send[1] = (byte)((2048 + 32) % 256);

                serialPort1.Write(send, 0, 2);
                isbusy = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy != true)
            {
                byte[] send = new byte[2];
                send[0] = (byte)((2048 - 32) / 256);
                send[1] = (byte)((2048 - 32) % 256);

                serialPort1.Write(send, 0, 2);
                isbusy = true;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex != -1 && isbusy != true)
            {
                byte[] send = new byte[2];
                int data = int.Parse(listBox1.SelectedItem.ToString());
                send[0] = (byte)(data / 256);
                send[1] = (byte)(data % 256);

                serialPort1.Write(send, 0, 2);
                isbusy = true;
            }
        }
    }
}
