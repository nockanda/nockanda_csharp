﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] output = new byte[2];
                int temp = int.Parse(textBox2.Text);
                output[0] = (byte)(temp / 256);
                output[1] = (byte)(temp % 256);

                serialPort1.Write(output, 0, 2);

            }
        }

        Button[] mybuttons = new Button[8];

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                /* 23-1번 예제
                byte[] input = new byte[2];
                serialPort1.Read(input, 0, 2);
                int value = input[0] * 256 + input[1];
                */
                /*
                // 23-2번 예제
                richTextBox1.Text = "";
                byte[] input = new byte[8];
                serialPort1.Read(input, 0, 8);
                for(int i = 0; i < input.Length; i++)
                {
                    //
                    if(input[i] == 1)
                    {
                        //안눌려짐
                        mybuttons[i].BackColor = SystemColors.Control;
                    }
                    else
                    {
                        //눌려짐
                        mybuttons[i].BackColor = Color.Red;
                    }
                    richTextBox1.Text += input[i];
                }
                richTextBox1.Text += "\n";    
                */
                //24번예제
                richTextBox1.Text = "";
                byte[] input = new byte[1];
                serialPort1.Read(input, 0, 1);
                for (int i = 0; i < 8; i++)
                {
                    
                    if((~input[0] & (1 << i)) == (1 << i))
                    {
                        //눌려진녀석
                        mybuttons[i].BackColor = Color.Red;
                    }
                    else
                    {
                        //안눌려짐
                        mybuttons[i].BackColor = SystemColors.Control;
                    }
                }

                richTextBox1.Text += input[0]+"\n";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mybuttons[0] = button4;
            mybuttons[1] = button5;
            mybuttons[2] = button6;
            mybuttons[3] = button7;
            mybuttons[4] = button8;
            mybuttons[5] = button9;
            mybuttons[6] = button10;
            mybuttons[7] = button11;

        }
    }
}
