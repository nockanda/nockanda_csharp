﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Bitmap bitmap = new Bitmap();
        //Bitmap img1 = new Bitmap(@"img/2020-05-18 18-00-33.mp4_001676066.png");
        //Bitmap img2 = new Bitmap(@"img/2020-05-18 20-09-12.mp4_000054066.png");
        //Bitmap img3 = new Bitmap(@"img/2020-05-18 21-22-20.mp4_004315133.png");
        int position = 0;
        Bitmap[] img = new Bitmap[15]; //이미지 리스트
        

        private void Form1_Load(object sender, EventArgs e)
        {
            
            //imageList1.Images.Count
            for(int i = 0; i < img.Length; i++)
            {
                //(i+1).png
                img[i] = new Bitmap(@"img2/" + (i + 1) + ".png");
                listBox1.Items.Add(@"img2/" + (i + 1) + ".png");
                ListViewItem lvi = new ListViewItem();
                
                lvi.Text = @"img2/" + (i + 1) + ".png";
                lvi.SubItems.Add(img[i].Width.ToString());
                lvi.SubItems.Add(img[i].Height.ToString());
                listView1.Items.Add(lvi);
            }
            pictureBox1.Image = img[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //img의 넘버는 0~14 ...해서 총 15개
            if(position >= 14)
            {
                position = 0;
            }
            else
            {
                position++;
            }
            pictureBox1.Image = img[position];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //img의 넘버는 0~14 ...해서 총 15개
            if (position <= 0)
            {
                position = 14;
            }
            else
            {
                position--;
            }
            pictureBox1.Image = img[position];
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex != -1)
            {
                //listbox 0 1 2 3 4 ..... 14 총(15개)
                //img 0 1 2 3 4 .... 14 총(15개)
                pictureBox1.Image = img[listBox1.SelectedIndex];
                //pictureBox1.Image = new Bitmap(listBox1.Items[listBox1.SelectedIndex].ToString());
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count == 1)
            {
                //listView1.SelectedItems[0]
                //MessageBox.Show(listView1.SelectedIndices[0].ToString());
                pictureBox1.Image = img[listView1.SelectedIndices[0]];
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
            }else if (radioButton2.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else if (radioButton3.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (radioButton4.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            }
            else if (radioButton5.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }
    }
}

