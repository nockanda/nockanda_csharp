﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int mnum = 63; //독약의 번호(1~100사이)
        CheckBox[] case2toggi = new CheckBox[20];
        Label[] case3toggi = new Label[7];
        
        private void button1_Click(object sender, EventArgs e)
        {
            Random rd = new Random();
            mnum = rd.Next(1, 101); //1~100
            //case1
            label1.Text = mnum.ToString() + "번째 토끼가 죽었습니다..";
            //case2
            //checklistbox 0~19
            //0~9 1~10번토끼 //10~19 11~20번토끼
            for(int i = 0;i< case2toggi.Length; i++)
            {
                case2toggi[i].Checked = false;
            }
            case2toggi[((mnum-1) / 10)].Checked = true;
            case2toggi[10+(mnum % 10)].Checked = true;

            //case3
            //1011000  = 88
            for(int i =0;i< case3toggi.Length; i++)
            {
                case3toggi[i].BackColor = SystemColors.Control;
            }

            if ((mnum & 1) == 1) //0000001
            {
                case3toggi[0].BackColor = Color.Red;
            }
            if ((mnum & 2) == 2) //0000010
            {
                case3toggi[1].BackColor = Color.Red;
            }
            if ((mnum & 4) == 4) //0000100
            {
                case3toggi[2].BackColor = Color.Red;
            }
            if ((mnum & 8) == 8) //0001000
            {
                case3toggi[3].BackColor = Color.Red;
            }
            if ((mnum & 16) == 16) //0010000
            {
                case3toggi[4].BackColor = Color.Red;
            }
            if ((mnum & 32) == 32) //0100000
            {
                case3toggi[5].BackColor = Color.Red;
            }
            if ((mnum & 64) == 64) //1000000
            {
                case3toggi[6].BackColor = Color.Red;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //1~10번토끼
            case2toggi[0] = checkBox1;
            case2toggi[1] = checkBox2;
            case2toggi[2] = checkBox3;
            case2toggi[3] = checkBox4;
            case2toggi[4] = checkBox5;
            case2toggi[5] = checkBox6;
            case2toggi[6] = checkBox7;
            case2toggi[7] = checkBox8;
            case2toggi[8] = checkBox9;
            case2toggi[9] = checkBox10;
            //11~20번토끼
            case2toggi[10] = checkBox20; //1
            case2toggi[11] = checkBox19;
            case2toggi[12] = checkBox18;
            case2toggi[13] = checkBox17;
            case2toggi[14] = checkBox16;
            case2toggi[15] = checkBox15;
            case2toggi[16] = checkBox14;
            case2toggi[17] = checkBox13;
            case2toggi[18] = checkBox12;
            case2toggi[19] = checkBox11; //0

            case3toggi[0] = label2;
            case3toggi[1] = label3;
            case3toggi[2] = label4;
            case3toggi[3] = label5;
            case3toggi[4] = label6;
            case3toggi[5] = label7;
            case3toggi[6] = label8;
        }
    }
}
