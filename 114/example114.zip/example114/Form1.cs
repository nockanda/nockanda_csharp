﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example114
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string your_key = textBox1.Text;

            string query = "http://openAPI.seoul.go.kr:8088/" + your_key + "/xml/RealtimeCityAir/1/25/";

            WebRequest wr = WebRequest.Create(query);
            wr.Method = "GET";

            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            //richTextBox1.Text = response;

            //xml파싱!
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["RealtimeCityAir"];

            //권역명이 들어갈자리
            Label[] c1 = { label2, label10, label18, label26, label34, label42, label50, label58, label66, label74, label82, label90, label98, label106, label114, label122, label130, label138, label146, label154, label162, label170, label178, label186, label194 };
            //PM10
            Label[] c2 = { label3, label11, label19, label27, label35, label43, label51, label59, label67, label75, label83, label91, label99, label107, label115, label123, label131, label139, label147, label155, label163, label171, label179, label187, label195 };
            //PM23
            Label[] c3 = { label4, label12, label20, label28, label36, label44, label52, label60, label68, label76, label84, label92, label100, label108, label116, label124, label132, label140, label148, label156, label164, label172, label180, label188, label196 };
            //O3
            Label[] c4 = { label5, label13, label21, label29, label37, label45, label53, label61, label69, label77, label85, label93, label101, label109, label117, label125, label133, label141, label149, label157, label165, label173, label181, label189, label197 };
            //NO2
            Label[] c5 = { label6, label14, label22, label30, label38, label46, label54, label62, label70, label78, label86, label94, label102, label110, label118, label126, label134, label142, label150, label158, label166, label174, label182, label190, label198 };
            //Co
            Label[] c6 = { label7, label15, label23, label31, label39, label47, label55, label63, label71, label79, label87, label95, label103, label111, label119, label127, label135, label143, label151, label159, label167, label175, label183, label191, label199 };
            //So2
            Label[] c7 = { label8, label16, label24, label32, label40, label48, label56, label64, label72, label80, label88, label96, label104, label112, label120, label128, label136, label144, label152, label160, label168, label176, label184, label192, label200 };
            //IDEX_NM
            Label[] c8 = { label9, label17, label25, label33, label41, label49, label57, label65, label73, label81, label89, label97, label105, label113, label121, label129, label137, label145, label153, label161, label169, label177, label185, label193, label201 };
            for (int i = 2; i < xn.ChildNodes.Count; i++)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = xn.ChildNodes[i]["MSRSTE_NM"].InnerText;
                lvi.SubItems.Add(xn.ChildNodes[i]["PM10"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["PM25"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["O3"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["NO2"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["CO"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["SO2"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["IDEX_NM"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["IDEX_MVL"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["ARPLT_MAIN"].InnerText);

                listView1.Items.Add(lvi);


                //각각의 자리에 각각의 데이터를 레이블에 집어넣는다!
                c1[i - 2].Text = "권역명: "+xn.ChildNodes[i]["MSRSTE_NM"].InnerText;
                c2[i - 2].Text = "PM10: " + xn.ChildNodes[i]["PM10"].InnerText + "㎍/㎥";
                c3[i - 2].Text = "PM25: " + xn.ChildNodes[i]["PM25"].InnerText + "㎍/㎥";
                c4[i - 2].Text = "O3: "+xn.ChildNodes[i]["O3"].InnerText + "PPM";
                c5[i - 2].Text = "NO2: " + xn.ChildNodes[i]["NO2"].InnerText + "PPM";
                c6[i - 2].Text = "CO: " + xn.ChildNodes[i]["CO"].InnerText + "PPM";
                c7[i - 2].Text = "SO2: " + xn.ChildNodes[i]["SO2"].InnerText + "PPM";
                c8[i - 2].Text = "통합등급: " + xn.ChildNodes[i]["IDEX_NM"].InnerText;
            }
        }

    }
}
