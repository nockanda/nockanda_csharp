﻿namespace example114
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label170 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label178 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(228, 14);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(383, 25);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(18, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "인증키입력";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(617, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 36);
            this.button1.TabIndex = 2;
            this.button1.Text = "Request";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.listView1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(203, 743);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1065, 211);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "측정소명";
            this.columnHeader1.Width = 143;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "PM10";
            this.columnHeader2.Width = 112;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "PM25";
            this.columnHeader3.Width = 97;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "O3";
            this.columnHeader4.Width = 77;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "NO2";
            this.columnHeader5.Width = 94;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "CO";
            this.columnHeader6.Width = 100;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "SO2";
            this.columnHeader7.Width = 103;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "통합대기환경등급";
            this.columnHeader8.Width = 137;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "통합대기환경지수";
            this.columnHeader9.Width = 98;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "지수결정물질";
            this.columnHeader10.Width = 79;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel1.Location = new System.Drawing.Point(32, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(165, 215);
            this.panel1.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(19, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 20);
            this.label9.TabIndex = 7;
            this.label9.Text = "label9";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(19, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "label8";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(19, 138);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(19, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(19, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(19, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(19, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "label3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(19, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "label2";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel2.Location = new System.Drawing.Point(203, 76);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(165, 215);
            this.panel2.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(19, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 20);
            this.label10.TabIndex = 7;
            this.label10.Text = "label10";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(19, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 20);
            this.label11.TabIndex = 6;
            this.label11.Text = "label11";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(19, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 20);
            this.label12.TabIndex = 5;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(19, 94);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "label13";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(19, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 20);
            this.label14.TabIndex = 3;
            this.label14.Text = "label14";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(19, 142);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 20);
            this.label15.TabIndex = 2;
            this.label15.Text = "label15";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(19, 166);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 20);
            this.label16.TabIndex = 1;
            this.label16.Text = "label16";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(19, 190);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 20);
            this.label17.TabIndex = 0;
            this.label17.Text = "label17";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel3.Location = new System.Drawing.Point(374, 76);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(165, 215);
            this.panel3.TabIndex = 9;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(19, 13);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 20);
            this.label18.TabIndex = 7;
            this.label18.Text = "label18";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.Location = new System.Drawing.Point(19, 42);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 20);
            this.label19.TabIndex = 6;
            this.label19.Text = "label19";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(19, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(68, 20);
            this.label20.TabIndex = 5;
            this.label20.Text = "label20";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.Location = new System.Drawing.Point(19, 94);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 20);
            this.label21.TabIndex = 4;
            this.label21.Text = "label21";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(19, 118);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 20);
            this.label22.TabIndex = 3;
            this.label22.Text = "label22";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(19, 142);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 20);
            this.label23.TabIndex = 2;
            this.label23.Text = "label23";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.Location = new System.Drawing.Point(19, 166);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(68, 20);
            this.label24.TabIndex = 1;
            this.label24.Text = "label24";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.Location = new System.Drawing.Point(19, 190);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(68, 20);
            this.label25.TabIndex = 0;
            this.label25.Text = "label25";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.label29);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label33);
            this.panel4.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel4.Location = new System.Drawing.Point(545, 76);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(165, 215);
            this.panel4.TabIndex = 10;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.Location = new System.Drawing.Point(19, 13);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(68, 20);
            this.label26.TabIndex = 7;
            this.label26.Text = "label26";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.Location = new System.Drawing.Point(19, 42);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(68, 20);
            this.label27.TabIndex = 6;
            this.label27.Text = "label27";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label28.Location = new System.Drawing.Point(19, 70);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(68, 20);
            this.label28.TabIndex = 5;
            this.label28.Text = "label28";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label29.Location = new System.Drawing.Point(19, 94);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(68, 20);
            this.label29.TabIndex = 4;
            this.label29.Text = "label29";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label30.Location = new System.Drawing.Point(19, 118);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(68, 20);
            this.label30.TabIndex = 3;
            this.label30.Text = "label30";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label31.Location = new System.Drawing.Point(19, 142);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(68, 20);
            this.label31.TabIndex = 2;
            this.label31.Text = "label31";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label32.Location = new System.Drawing.Point(19, 166);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(68, 20);
            this.label32.TabIndex = 1;
            this.label32.Text = "label32";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label33.Location = new System.Drawing.Point(19, 190);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(68, 20);
            this.label33.TabIndex = 0;
            this.label33.Text = "label33";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label36);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Controls.Add(this.label38);
            this.panel5.Controls.Add(this.label39);
            this.panel5.Controls.Add(this.label40);
            this.panel5.Controls.Add(this.label41);
            this.panel5.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel5.Location = new System.Drawing.Point(716, 76);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(165, 215);
            this.panel5.TabIndex = 10;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label34.Location = new System.Drawing.Point(19, 13);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(68, 20);
            this.label34.TabIndex = 7;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label35.Location = new System.Drawing.Point(19, 42);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(68, 20);
            this.label35.TabIndex = 6;
            this.label35.Text = "label35";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label36.Location = new System.Drawing.Point(19, 70);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(68, 20);
            this.label36.TabIndex = 5;
            this.label36.Text = "label36";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label37.Location = new System.Drawing.Point(19, 94);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(68, 20);
            this.label37.TabIndex = 4;
            this.label37.Text = "label37";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label38.Location = new System.Drawing.Point(19, 118);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(68, 20);
            this.label38.TabIndex = 3;
            this.label38.Text = "label38";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label39.Location = new System.Drawing.Point(19, 142);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(68, 20);
            this.label39.TabIndex = 2;
            this.label39.Text = "label39";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label40.Location = new System.Drawing.Point(19, 166);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 20);
            this.label40.TabIndex = 1;
            this.label40.Text = "label40";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label41.Location = new System.Drawing.Point(19, 190);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 20);
            this.label41.TabIndex = 0;
            this.label41.Text = "label41";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label42);
            this.panel6.Controls.Add(this.label43);
            this.panel6.Controls.Add(this.label44);
            this.panel6.Controls.Add(this.label45);
            this.panel6.Controls.Add(this.label46);
            this.panel6.Controls.Add(this.label47);
            this.panel6.Controls.Add(this.label48);
            this.panel6.Controls.Add(this.label49);
            this.panel6.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel6.Location = new System.Drawing.Point(887, 76);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(165, 215);
            this.panel6.TabIndex = 10;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label42.Location = new System.Drawing.Point(19, 13);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(68, 20);
            this.label42.TabIndex = 7;
            this.label42.Text = "label42";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label43.Location = new System.Drawing.Point(19, 42);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(68, 20);
            this.label43.TabIndex = 6;
            this.label43.Text = "label43";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label44.Location = new System.Drawing.Point(19, 70);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 20);
            this.label44.TabIndex = 5;
            this.label44.Text = "label44";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label45.Location = new System.Drawing.Point(19, 94);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(68, 20);
            this.label45.TabIndex = 4;
            this.label45.Text = "label45";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label46.Location = new System.Drawing.Point(19, 118);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(68, 20);
            this.label46.TabIndex = 3;
            this.label46.Text = "label46";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label47.Location = new System.Drawing.Point(19, 142);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(68, 20);
            this.label47.TabIndex = 2;
            this.label47.Text = "label47";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label48.Location = new System.Drawing.Point(19, 166);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(68, 20);
            this.label48.TabIndex = 1;
            this.label48.Text = "label48";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label49.Location = new System.Drawing.Point(19, 190);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(68, 20);
            this.label49.TabIndex = 0;
            this.label49.Text = "label49";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label50);
            this.panel7.Controls.Add(this.label51);
            this.panel7.Controls.Add(this.label52);
            this.panel7.Controls.Add(this.label53);
            this.panel7.Controls.Add(this.label54);
            this.panel7.Controls.Add(this.label55);
            this.panel7.Controls.Add(this.label56);
            this.panel7.Controls.Add(this.label57);
            this.panel7.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel7.Location = new System.Drawing.Point(1058, 76);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(165, 215);
            this.panel7.TabIndex = 10;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label50.Location = new System.Drawing.Point(19, 13);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(68, 20);
            this.label50.TabIndex = 7;
            this.label50.Text = "label50";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label51.Location = new System.Drawing.Point(19, 42);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(68, 20);
            this.label51.TabIndex = 6;
            this.label51.Text = "label51";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label52.Location = new System.Drawing.Point(19, 70);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(68, 20);
            this.label52.TabIndex = 5;
            this.label52.Text = "label52";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label53.Location = new System.Drawing.Point(19, 94);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(68, 20);
            this.label53.TabIndex = 4;
            this.label53.Text = "label53";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label54.Location = new System.Drawing.Point(19, 118);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(68, 20);
            this.label54.TabIndex = 3;
            this.label54.Text = "label54";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label55.Location = new System.Drawing.Point(19, 142);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(68, 20);
            this.label55.TabIndex = 2;
            this.label55.Text = "label55";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label56.Location = new System.Drawing.Point(19, 166);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(68, 20);
            this.label56.TabIndex = 1;
            this.label56.Text = "label56";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label57.Location = new System.Drawing.Point(19, 190);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(68, 20);
            this.label57.TabIndex = 0;
            this.label57.Text = "label57";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label58);
            this.panel8.Controls.Add(this.label59);
            this.panel8.Controls.Add(this.label60);
            this.panel8.Controls.Add(this.label61);
            this.panel8.Controls.Add(this.label62);
            this.panel8.Controls.Add(this.label63);
            this.panel8.Controls.Add(this.label64);
            this.panel8.Controls.Add(this.label65);
            this.panel8.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel8.Location = new System.Drawing.Point(1229, 76);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(165, 215);
            this.panel8.TabIndex = 10;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label58.Location = new System.Drawing.Point(19, 13);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(68, 20);
            this.label58.TabIndex = 7;
            this.label58.Text = "label58";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label59.Location = new System.Drawing.Point(19, 42);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(68, 20);
            this.label59.TabIndex = 6;
            this.label59.Text = "label59";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label60.Location = new System.Drawing.Point(19, 70);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(68, 20);
            this.label60.TabIndex = 5;
            this.label60.Text = "label60";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label61.Location = new System.Drawing.Point(19, 94);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(68, 20);
            this.label61.TabIndex = 4;
            this.label61.Text = "label61";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label62.Location = new System.Drawing.Point(19, 118);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(68, 20);
            this.label62.TabIndex = 3;
            this.label62.Text = "label62";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label63.Location = new System.Drawing.Point(19, 142);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(68, 20);
            this.label63.TabIndex = 2;
            this.label63.Text = "label63";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label64.Location = new System.Drawing.Point(19, 166);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(68, 20);
            this.label64.TabIndex = 1;
            this.label64.Text = "label64";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label65.Location = new System.Drawing.Point(19, 190);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(68, 20);
            this.label65.TabIndex = 0;
            this.label65.Text = "label65";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label66);
            this.panel9.Controls.Add(this.label67);
            this.panel9.Controls.Add(this.label68);
            this.panel9.Controls.Add(this.label69);
            this.panel9.Controls.Add(this.label70);
            this.panel9.Controls.Add(this.label71);
            this.panel9.Controls.Add(this.label72);
            this.panel9.Controls.Add(this.label73);
            this.panel9.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel9.Location = new System.Drawing.Point(32, 297);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(165, 215);
            this.panel9.TabIndex = 10;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label66.Location = new System.Drawing.Point(19, 13);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(68, 20);
            this.label66.TabIndex = 7;
            this.label66.Text = "label66";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label67.Location = new System.Drawing.Point(19, 42);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(68, 20);
            this.label67.TabIndex = 6;
            this.label67.Text = "label67";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label68.Location = new System.Drawing.Point(19, 70);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(68, 20);
            this.label68.TabIndex = 5;
            this.label68.Text = "label68";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label69.Location = new System.Drawing.Point(19, 94);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(68, 20);
            this.label69.TabIndex = 4;
            this.label69.Text = "label69";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label70.Location = new System.Drawing.Point(19, 118);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(68, 20);
            this.label70.TabIndex = 3;
            this.label70.Text = "label70";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label71.Location = new System.Drawing.Point(19, 142);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(68, 20);
            this.label71.TabIndex = 2;
            this.label71.Text = "label71";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label72.Location = new System.Drawing.Point(19, 166);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(68, 20);
            this.label72.TabIndex = 1;
            this.label72.Text = "label72";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label73.Location = new System.Drawing.Point(19, 190);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(68, 20);
            this.label73.TabIndex = 0;
            this.label73.Text = "label73";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label74);
            this.panel10.Controls.Add(this.label75);
            this.panel10.Controls.Add(this.label76);
            this.panel10.Controls.Add(this.label77);
            this.panel10.Controls.Add(this.label78);
            this.panel10.Controls.Add(this.label79);
            this.panel10.Controls.Add(this.label80);
            this.panel10.Controls.Add(this.label81);
            this.panel10.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel10.Location = new System.Drawing.Point(203, 297);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(165, 215);
            this.panel10.TabIndex = 10;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label74.Location = new System.Drawing.Point(19, 13);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(68, 20);
            this.label74.TabIndex = 7;
            this.label74.Text = "label74";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label75.Location = new System.Drawing.Point(19, 42);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(68, 20);
            this.label75.TabIndex = 6;
            this.label75.Text = "label75";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label76.Location = new System.Drawing.Point(19, 70);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(68, 20);
            this.label76.TabIndex = 5;
            this.label76.Text = "label76";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label77.Location = new System.Drawing.Point(19, 94);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(68, 20);
            this.label77.TabIndex = 4;
            this.label77.Text = "label77";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label78.Location = new System.Drawing.Point(19, 118);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(68, 20);
            this.label78.TabIndex = 3;
            this.label78.Text = "label78";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label79.Location = new System.Drawing.Point(19, 142);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(68, 20);
            this.label79.TabIndex = 2;
            this.label79.Text = "label79";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label80.Location = new System.Drawing.Point(19, 166);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(68, 20);
            this.label80.TabIndex = 1;
            this.label80.Text = "label80";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label81.Location = new System.Drawing.Point(19, 190);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(68, 20);
            this.label81.TabIndex = 0;
            this.label81.Text = "label81";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.label82);
            this.panel11.Controls.Add(this.label83);
            this.panel11.Controls.Add(this.label84);
            this.panel11.Controls.Add(this.label85);
            this.panel11.Controls.Add(this.label86);
            this.panel11.Controls.Add(this.label87);
            this.panel11.Controls.Add(this.label88);
            this.panel11.Controls.Add(this.label89);
            this.panel11.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel11.Location = new System.Drawing.Point(374, 297);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(165, 215);
            this.panel11.TabIndex = 10;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label82.Location = new System.Drawing.Point(19, 13);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(68, 20);
            this.label82.TabIndex = 7;
            this.label82.Text = "label82";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label83.Location = new System.Drawing.Point(19, 42);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(68, 20);
            this.label83.TabIndex = 6;
            this.label83.Text = "label83";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label84.Location = new System.Drawing.Point(19, 70);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(68, 20);
            this.label84.TabIndex = 5;
            this.label84.Text = "label84";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label85.Location = new System.Drawing.Point(19, 94);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(68, 20);
            this.label85.TabIndex = 4;
            this.label85.Text = "label85";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label86.Location = new System.Drawing.Point(19, 118);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(68, 20);
            this.label86.TabIndex = 3;
            this.label86.Text = "label86";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label87.Location = new System.Drawing.Point(19, 142);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(68, 20);
            this.label87.TabIndex = 2;
            this.label87.Text = "label87";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label88.Location = new System.Drawing.Point(19, 166);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(68, 20);
            this.label88.TabIndex = 1;
            this.label88.Text = "label88";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label89.Location = new System.Drawing.Point(19, 190);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(68, 20);
            this.label89.TabIndex = 0;
            this.label89.Text = "label89";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.label90);
            this.panel12.Controls.Add(this.label91);
            this.panel12.Controls.Add(this.label92);
            this.panel12.Controls.Add(this.label93);
            this.panel12.Controls.Add(this.label94);
            this.panel12.Controls.Add(this.label95);
            this.panel12.Controls.Add(this.label96);
            this.panel12.Controls.Add(this.label97);
            this.panel12.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel12.Location = new System.Drawing.Point(545, 297);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(165, 215);
            this.panel12.TabIndex = 10;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label90.Location = new System.Drawing.Point(19, 13);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(68, 20);
            this.label90.TabIndex = 7;
            this.label90.Text = "label90";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label91.Location = new System.Drawing.Point(19, 42);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(68, 20);
            this.label91.TabIndex = 6;
            this.label91.Text = "label91";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label92.Location = new System.Drawing.Point(19, 70);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(68, 20);
            this.label92.TabIndex = 5;
            this.label92.Text = "label92";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label93.Location = new System.Drawing.Point(19, 94);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(68, 20);
            this.label93.TabIndex = 4;
            this.label93.Text = "label93";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label94.Location = new System.Drawing.Point(19, 118);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(68, 20);
            this.label94.TabIndex = 3;
            this.label94.Text = "label94";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label95.Location = new System.Drawing.Point(19, 142);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(68, 20);
            this.label95.TabIndex = 2;
            this.label95.Text = "label95";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label96.Location = new System.Drawing.Point(19, 166);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(68, 20);
            this.label96.TabIndex = 1;
            this.label96.Text = "label96";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label97.Location = new System.Drawing.Point(19, 190);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(68, 20);
            this.label97.TabIndex = 0;
            this.label97.Text = "label97";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.label98);
            this.panel13.Controls.Add(this.label99);
            this.panel13.Controls.Add(this.label100);
            this.panel13.Controls.Add(this.label101);
            this.panel13.Controls.Add(this.label102);
            this.panel13.Controls.Add(this.label103);
            this.panel13.Controls.Add(this.label104);
            this.panel13.Controls.Add(this.label105);
            this.panel13.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel13.Location = new System.Drawing.Point(716, 297);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(165, 215);
            this.panel13.TabIndex = 10;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label98.Location = new System.Drawing.Point(19, 13);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(68, 20);
            this.label98.TabIndex = 7;
            this.label98.Text = "label98";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label99.Location = new System.Drawing.Point(19, 42);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(68, 20);
            this.label99.TabIndex = 6;
            this.label99.Text = "label99";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label100.Location = new System.Drawing.Point(19, 70);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(79, 20);
            this.label100.TabIndex = 5;
            this.label100.Text = "label100";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label101.Location = new System.Drawing.Point(19, 94);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(79, 20);
            this.label101.TabIndex = 4;
            this.label101.Text = "label101";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label102.Location = new System.Drawing.Point(19, 118);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(79, 20);
            this.label102.TabIndex = 3;
            this.label102.Text = "label102";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label103.Location = new System.Drawing.Point(19, 142);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(79, 20);
            this.label103.TabIndex = 2;
            this.label103.Text = "label103";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label104.Location = new System.Drawing.Point(19, 166);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(79, 20);
            this.label104.TabIndex = 1;
            this.label104.Text = "label104";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label105.Location = new System.Drawing.Point(19, 190);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(79, 20);
            this.label105.TabIndex = 0;
            this.label105.Text = "label105";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.label106);
            this.panel14.Controls.Add(this.label107);
            this.panel14.Controls.Add(this.label108);
            this.panel14.Controls.Add(this.label109);
            this.panel14.Controls.Add(this.label110);
            this.panel14.Controls.Add(this.label111);
            this.panel14.Controls.Add(this.label112);
            this.panel14.Controls.Add(this.label113);
            this.panel14.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel14.Location = new System.Drawing.Point(887, 297);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(165, 215);
            this.panel14.TabIndex = 10;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label106.Location = new System.Drawing.Point(19, 13);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(79, 20);
            this.label106.TabIndex = 7;
            this.label106.Text = "label106";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label107.Location = new System.Drawing.Point(19, 42);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(79, 20);
            this.label107.TabIndex = 6;
            this.label107.Text = "label107";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label108.Location = new System.Drawing.Point(19, 70);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(79, 20);
            this.label108.TabIndex = 5;
            this.label108.Text = "label108";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label109.Location = new System.Drawing.Point(19, 94);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(79, 20);
            this.label109.TabIndex = 4;
            this.label109.Text = "label109";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label110.Location = new System.Drawing.Point(19, 118);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(79, 20);
            this.label110.TabIndex = 3;
            this.label110.Text = "label110";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label111.Location = new System.Drawing.Point(19, 142);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(79, 20);
            this.label111.TabIndex = 2;
            this.label111.Text = "label111";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label112.Location = new System.Drawing.Point(19, 166);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(79, 20);
            this.label112.TabIndex = 1;
            this.label112.Text = "label112";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label113.Location = new System.Drawing.Point(19, 190);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(79, 20);
            this.label113.TabIndex = 0;
            this.label113.Text = "label113";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.label114);
            this.panel15.Controls.Add(this.label115);
            this.panel15.Controls.Add(this.label116);
            this.panel15.Controls.Add(this.label117);
            this.panel15.Controls.Add(this.label118);
            this.panel15.Controls.Add(this.label119);
            this.panel15.Controls.Add(this.label120);
            this.panel15.Controls.Add(this.label121);
            this.panel15.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel15.Location = new System.Drawing.Point(1058, 297);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(165, 215);
            this.panel15.TabIndex = 10;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label114.Location = new System.Drawing.Point(19, 13);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(79, 20);
            this.label114.TabIndex = 7;
            this.label114.Text = "label114";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label115.Location = new System.Drawing.Point(19, 42);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(79, 20);
            this.label115.TabIndex = 6;
            this.label115.Text = "label115";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label116.Location = new System.Drawing.Point(19, 70);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(79, 20);
            this.label116.TabIndex = 5;
            this.label116.Text = "label116";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label117.Location = new System.Drawing.Point(19, 94);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(79, 20);
            this.label117.TabIndex = 4;
            this.label117.Text = "label117";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label118.Location = new System.Drawing.Point(19, 118);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(79, 20);
            this.label118.TabIndex = 3;
            this.label118.Text = "label118";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label119.Location = new System.Drawing.Point(19, 142);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(79, 20);
            this.label119.TabIndex = 2;
            this.label119.Text = "label119";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label120.Location = new System.Drawing.Point(19, 166);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(79, 20);
            this.label120.TabIndex = 1;
            this.label120.Text = "label120";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label121.Location = new System.Drawing.Point(19, 190);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(79, 20);
            this.label121.TabIndex = 0;
            this.label121.Text = "label121";
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.label122);
            this.panel16.Controls.Add(this.label123);
            this.panel16.Controls.Add(this.label124);
            this.panel16.Controls.Add(this.label125);
            this.panel16.Controls.Add(this.label126);
            this.panel16.Controls.Add(this.label127);
            this.panel16.Controls.Add(this.label128);
            this.panel16.Controls.Add(this.label129);
            this.panel16.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel16.Location = new System.Drawing.Point(1229, 297);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(165, 215);
            this.panel16.TabIndex = 10;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label122.Location = new System.Drawing.Point(19, 13);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(79, 20);
            this.label122.TabIndex = 7;
            this.label122.Text = "label122";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label123.Location = new System.Drawing.Point(19, 42);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(79, 20);
            this.label123.TabIndex = 6;
            this.label123.Text = "label123";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label124.Location = new System.Drawing.Point(19, 70);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(79, 20);
            this.label124.TabIndex = 5;
            this.label124.Text = "label124";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label125.Location = new System.Drawing.Point(19, 94);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(79, 20);
            this.label125.TabIndex = 4;
            this.label125.Text = "label125";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label126.Location = new System.Drawing.Point(19, 118);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(79, 20);
            this.label126.TabIndex = 3;
            this.label126.Text = "label126";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label127.Location = new System.Drawing.Point(19, 142);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(79, 20);
            this.label127.TabIndex = 2;
            this.label127.Text = "label127";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label128.Location = new System.Drawing.Point(19, 166);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(79, 20);
            this.label128.TabIndex = 1;
            this.label128.Text = "label128";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label129.Location = new System.Drawing.Point(19, 190);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(79, 20);
            this.label129.TabIndex = 0;
            this.label129.Text = "label129";
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.label130);
            this.panel17.Controls.Add(this.label131);
            this.panel17.Controls.Add(this.label132);
            this.panel17.Controls.Add(this.label133);
            this.panel17.Controls.Add(this.label134);
            this.panel17.Controls.Add(this.label135);
            this.panel17.Controls.Add(this.label136);
            this.panel17.Controls.Add(this.label137);
            this.panel17.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel17.Location = new System.Drawing.Point(32, 518);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(165, 215);
            this.panel17.TabIndex = 10;
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label130.Location = new System.Drawing.Point(19, 13);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(79, 20);
            this.label130.TabIndex = 7;
            this.label130.Text = "label130";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label131.Location = new System.Drawing.Point(19, 42);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(79, 20);
            this.label131.TabIndex = 6;
            this.label131.Text = "label131";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label132.Location = new System.Drawing.Point(19, 70);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(79, 20);
            this.label132.TabIndex = 5;
            this.label132.Text = "label132";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label133.Location = new System.Drawing.Point(19, 94);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(79, 20);
            this.label133.TabIndex = 4;
            this.label133.Text = "label133";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label134.Location = new System.Drawing.Point(19, 118);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(79, 20);
            this.label134.TabIndex = 3;
            this.label134.Text = "label134";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label135.Location = new System.Drawing.Point(19, 142);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(79, 20);
            this.label135.TabIndex = 2;
            this.label135.Text = "label135";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label136.Location = new System.Drawing.Point(19, 166);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(79, 20);
            this.label136.TabIndex = 1;
            this.label136.Text = "label136";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label137.Location = new System.Drawing.Point(19, 190);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(79, 20);
            this.label137.TabIndex = 0;
            this.label137.Text = "label137";
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.label138);
            this.panel18.Controls.Add(this.label139);
            this.panel18.Controls.Add(this.label140);
            this.panel18.Controls.Add(this.label141);
            this.panel18.Controls.Add(this.label142);
            this.panel18.Controls.Add(this.label143);
            this.panel18.Controls.Add(this.label144);
            this.panel18.Controls.Add(this.label145);
            this.panel18.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel18.Location = new System.Drawing.Point(203, 518);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(165, 215);
            this.panel18.TabIndex = 10;
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label138.Location = new System.Drawing.Point(19, 13);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(79, 20);
            this.label138.TabIndex = 7;
            this.label138.Text = "label138";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label139.Location = new System.Drawing.Point(19, 42);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(79, 20);
            this.label139.TabIndex = 6;
            this.label139.Text = "label139";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label140.Location = new System.Drawing.Point(19, 70);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(79, 20);
            this.label140.TabIndex = 5;
            this.label140.Text = "label140";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label141.Location = new System.Drawing.Point(19, 94);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(79, 20);
            this.label141.TabIndex = 4;
            this.label141.Text = "label141";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label142.Location = new System.Drawing.Point(19, 118);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(79, 20);
            this.label142.TabIndex = 3;
            this.label142.Text = "label142";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label143.Location = new System.Drawing.Point(19, 142);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(79, 20);
            this.label143.TabIndex = 2;
            this.label143.Text = "label143";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label144.Location = new System.Drawing.Point(19, 166);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(79, 20);
            this.label144.TabIndex = 1;
            this.label144.Text = "label144";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label145.Location = new System.Drawing.Point(19, 190);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(79, 20);
            this.label145.TabIndex = 0;
            this.label145.Text = "label145";
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.label146);
            this.panel19.Controls.Add(this.label147);
            this.panel19.Controls.Add(this.label148);
            this.panel19.Controls.Add(this.label149);
            this.panel19.Controls.Add(this.label150);
            this.panel19.Controls.Add(this.label151);
            this.panel19.Controls.Add(this.label152);
            this.panel19.Controls.Add(this.label153);
            this.panel19.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel19.Location = new System.Drawing.Point(374, 518);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(165, 215);
            this.panel19.TabIndex = 10;
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label146.Location = new System.Drawing.Point(19, 13);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(79, 20);
            this.label146.TabIndex = 7;
            this.label146.Text = "label146";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label147.Location = new System.Drawing.Point(19, 42);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(79, 20);
            this.label147.TabIndex = 6;
            this.label147.Text = "label147";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label148.Location = new System.Drawing.Point(19, 70);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(79, 20);
            this.label148.TabIndex = 5;
            this.label148.Text = "label148";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label149.Location = new System.Drawing.Point(19, 94);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(79, 20);
            this.label149.TabIndex = 4;
            this.label149.Text = "label149";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label150.Location = new System.Drawing.Point(19, 118);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(79, 20);
            this.label150.TabIndex = 3;
            this.label150.Text = "label150";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label151.Location = new System.Drawing.Point(19, 142);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(79, 20);
            this.label151.TabIndex = 2;
            this.label151.Text = "label151";
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label152.Location = new System.Drawing.Point(19, 166);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(79, 20);
            this.label152.TabIndex = 1;
            this.label152.Text = "label152";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label153.Location = new System.Drawing.Point(19, 190);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(79, 20);
            this.label153.TabIndex = 0;
            this.label153.Text = "label153";
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.label154);
            this.panel20.Controls.Add(this.label155);
            this.panel20.Controls.Add(this.label156);
            this.panel20.Controls.Add(this.label157);
            this.panel20.Controls.Add(this.label158);
            this.panel20.Controls.Add(this.label159);
            this.panel20.Controls.Add(this.label160);
            this.panel20.Controls.Add(this.label161);
            this.panel20.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel20.Location = new System.Drawing.Point(545, 518);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(165, 215);
            this.panel20.TabIndex = 10;
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label154.Location = new System.Drawing.Point(19, 13);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(79, 20);
            this.label154.TabIndex = 7;
            this.label154.Text = "label154";
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label155.Location = new System.Drawing.Point(19, 42);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(79, 20);
            this.label155.TabIndex = 6;
            this.label155.Text = "label155";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label156.Location = new System.Drawing.Point(19, 70);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(79, 20);
            this.label156.TabIndex = 5;
            this.label156.Text = "label156";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label157.Location = new System.Drawing.Point(19, 94);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(79, 20);
            this.label157.TabIndex = 4;
            this.label157.Text = "label157";
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label158.Location = new System.Drawing.Point(19, 118);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(79, 20);
            this.label158.TabIndex = 3;
            this.label158.Text = "label158";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label159.Location = new System.Drawing.Point(19, 142);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(79, 20);
            this.label159.TabIndex = 2;
            this.label159.Text = "label159";
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label160.Location = new System.Drawing.Point(19, 166);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(79, 20);
            this.label160.TabIndex = 1;
            this.label160.Text = "label160";
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label161.Location = new System.Drawing.Point(19, 190);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(79, 20);
            this.label161.TabIndex = 0;
            this.label161.Text = "label161";
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.label162);
            this.panel21.Controls.Add(this.label163);
            this.panel21.Controls.Add(this.label164);
            this.panel21.Controls.Add(this.label165);
            this.panel21.Controls.Add(this.label166);
            this.panel21.Controls.Add(this.label167);
            this.panel21.Controls.Add(this.label168);
            this.panel21.Controls.Add(this.label169);
            this.panel21.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel21.Location = new System.Drawing.Point(716, 518);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(165, 215);
            this.panel21.TabIndex = 10;
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label162.Location = new System.Drawing.Point(19, 13);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(79, 20);
            this.label162.TabIndex = 7;
            this.label162.Text = "label162";
            // 
            // label163
            // 
            this.label163.AutoSize = true;
            this.label163.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label163.Location = new System.Drawing.Point(19, 42);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(79, 20);
            this.label163.TabIndex = 6;
            this.label163.Text = "label163";
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label164.Location = new System.Drawing.Point(19, 70);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(79, 20);
            this.label164.TabIndex = 5;
            this.label164.Text = "label164";
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label165.Location = new System.Drawing.Point(19, 94);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(79, 20);
            this.label165.TabIndex = 4;
            this.label165.Text = "label165";
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label166.Location = new System.Drawing.Point(19, 118);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(79, 20);
            this.label166.TabIndex = 3;
            this.label166.Text = "label166";
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label167.Location = new System.Drawing.Point(19, 142);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(79, 20);
            this.label167.TabIndex = 2;
            this.label167.Text = "label167";
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label168.Location = new System.Drawing.Point(19, 166);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(79, 20);
            this.label168.TabIndex = 1;
            this.label168.Text = "label168";
            // 
            // label169
            // 
            this.label169.AutoSize = true;
            this.label169.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label169.Location = new System.Drawing.Point(19, 190);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(79, 20);
            this.label169.TabIndex = 0;
            this.label169.Text = "label169";
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.label170);
            this.panel22.Controls.Add(this.label171);
            this.panel22.Controls.Add(this.label172);
            this.panel22.Controls.Add(this.label173);
            this.panel22.Controls.Add(this.label174);
            this.panel22.Controls.Add(this.label175);
            this.panel22.Controls.Add(this.label176);
            this.panel22.Controls.Add(this.label177);
            this.panel22.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel22.Location = new System.Drawing.Point(887, 518);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(165, 215);
            this.panel22.TabIndex = 10;
            // 
            // label170
            // 
            this.label170.AutoSize = true;
            this.label170.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label170.Location = new System.Drawing.Point(19, 13);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(79, 20);
            this.label170.TabIndex = 7;
            this.label170.Text = "label170";
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label171.Location = new System.Drawing.Point(19, 42);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(79, 20);
            this.label171.TabIndex = 6;
            this.label171.Text = "label171";
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label172.Location = new System.Drawing.Point(19, 70);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(79, 20);
            this.label172.TabIndex = 5;
            this.label172.Text = "label172";
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label173.Location = new System.Drawing.Point(19, 94);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(79, 20);
            this.label173.TabIndex = 4;
            this.label173.Text = "label173";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label174.Location = new System.Drawing.Point(19, 118);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(79, 20);
            this.label174.TabIndex = 3;
            this.label174.Text = "label174";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label175.Location = new System.Drawing.Point(19, 142);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(79, 20);
            this.label175.TabIndex = 2;
            this.label175.Text = "label175";
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label176.Location = new System.Drawing.Point(19, 166);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(79, 20);
            this.label176.TabIndex = 1;
            this.label176.Text = "label176";
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label177.Location = new System.Drawing.Point(19, 190);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(79, 20);
            this.label177.TabIndex = 0;
            this.label177.Text = "label177";
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.label178);
            this.panel23.Controls.Add(this.label179);
            this.panel23.Controls.Add(this.label180);
            this.panel23.Controls.Add(this.label181);
            this.panel23.Controls.Add(this.label182);
            this.panel23.Controls.Add(this.label183);
            this.panel23.Controls.Add(this.label184);
            this.panel23.Controls.Add(this.label185);
            this.panel23.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel23.Location = new System.Drawing.Point(1058, 518);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(165, 215);
            this.panel23.TabIndex = 10;
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label178.Location = new System.Drawing.Point(19, 13);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(79, 20);
            this.label178.TabIndex = 7;
            this.label178.Text = "label178";
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label179.Location = new System.Drawing.Point(19, 42);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(79, 20);
            this.label179.TabIndex = 6;
            this.label179.Text = "label179";
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label180.Location = new System.Drawing.Point(19, 70);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(79, 20);
            this.label180.TabIndex = 5;
            this.label180.Text = "label180";
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label181.Location = new System.Drawing.Point(19, 94);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(79, 20);
            this.label181.TabIndex = 4;
            this.label181.Text = "label181";
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label182.Location = new System.Drawing.Point(19, 118);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(79, 20);
            this.label182.TabIndex = 3;
            this.label182.Text = "label182";
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label183.Location = new System.Drawing.Point(19, 142);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(79, 20);
            this.label183.TabIndex = 2;
            this.label183.Text = "label183";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label184.Location = new System.Drawing.Point(19, 166);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(79, 20);
            this.label184.TabIndex = 1;
            this.label184.Text = "label184";
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label185.Location = new System.Drawing.Point(19, 190);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(79, 20);
            this.label185.TabIndex = 0;
            this.label185.Text = "label185";
            // 
            // panel24
            // 
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.label186);
            this.panel24.Controls.Add(this.label187);
            this.panel24.Controls.Add(this.label188);
            this.panel24.Controls.Add(this.label189);
            this.panel24.Controls.Add(this.label190);
            this.panel24.Controls.Add(this.label191);
            this.panel24.Controls.Add(this.label192);
            this.panel24.Controls.Add(this.label193);
            this.panel24.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel24.Location = new System.Drawing.Point(1229, 518);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(165, 215);
            this.panel24.TabIndex = 10;
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label186.Location = new System.Drawing.Point(19, 13);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(79, 20);
            this.label186.TabIndex = 7;
            this.label186.Text = "label186";
            // 
            // label187
            // 
            this.label187.AutoSize = true;
            this.label187.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label187.Location = new System.Drawing.Point(19, 42);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(79, 20);
            this.label187.TabIndex = 6;
            this.label187.Text = "label187";
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label188.Location = new System.Drawing.Point(19, 70);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(79, 20);
            this.label188.TabIndex = 5;
            this.label188.Text = "label188";
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label189.Location = new System.Drawing.Point(19, 94);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(79, 20);
            this.label189.TabIndex = 4;
            this.label189.Text = "label189";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label190.Location = new System.Drawing.Point(19, 118);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(79, 20);
            this.label190.TabIndex = 3;
            this.label190.Text = "label190";
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label191.Location = new System.Drawing.Point(19, 142);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(79, 20);
            this.label191.TabIndex = 2;
            this.label191.Text = "label191";
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label192.Location = new System.Drawing.Point(19, 166);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(79, 20);
            this.label192.TabIndex = 1;
            this.label192.Text = "label192";
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label193.Location = new System.Drawing.Point(19, 190);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(79, 20);
            this.label193.TabIndex = 0;
            this.label193.Text = "label193";
            // 
            // panel25
            // 
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.label194);
            this.panel25.Controls.Add(this.label195);
            this.panel25.Controls.Add(this.label196);
            this.panel25.Controls.Add(this.label197);
            this.panel25.Controls.Add(this.label198);
            this.panel25.Controls.Add(this.label199);
            this.panel25.Controls.Add(this.label200);
            this.panel25.Controls.Add(this.label201);
            this.panel25.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel25.Location = new System.Drawing.Point(32, 739);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(165, 215);
            this.panel25.TabIndex = 11;
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label194.Location = new System.Drawing.Point(19, 13);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(79, 20);
            this.label194.TabIndex = 7;
            this.label194.Text = "label194";
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label195.Location = new System.Drawing.Point(19, 42);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(79, 20);
            this.label195.TabIndex = 6;
            this.label195.Text = "label195";
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label196.Location = new System.Drawing.Point(19, 70);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(79, 20);
            this.label196.TabIndex = 5;
            this.label196.Text = "label196";
            // 
            // label197
            // 
            this.label197.AutoSize = true;
            this.label197.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label197.Location = new System.Drawing.Point(19, 94);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(79, 20);
            this.label197.TabIndex = 4;
            this.label197.Text = "label197";
            // 
            // label198
            // 
            this.label198.AutoSize = true;
            this.label198.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label198.Location = new System.Drawing.Point(19, 118);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(79, 20);
            this.label198.TabIndex = 3;
            this.label198.Text = "label198";
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label199.Location = new System.Drawing.Point(19, 142);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(79, 20);
            this.label199.TabIndex = 2;
            this.label199.Text = "label199";
            // 
            // label200
            // 
            this.label200.AutoSize = true;
            this.label200.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label200.Location = new System.Drawing.Point(19, 166);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(79, 20);
            this.label200.TabIndex = 1;
            this.label200.Text = "label200";
            // 
            // label201
            // 
            this.label201.AutoSize = true;
            this.label201.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label201.Location = new System.Drawing.Point(19, 190);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(79, 20);
            this.label201.TabIndex = 0;
            this.label201.Text = "label201";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1447, 975);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
    }
}

