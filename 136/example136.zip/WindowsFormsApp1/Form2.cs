﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example136;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from sct013 order by date desc limit 30";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "sct013");
                
                for(int i = 0; i < chart1.Series.Count; i++)
                {
                    chart1.Series[i].Points.Clear();
                }

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    chart1.Series[0].Points.AddXY(i, double.Parse(ds.Tables[0].Rows[i]["stime"].ToString()));
                    chart1.Series[1].Points.AddXY(i, double.Parse(ds.Tables[0].Rows[i]["wh"].ToString()));
                    chart1.Series[2].Points.AddXY(i, double.Parse(ds.Tables[0].Rows[i]["w"].ToString()));
                    chart1.Series[3].Points.AddXY(i, double.Parse(ds.Tables[0].Rows[i]["a"].ToString()));
                }
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }
    }
}
