﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;
        string Conn = "Server=localhost;Database=example136;Uid=root;Pwd=qwer1234;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MQTT 브로커와 연결하는 부분
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //
            string[] topics = { "nockanda/relay/state", "nockanda/sct013" };
            byte[] qos = { 0,0 };
            client.Subscribe(topics, qos);
        }
        //MQTT이벤트 핸들러
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/relay/state")
            {
                if(ReceivedMessage == "0")
                {
                    label1.Text = "전구가 꺼졌습니다!(OFF)";
                }
                else if(ReceivedMessage == "1")
                {
                    label1.Text = "전구가 켜졌습니다!(ON)";
                }
                //DB에 데이터기록
                //삽입구문
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into relaystate(state,date) values("+ ReceivedMessage + ",'"+DateTime.Now.ToString()+"')", conn);
                    msc.ExecuteNonQuery();
                }
            }else if(e.Topic == "nockanda/sct013")
            {
                //label2.Text = ReceivedMessage;
                string[] data = ReceivedMessage.Split(',');

                label2.Text = "샘플링타임:"+data[0] + "ms";
                label3.Text = "누적전력량:"+data[1] + "Wh";
                label4.Text = "순간전력:"+data[2]+"W";
                label5.Text = "순간전류:" +data[3] + "A";

                //DB에 데이터를 누적
                //삽입구문
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into sct013(stime,wh,w,a,date) values("+ data[0] + ","+ data[1] + ","+ data[2] + ","+ data[3] + ",'"+DateTime.Now.ToString()+"')", conn);
                    msc.ExecuteNonQuery();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/relay/control", Encoding.UTF8.GetBytes("1"), 0, true);
            //삽입구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into relaycontrol(control,date) values(1,'"+DateTime.Now.ToString()+"')", conn);
                msc.ExecuteNonQuery();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/relay/control", Encoding.UTF8.GetBytes("0"), 0, true);
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into relaycontrol(control,date) values(0,'" + DateTime.Now.ToString() + "')", conn);
                msc.ExecuteNonQuery();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from relaycontrol order by date desc limit 10";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "relaycontrol");

                listView1.Items.Clear();
                for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ds.Tables[0].Rows[i]["num"].ToString();
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["control"].ToString());
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["date"].ToString());

                    listView1.Items.Add(lvi);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from relaystate order by date desc limit 10";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "relaycontrol");

                listView1.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ds.Tables[0].Rows[i]["num"].ToString();
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["state"].ToString());
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["date"].ToString());

                    listView1.Items.Add(lvi);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();
            fm2.Show();
        }
    }
}
