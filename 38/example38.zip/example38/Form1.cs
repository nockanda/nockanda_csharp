﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example38
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[2];
                serialPort1.Read(recv, 0, 2);
                int value = (recv[0] * 256) + recv[1];

                if (value < 1024 && value >= 0)
                {
                    vScrollBar1.Value = value;
                }
                if (boanmode)
                {
                    if (value < 500)
                    {
                        //후레쉬를 비춘경우
                        label2.Text = "침입감지!";
                        listBox1.Items.Add(DateTime.Now.ToString() + "/침입발생");
                    }
                    else
                    {
                        //평상시경우
                        label2.Text = "안전함!";
                    }
                }
                label1.Text = value.ToString();
            }
        }

        bool boanmode = false;
        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[1];
                send[0] = 1;
                serialPort1.Write(send, 0, 1);
                boanmode = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[1];
                send[0] = 0;
                serialPort1.Write(send, 0, 1);
                boanmode = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[1];
                send[0] = 0;
                serialPort1.Write(send, 0, 1);
                boanmode = false;
            }
        }
    }
}
