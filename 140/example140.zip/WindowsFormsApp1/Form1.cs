﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string your_key = textBox1.Text;
            richTextBox1.Text = "";
            
            WebRequest wr = WebRequest.Create("https://dapi.kakao.com/v2/vision/face/detect");
            wr.Method = "POST";
            wr.ContentType = "application/x-www-form-urlencoded";
            wr.Headers.Add("Authorization", "KakaoAK " + your_key);

            string path = "image_url=" + textBox2.Text;
            byte[] img = Encoding.UTF8.GetBytes(path);

            Stream wr_s = wr.GetRequestStream();
            wr_s.Write(img, 0, img.Length);
            wr_s.Close();

            WebResponse wrs = wr.GetResponse();
            Stream wrs_s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(wrs_s);

            string response = sr.ReadToEnd();

            sr.Close();
            wrs_s.Close();
            

            //string response = richTextBox1.Text;

            JObject jo = JObject.Parse(response);

            pictureBox1.Load(textBox2.Text);
            Bitmap bt = new Bitmap(pictureBox1.Image);
            Graphics g = Graphics.FromImage(bt);

            for (int j = 0; j < jo["result"]["faces"].Count(); j++)
            {
                JToken node1 = jo["result"]["faces"][j]["facial_attributes"];
                JToken node2 = jo["result"]["faces"][j]["facial_points"];
                JToken node3 = jo["result"]["faces"][j];


                double male = double.Parse(node1["gender"]["male"].ToString());
                double female = double.Parse(node1["gender"]["female"].ToString());

                int age = (int)double.Parse(node1["age"].ToString());


                string sx = "";
                if (male > female)
                {
                    //남자
                    richTextBox1.Text += "남자인것 같다..\n";
                    sx = "남자";
                }
                else
                {
                    //여자
                    richTextBox1.Text += "여자인것 같다..\n";
                    sx = "여자";
                }

                richTextBox1.Text += "나이 = " + age + "\n";


                int width = bt.Width;
                int height = bt.Height;

                int marker_size = 5;

                float xx = float.Parse(node3["x"].ToString());
                float yy = float.Parse(node3["y"].ToString());
                float ww = float.Parse(node3["w"].ToString());
                float hh = float.Parse(node3["h"].ToString());

                float pitch = float.Parse(node3["pitch"].ToString());
                float yaw = float.Parse(node3["yaw"].ToString());
                float roll = float.Parse(node3["roll"].ToString());

                richTextBox1.Text += "pitch" + pitch + "\n";
                richTextBox1.Text += "yaw" + yaw + "\n";
                richTextBox1.Text += "roll" + roll + "\n";

                Pen p = new Pen(Color.Red, 5);
                g.DrawRectangle(p, width * xx, height * yy, width * ww, height * hh);

                Font drawFont = new Font("Arial", 20);
                SolidBrush drawBrush = new SolidBrush(Color.Red);
                g.DrawString(sx+"("+age.ToString()+")", drawFont, drawBrush, width * xx, height * yy-30);


                for (int i = 0; i < node2["left_eyebrow"].Count(); i++)
                {
                    float x = float.Parse(node2["left_eyebrow"][i][0].ToString());
                    float y = float.Parse(node2["left_eyebrow"][i][1].ToString());
                    g.FillRectangle(Brushes.Red, width * x, height * y, marker_size, marker_size);
                }
                for (int i = 0; i < node2["jaw"].Count(); i++)
                {
                    float x = float.Parse(node2["jaw"][i][0].ToString());
                    float y = float.Parse(node2["jaw"][i][1].ToString());
                    g.FillRectangle(Brushes.Blue, width * x, height * y, marker_size, marker_size);
                }
                for (int i = 0; i < node2["left_eye"].Count(); i++)
                {
                    float x = float.Parse(node2["left_eye"][i][0].ToString());
                    float y = float.Parse(node2["left_eye"][i][1].ToString());
                    g.FillRectangle(Brushes.Green, width * x, height * y, marker_size, marker_size);
                }
                for (int i = 0; i < node2["lip"].Count(); i++)
                {
                    float x = float.Parse(node2["lip"][i][0].ToString());
                    float y = float.Parse(node2["lip"][i][1].ToString());
                    g.FillRectangle(Brushes.Yellow, width * x, height * y, marker_size, marker_size);
                }
                for (int i = 0; i < node2["nose"].Count(); i++)
                {
                    float x = float.Parse(node2["nose"][i][0].ToString());
                    float y = float.Parse(node2["nose"][i][1].ToString());
                    g.FillRectangle(Brushes.Purple, width * x, height * y, marker_size, marker_size);
                }

                for (int i = 0; i < node2["right_eye"].Count(); i++)
                {
                    float x = float.Parse(node2["right_eye"][i][0].ToString());
                    float y = float.Parse(node2["right_eye"][i][1].ToString());
                    g.FillRectangle(Brushes.Green, width * x, height * y, marker_size, marker_size);
                }
                for (int i = 0; i < node2["right_eyebrow"].Count(); i++)
                {
                    float x = float.Parse(node2["right_eyebrow"][i][0].ToString());
                    float y = float.Parse(node2["right_eyebrow"][i][1].ToString());
                    g.FillRectangle(Brushes.Red, width * x, height * y, marker_size, marker_size);
                }
                richTextBox1.Text += "---------------------\n";
            }
            g.Dispose();

            pictureBox1.Image = bt;
        }
    }
}
