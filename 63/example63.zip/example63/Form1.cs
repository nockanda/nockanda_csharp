﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example63
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        static string tag1 = " a7 3c bb 7a"; //열쇠고리
        static string tag2 = " d4 6d a2 2a"; //1
        static string tag3 = " 4d 94 a0 3d"; //2
        static string tag4 = " 1c 75 84 3d"; //3
        static string tag5 = " bf 5f a0 3d"; //4
        static string tag6 = " 17 83 a0 3d"; //5
        static string tag7 = " 6b 08 a0 3d"; //6

        string[] tag_id = { tag1, tag2, tag3, tag4, tag5, tag6, tag7 };
        string[] word = { "사과", "포도", "바나나", "딸기", "참외", "수박", "망고" };
        Bitmap[] img = new Bitmap[7];

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
                MessageBox.Show("연결했습니다!");
            }
        }

        int tag_index(string id)
        {
            int i = 0;
            for (i = 0;i< tag_id.Length; i++)
            {
                if(tag_id[i] == id)
                {
                    //찾았네?
                    break;
                }
            }

            return i;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                string tag_id = serialPort1.ReadLine();
                tag_id = tag_id.Replace(((char)13).ToString(), "");
                label1.Text = tag_id;

                //richTextBox1.Text = word[tag_index(tag_id)];
                now_id = tag_id;
                is_receved = true;

            }
        }

        int[] nums = new int[3];
        string now_id = "";
        bool is_receved = false;
        int tag_count = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            //컨트롤 초기화과정
            label5.Text = "-";
            label6.Text = "-";
            label7.Text = "-";

            Random rd = new Random();

            nums[0] = rd.Next(0, 7);
            nums[1] = rd.Next(0, 7);
            nums[2] = rd.Next(0, 7);
            label2.Text = word[nums[0]];
            label3.Text = word[nums[1]];
            label4.Text = word[nums[2]];
            pictureBox1.Image = img[nums[0]];
            pictureBox2.Image = img[nums[1]];
            pictureBox3.Image = img[nums[2]];
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            img[0] = new Bitmap("./img1.png");
            img[1] = new Bitmap("./img2.png");
            img[2] = new Bitmap("./img3.png");
            img[3] = new Bitmap("./img4.png");
            img[4] = new Bitmap("./img5.png");
            img[5] = new Bitmap("./img6.png");
            img[6] = new Bitmap("./img7.png");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (is_receved)
            {
                //태깅된 값이 존재함
                


                is_receved = false;
                if (tag_count == 0)
                {
                    //첫번째 태깅
                    if (tag_index(now_id) == nums[0])
                    {
                        //랜덤으로 지정한 과일하고
                        //태깅한 태그가 일치하는 경우
                        label5.Text = "O";
                        richTextBox1.Text += word[nums[0]] + "/" + word[tag_index(now_id)];
                    }
                    else
                    {
                        label5.Text = "X";
                        richTextBox1.Text += word[nums[0]] + "/" + word[tag_index(now_id)];

                    }
                    tag_count++;
                }
                else if(tag_count == 1)
                {
                    //두번째 태깅
                    if (tag_index(now_id) == nums[1])
                    {
                        //랜덤으로 지정한 과일하고
                        //태깅한 태그가 일치하는 경우
                        label6.Text = "O";
                        richTextBox1.Text += word[nums[1]] + "/" + word[tag_index(now_id)];
                    }
                    else
                    {
                        label6.Text = "X";
                        richTextBox1.Text += word[nums[1]] + "/" + word[tag_index(now_id)];
                    }
                    tag_count++;
                }
                else if(tag_count == 2)
                {
                    //세번쨰태깅
                    if (tag_index(now_id) == nums[2])
                    {
                        //랜덤으로 지정한 과일하고
                        //태깅한 태그가 일치하는 경우
                        label7.Text = "O";
                        richTextBox1.Text += word[nums[2]] + "/" + word[tag_index(now_id)];
                    }
                    else
                    {
                        label7.Text = "X";
                        richTextBox1.Text += word[nums[2]] + "/" + word[tag_index(now_id)];
                    }
                    tag_count = 0;
                    timer1.Stop();
                }

                
            }
        }
    }
}
