﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example59
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //8바이트씩 4덩어리
        byte[,] dots = new byte[4, 8];
        private void button2_Click(object sender, EventArgs e)
        {
            //가로10 세로10인 사각형
            int size = 20;
            Bitmap bt = new Bitmap(32 * size, 8 * size);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(Color.Black);

            for(int i = 0; i < 32; i++)
            {
                for(int j = 0; j <8; j++)
                {
                    
                    g.DrawRectangle(Pens.Red, i * size, j * size, size, size);
                }
            }

            g.Dispose();
            pictureBox1.Image = bt;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            //e.X
            //e.Y
            //0~640 ... 한칸이 20
            //
            //richTextBox1.Text = ((int)(e.X / 20.0)).ToString()+"/";
            //richTextBox1.Text += ((int)(e.Y / 20.0)).ToString();
            // byte[,] dots = new byte[4, 8];
            //y가 0이면서 x가 5   13
            //[0.0] | 00001000 8-col
            int device = (int)(e.X / 160.0);
            int row = (int)(e.Y / 20.0);
            int col = ((int)(e.X / 20.0)) % 8;
            //richTextBox1.Text += device + "/" + row+"/"+ col+"\n";

            if (((dots[device, row] >> (7 - col)) & 0x01) == 1)
            {
                //0으로 만들어줘야함  1
                dots[device, row] = (byte)(dots[device, row] ^ (1 << (7 - col)));
            }
            else
            {
                //1로만들어줘야함
                dots[device, row] = (byte)(dots[device, row] | (1 << (7 - col)));
            }

            //새로그리기
            //가로10 세로10인 사각형
            
            int size = 20;
            Bitmap bt = new Bitmap(32 * size, 8 * size);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(Color.Black);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    //0~31 
                    //dots[i, j]
                    //j 1당 20씩
                    //i*160씩 너비가 증가
                    for(int k = 0; k < 8; k++)
                    {
                        //각바이트를 분해하기 위함
                        //1000 0000  >> 7  
                        if (((dots[i, j] >> k) & 0x01) == 1)
                        {
                            //checked
                            g.FillRectangle(Brushes.Red, ((i*8)+7-k) * size, j * size, size, size);
                        }
                        else
                        {
                            g.DrawRectangle(Pens.Red, ((i * 8) + 7-k) * size, j * size, size, size);
                        }
                    }
                }
            }

            g.Dispose();
            pictureBox1.Image = bt;
            

            richTextBox1.Text = "";
            for(int i = 0; i < 4; i++)
            {
                for(int j = 0; j < 8; j++)
                {
                    richTextBox1.Text += dots[i, j].ToString("X") + "/";
                }
                richTextBox1.Text += "\n";
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[32];
                for(int i = 0; i < 4; i++)
                {
                    for(int j = 0; j < 8; j++)
                    {
                        send[(i * 8) + j] = dots[i, j];

                        richTextBox1.Text += send[(i * 8) + j].ToString("X") + "/";
                    }
                }

                serialPort1.Write(send, 0, 32);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < dots.GetLength(0); i++)
            {
                for(int j = 0; j < dots.GetLength(1); j++)
                {
                    dots[i, j] = 0x00;
                }
            }
            int size = 20;
            Bitmap bt = new Bitmap(32 * size, 8 * size);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(Color.Black);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    //0~31 
                    //dots[i, j]
                    //j 1당 20씩
                    //i*160씩 너비가 증가
                    for (int k = 0; k < 8; k++)
                    {
                        //각바이트를 분해하기 위함
                        //1000 0000  >> 7  
                        if (((dots[i, j] >> k) & 0x01) == 1)
                        {
                            //checked
                            g.FillRectangle(Brushes.Red, ((i * 8) + 7 - k) * size, j * size, size, size);
                        }
                        else
                        {
                            g.DrawRectangle(Pens.Red, ((i * 8) + 7 - k) * size, j * size, size, size);
                        }
                    }
                }
            }

            g.Dispose();
            pictureBox1.Image = bt;
        }
    }
}
