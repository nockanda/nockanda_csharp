﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example48
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text += button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text += button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Text += button4.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox2.Text += button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox2.Text += button7.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox2.Text += button8.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox2.Text += button5.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox2.Text += button9.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox2.Text += button10.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox2.Text += button11.Text;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox2.Text += button12.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox2.Text += button13.Text;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox2.Text += button14.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox2.Text += button15.Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox2.Text += button16.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox2.Text += button17.Text;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                char input = (char)serialPort1.ReadChar();

                if(input == '1')
                {
                    button2_Click(null, null);
                }
                if (input == '2')
                {
                    button3_Click(null, null);
                }
                if (input == '3')
                {
                    button4_Click(null, null);
                }
                if (input == '4')
                {
                    button6_Click(null, null);
                }
                if (input == '5')
                {
                    button7_Click(null, null);
                }
                if (input == '6')
                {
                    button8_Click(null, null);
                }
                if (input == '7')
                {
                    button10_Click(null, null);
                }
                if (input == '8')
                {
                    button11_Click(null, null);
                }
                if (input == '9')
                {
                    button12_Click(null, null);
                }
                if (input == '0')
                {
                    button15_Click(null, null);
                }
                if (input == 'A')
                {
                    button5_Click(null, null);
                }
                if (input == 'B')
                {
                    button9_Click(null, null);
                }
                if (input == 'C')
                {
                    button13_Click(null, null);
                }
                if (input == 'D')
                {
                    button17_Click(null, null);
                }
                if (input == '*')
                {
                    button14_Click(null, null);
                }
                if (input == '#')
                {
                    button16_Click(null, null);
                }
            }
        }
    }
}
