﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example72
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Pen mypen = Pens.Black;

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = hScrollBar1.Value.ToString();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            int r = hScrollBar1.Value;

            mypen = new Pen(mypen.Color, hScrollBar2.Value);
            g.DrawEllipse(mypen, e.X-r, e.Y-r, r*2, r*2);

            double area = Math.PI * r * r;
            double dia = 2 * Math.PI * r;

            g.DrawString("넓이:"+area.ToString() + "\n지름:" + dia.ToString(), DefaultFont, Brushes.Red, e.Location);

            g.Dispose();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
             * 검은색0
                빨간색1
                파란색2
                초록색3
                노란색4
             */
            if (comboBox1.SelectedIndex == 0)
            {
                mypen = new Pen(Color.Black, 1);
            }else if(comboBox1.SelectedIndex == 1)
            {
                mypen = new Pen(Color.Red, 1);
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                mypen = new Pen(Color.Blue, 1);
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                mypen = new Pen(Color.Green, 1);
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                mypen = new Pen(Color.Yellow, 1);
            }
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label5.Text = hScrollBar2.Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            g.FillRectangle(Brushes.White, 0, 0, pictureBox1.Width, pictureBox1.Height);

            g.Dispose();
        }
    }
}
