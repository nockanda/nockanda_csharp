﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example33
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            
        }

        private void richTextBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            label1.Text = e.Location.ToString();
            //label3.Text = this.Location.ToString();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //label1.Text =  e.KeyData.ToString() + "뭔가 누르고 있는 중입니다..";
            if(e.KeyCode == Keys.A)
            {
                //a를 눌렀다면...
                label1.Text = e.KeyData.ToString() + "뭔가 누르고 있는 중입니다..";
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                label1.Text = e.KeyData.ToString() + "뭔가 눌렀다가 뗏다..";
            }
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            //button1.BackColor = Color.Red;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            //button1.BackColor = SystemColors.Control;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        Point windowmove;
        bool clicked = false;
        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            windowmove = e.Location;
            clicked = true;
        }

        private void label2_MouseMove(object sender, MouseEventArgs e)
        {
            if (clicked) {
                int x = e.X - windowmove.X; //이동량
                int y = e.Y - windowmove.Y; //이동량
                this.Location = new Point(this.Location.X + x, this.Location.Y + y);
                //label3.Text = x + "/" + y;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        private void label2_MouseUp(object sender, MouseEventArgs e)
        {
            clicked = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(textBox3.Text != "")
            {
                richTextBox1.Text += textBox3.Text + "\n";
                textBox3.Text = "";
                textBox3.Focus();
                toolStripStatusLabel1.Text = "메시지 전송이 완료되었습니다..";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (true)
            {
                //만약 로그인이 성공했다면..
                textBox3.Focus();
                toolStripStatusLabel1.Text = "로그인이 완료되었습니다";
            }
        }

        private void 끄기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            this.Opacity = trackBar1.Value / 100d;
        }

        private void 종료ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.5;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.7;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            this.Opacity = 1.0;
        }
    }
}
