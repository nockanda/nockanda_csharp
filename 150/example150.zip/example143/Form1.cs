﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using MySql.Data.MySqlClient;

namespace example143
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example150;Uid=root;Pwd=qwer1234;";
        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;


                //   rawdata = /barcode=8809022634918
                //             /barcode=8809022634918&type=1
                
                string responseString = "";

                if (request.RawUrl.IndexOf("&type") != -1)
                {
                    //리퀘스트폼2(데이터 입력)
                    //             /barcode=8809022634918&type=1
                    string data = request.RawUrl.Replace("/", "");
                    //              barcode=8809022634918&type=1
                    string[] keys = data.Split('&');
                    // keys[0] =  barcode=8809022634918
                    // keys[1] =  type=1
                    //insert into trashcan values('8808739000108',0);

                    string barcode = keys[0].Split('=')[1];
                    string type = keys[1].Split('=')[1];

                    //삽입구문
                    using (MySqlConnection conn = new MySqlConnection(Conn))
                    {
                        conn.Open();
                        MySqlCommand msc = new MySqlCommand("insert into trashcan values('"+ barcode + "',"+ type + ")", conn);
                        msc.ExecuteNonQuery();
                    }
                    responseString = "<response>OK\n";
                }
                else
                {
                    //리퀘스트폼1(조회)
                    string barcode = request.RawUrl.Replace("/barcode=", "");
                    using (MySqlConnection conn = new MySqlConnection(Conn))
                    {
                        DataSet ds = new DataSet();
                        string sql = "select * from trashcan where barcode='" + barcode + "'";
                        MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                        adpt.Fill(ds, "trashcan");

                        //ds
                        //0 - 일반, 1- 재활용, 2-검색결과없음
                        if (ds.Tables[0].Rows.Count == 0)
                        {
                            //검색결과 없음
                            responseString = "<response>2\n";
                        }
                        else
                        {
                            //검색결과 있음
                            responseString = "<response>" + ds.Tables[0].Rows[0]["type"].ToString() + "\n";
                        }
                    }

                }


                //richTextBox1.Text += request.RawUrl + "\n";


                //DB에서 찾는다!
                //검색구문




                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                // Construct a response.
                
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }
    }
}
