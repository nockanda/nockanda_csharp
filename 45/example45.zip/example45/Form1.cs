﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example45
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }
        bool isbusy = false;
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                //1바이트 0~255
                byte[] send = new byte[1];
                send[0] = (byte)trackBar1.Value;
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[1];
                serialPort1.Read(recv, 0, 1);
                label1.Text = ((int)((recv[0] / 255.0) * 100)).ToString() + "%";
                isbusy = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                //1바이트 0~255
                byte[] send = new byte[1];
                send[0] = (byte)(255*0.15);
                trackBar1.Value = send[0];
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                //1바이트 0~255
                byte[] send = new byte[1];
                send[0] = (byte)(255 * 0.2);
                trackBar1.Value = send[0];
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                //1바이트 0~255
                byte[] send = new byte[1];
                send[0] = (byte)(255 * 0.5);
                trackBar1.Value = send[0];
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                //1바이트 0~255
                byte[] send = new byte[1];
                send[0] = (byte)(255 * 0.7);
                trackBar1.Value = send[0];
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                //1바이트 0~255
                byte[] send = new byte[1];
                send[0] = (byte)(255);
                trackBar1.Value = send[0];
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }
    }
}
