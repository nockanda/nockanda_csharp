﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example61
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[1];
                serialPort1.Read(recv, 0, 1);

                textBox2.Text = recv[0].ToString();
                if (army_info.ContainsKey((int)recv[0]))
                {
                    //등록된 정보가 있을경우
                    textBox3.Text = army_info[recv[0]].name;
                    textBox4.Text = army_info[recv[0]].age;
                    textBox5.Text = army_info[recv[0]].s;
                    textBox6.Text = army_info[recv[0]].level;
                    textBox7.Text = army_info[recv[0]].skill;
                    textBox8.Text = army_info[recv[0]].budae;
                }
                else
                {
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                }
            }
        }

        Dictionary<int, army> army_info = new Dictionary<int, army>();
        private void button2_Click(object sender, EventArgs e)
        {
            army input_data = new army();
            if(textBox2.Text == "")
            {
                MessageBox.Show("지문을 입력해주세요!");
                return;
            }
            
            input_data.fingerid = int.Parse(textBox2.Text);
            input_data.name = textBox3.Text;
            input_data.age = textBox4.Text;
            input_data.s = textBox5.Text;
            input_data.level = textBox6.Text;
            input_data.skill = textBox7.Text;
            input_data.budae = textBox8.Text;
            
            //이미 딕셔너리에 있는 ID면 등록되면 안됨
            if (army_info.ContainsKey(input_data.fingerid))
            {
                //이미등록이 된 경우
                MessageBox.Show("이미 등록된 정보입니다!");
            }
            else
            {
                army_info.Add(input_data.fingerid, input_data);
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                MessageBox.Show("성공적으로 등록했습니다!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox2.Text == "")
            {
                MessageBox.Show("지문을 입력해주세요!");
                return;
            }

            int fingerid = int.Parse(textBox2.Text);
            if (army_info.ContainsKey(fingerid))
            {
                //지문정보가 조회된 경우
                army_info[fingerid].fingerid = fingerid;
                army_info[fingerid].name = textBox3.Text;
                army_info[fingerid].age = textBox4.Text;
                army_info[fingerid].s = textBox5.Text;
                army_info[fingerid].level = textBox6.Text;
                army_info[fingerid].skill = textBox7.Text;
                army_info[fingerid].budae = textBox8.Text;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("지문을 입력해주세요!");
                return;
            }

            int fingerid = int.Parse(textBox2.Text);
            if (army_info.ContainsKey(fingerid))
            {
                army_info.Remove(fingerid);
            }
        }
    }
    //이름 나이 성별 계급 특기 소속부대
    class army
    {
        public int fingerid;
        public string name;
        public string age;
        public string s;
        public string level;
        public string skill;
        public string budae;
    }
}
