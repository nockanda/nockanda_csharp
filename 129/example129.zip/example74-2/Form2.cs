﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example74_2
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example129;Uid=root;Pwd=qwer1234;";

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //chart clear
            for (int i = 0; i < chart1.Series.Count; i++)
            {
                chart1.Series[i].Points.Clear();
            }

            //DB에서 데이터를 추출해서
            //그래프에 그려라!
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from pump order by date desc limit 20";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "pump");

                //받아온 결과(Dataset)에서 한 레코드씩 순회하면서 결과를 그래프로 출력한다!
                for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string pump = ds.Tables[0].Rows[i]["pump"].ToString();
                    string flow = ds.Tables[0].Rows[i]["flow"].ToString();
                    string min = ds.Tables[0].Rows[i]["min"].ToString();
                    string max = ds.Tables[0].Rows[i]["max"].ToString();

                    chart1.Series[0].Points.AddXY(i, int.Parse(pump));
                    chart1.Series[1].Points.AddXY(i, float.Parse(flow));
                    chart1.Series[2].Points.AddXY(i, int.Parse(min));
                    chart1.Series[3].Points.AddXY(i, int.Parse(max));
                }
            }
        }
    }
}
