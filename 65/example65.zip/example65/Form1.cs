﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example65
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //nockanda_number[1,?] ~ nockanda_number[4,?]
        byte[,] nockanda_number =
        {
            {0b00011000,0b00111100,0b01100110,0b01100110,0b01100110,0b01100110,0b00111100,0b00011000},//0
            {0b00011000,0b00111000,0b01111000,0b00011000,0b00011000,0b00011000,0b00011000,0b01111110}, //1
            {0b00111100,0b01111110,0b01000110,0b00001100,0b00011000,0b00110000,0b01100000,0b01111110}, //2
            {0b00111100,0b01111110,0b01100110,0b00001110,0b00001100,0b01000110,0b01111110,0b00111100}, //3
            {0b00010000,0b00100000,0b01001000,0b01001000,0b01111110,0b00001000,0b00001000,0b00001000}, //4
            {0b01111110,0b01100000,0b01100000,0b00111100,0b00000110,0b00000110,0b01111110,0b01111110}, //5
            {0b00011100,0b00110000,0b01100000,0b01111110,0b01111110,0b01000010,0b01111110,0b00111100}, //6
            {0b00111100,0b01111110,0b01000110,0b00000110,0b00001100,0b00011000,0b00110000,0b00100000}, //7
            {0b00111100,0b01000010,0b01000010,0b01111110,0b00111100,0b01000010,0b01000010,0b00111100}, //8
            {0b00111100,0b01111110,0b01000010,0b01111110,0b00111110,0b00000010,0b00000010,0b00111100} //9
        };
        byte[] nockanda =
        {
            0b00000000,
            0b01100110,
            0b11111111,
            0b11111111,
            0b01111110,
            0b00111100,
            0b00011000,
            0b00000000
        };
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {


            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[32];
                
                DateTime dt = DateTime.Now;
                //1초.,... 01
                label1.Text = dt.Hour + ":" + dt.Minute + ":" + dt.Second;
                int[] nums = new int[4];
                nums[0] = dt.Hour / 10;
                nums[1] = dt.Hour % 10;

                nums[2] = dt.Minute / 10;
                nums[3] = dt.Minute % 10;

                //첫번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    send[i] = (byte)(nockanda_number[nums[0], i] << 1);
                }
                //두번쨰숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    byte temp = (byte)(nockanda_number[nums[1], i] << 1);
                    if (i == 1 || i == 2 || i == 5 || i == 6)
                    {
                        temp = (byte)(temp | 0x01);
                    }
                    send[i + 8] = temp;
                }
                //세번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    byte temp = (byte)(nockanda_number[nums[2], i] >> 1);
                    if (i == 1 || i == 2 || i == 5 || i == 6)
                    {
                        temp = (byte)(temp | 0x80);
                    }
                    send[i + 16] = temp;
                }
                //네번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    send[i + 24] = (byte)(nockanda_number[nums[3], i] >> 1);
                }
                serialPort1.Write(send, 0, 32);
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[32];
                int year = DateTime.Now.Year;
                int[] nums = new int[4];
                nums[0] = year / 1000;
                nums[1] = (year % 1000) / 100;
                nums[2] = (year % 100) / 10;
                nums[3] = year % 10;

                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    send[i] = (byte)(nockanda_number[nums[0], i] << 1);
                }
                //두번쨰숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    byte temp = (byte)(nockanda_number[nums[1], i] << 1);
                    
                    send[i + 8] = temp;
                }
                //세번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    byte temp = (byte)(nockanda_number[nums[2], i] >> 1);
                    
                    send[i + 16] = temp;
                }
                //네번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    send[i + 24] = (byte)(nockanda_number[nums[3], i] >> 1);
                }
                serialPort1.Write(send, 0, 32);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[32];
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;
                int[] nums = new int[4];
                nums[0] = month / 10;
                nums[1] = month % 10;
                nums[2] = day / 10;
                nums[3] = day % 10;

                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    send[i] = (byte)(nockanda_number[nums[0], i] << 1);
                }
                //두번쨰숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    byte temp = (byte)(nockanda_number[nums[1], i] << 1);

                    send[i + 8] = temp;
                }
                //세번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    byte temp = (byte)(nockanda_number[nums[2], i] >> 1);

                    send[i + 16] = temp;
                }
                //네번째숫자
                for (int i = 0; i < 8; i++)
                {
                    //nockanda_number[num1,i]
                    send[i + 24] = (byte)(nockanda_number[nums[3], i] >> 1);
                }
                serialPort1.Write(send, 0, 32);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[32];
                for (int j = 0; j < 4; j++)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        //nockanda_number[num1,i]
                        send[i+(8*j)] = nockanda[i];
                    }
                }
                serialPort1.Write(send, 0, 32);
            }
        }
    }
}

