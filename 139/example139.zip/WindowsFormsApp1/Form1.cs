﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example139;Uid=root;Pwd=qwer1234;";
        MqttClient client;
        string clientId;

        int pump = -999;
        float water = -999;
        int level = -999;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MQTT 브로커와 연결하는 부분
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독할 TOPIC을 추가
            string[] topic = { "nockanda/device1", "nockanda/flow","nockanda/level"};
            byte[] qos = { 0, 0, 0 };
            client.Subscribe(topic, qos);
        }
        //MQTT이벤트 핸들러
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if (e.Topic == "nockanda/device1")
            {
                if (ReceivedMessage == "0")
                {
                    //label1.Text = "워터펌프가 꺼져있다!(OFF)";
                    aGauge1.Value = 0;
                    pump = 0;
                }
                else if (ReceivedMessage == "1")
                {
                    //label1.Text = "워터펌프가 켜져있다!(ON)";
                    aGauge1.Value = 1;
                    pump = 1;
                }

            }
            else if (e.Topic == "nockanda/flow")
            {
                label2.Text = ReceivedMessage + "ml";
                float value = float.Parse(ReceivedMessage);
                if (value <= 400)
                {
                    aGauge2.Value = value;
                }
                water = value;

                if (checkBox1.Checked)
                {
                    if(value > hScrollBar1.Value)
                    {
                        //사용량 제한을 초과한 경우이므로
                        //워터펌프를 시스템에 의해서 자동으로 멈춘다
                        client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("0"), 0, true);
                    }
                }
            }
            
            else if (e.Topic == "nockanda/level")
            {
                //label4.Text = ReceivedMessage;
                level = int.Parse(ReceivedMessage);
                aGauge3.Value = level;

                //0(부족),1(적정),2(충분)
                if(level == 0)
                {
                    //펌프를 멈추게 하는 메시지를 publish
                    client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("0"), 0, true);
                }

            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("1"), 0, true);
            //DB에 기록
            //삽입구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into pump(state,date) values(1,'" + DateTime.Now.ToString() + "')", conn);
                msc.ExecuteNonQuery();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("0"), 0, true);
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into pump(state,date) values(0,'" + DateTime.Now.ToString() + "')", conn);
                msc.ExecuteNonQuery();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/clear", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {
                timer1.Start();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //나는 DB에 데이터 저장해야지~~
            //삽입구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into monitor(pump,water,level,date) values("+pump+","+water+","+level+",'"+DateTime.Now.ToString()+"')", conn);
                msc.ExecuteNonQuery();
                water = -999;
                pump = -999;
                level = -999;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();
            fm2.Show();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label7.Text = hScrollBar1.Value.ToString();
        }
    }
}
