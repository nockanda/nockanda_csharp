﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example139;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from monitor order by date desc limit 30";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "monitor");

                //chart 초기화
                chart1.Series[0].Points.Clear();
                chart1.Series[1].Points.Clear();
                chart1.Series[2].Points.Clear();

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    int pump = int.Parse(ds.Tables[0].Rows[i]["pump"].ToString());
                    float water = float.Parse(ds.Tables[0].Rows[i]["water"].ToString());
                    int level = int.Parse(ds.Tables[0].Rows[i]["level"].ToString());

                    if (pump != -999)
                    {
                        chart1.Series[0].Points.AddXY(i, pump);
                    }
                    if (water != -999)
                    {
                        chart1.Series[1].Points.AddXY(i, water);
                    }
                    if (level != -999)
                    {
                        chart1.Series[2].Points.AddXY(i, level);
                    }
                }
            }
        }
    }
}
