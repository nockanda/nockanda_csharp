﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example29
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();

                //아두이노에게 3을 보내면 초기요청
                if (serialPort1.IsOpen)
                {
                    byte[] send = new byte[1];
                    send[0] = 2;
                    serialPort1.Write(send, 0, 1);
                }
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                int recv = serialPort1.ReadByte();
                if(recv == 0)
                {
                    label1.Text = "닫힘!";
                }
                else
                {
                    label1.Text = "열림!";
                }
                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(label1.Text);
                listView1.Items.Add(lvi);

                richTextBox1.Text += recv + "\n";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[1];
                send[0] = 0;
                serialPort1.Write(send, 0, 1);


                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add("솔레노이드 잠금");
                listView1.Items.Add(lvi);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[1];
                send[0] = 1;
                serialPort1.Write(send, 0, 1);

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add("솔레노이드 열림");
                listView1.Items.Add(lvi);
            }
        }
    }
}
