﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example30
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        Point p = new Point(388, 104); //원래 별모양의 위치
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[4];
                serialPort1.Read(recv, 0, 4);

                int value1 = (recv[0] * 256) + recv[1];
                int value2 = (recv[2] * 256) + recv[3];
                label1.Text = value1.ToString();
                label2.Text = value2.ToString();

                label3.Location = new Point((int)(p.X + value1 / 10.0f), (int)(p.Y + value2 / 10.0f));
                trackBar1.Value = value1;
                trackBar2.Value = value2;
                Graphics g = pictureBox1.CreateGraphics();
                Point drawpoint = new Point((int)(value1 / 10.0f), (int)(value2 / 10.0f));

                g.DrawRectangle(mypen, drawpoint.X, drawpoint.Y, 2, 2);


                g.Dispose();

            }
        }
        Pen mypen = Pens.Black;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            mypen = Pens.Black;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            mypen = Pens.Red;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            mypen = Pens.Blue;
        }
    }
}
