﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example125
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example125;Uid=root;Pwd=qwer1234;";

        private TextBox _tb;

        public Form2(TextBox tb)
        {
            InitializeComponent();
            _tb = tb;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //기본값 저장하기
            for(int i = 1; i <= 50; i++)
            {
                listBox1.Items.Add(i.ToString());
            }

            //DB에서 조회해서 해당되는 락커번호 빼기
            
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select room from user order by room";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "user");

                for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                     listBox1.Items.Remove(ds.Tables[0].Rows[i]["room"].ToString());
                }
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex != -1)
            {
                _tb.Text = listBox1.SelectedItem.ToString();
                this.Close();
            }
        }
    }
}
