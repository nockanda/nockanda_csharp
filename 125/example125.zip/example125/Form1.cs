﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Crypto.Digests;

namespace example125
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example125;Uid=root;Pwd=qwer1234;";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && serialPort1.IsOpen == false)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen == true)
            {
                serialPort1.Close();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //크로스 스레드
            textBox2.Text = serialPort1.ReadLine();

            //아두이노로부터 RFID태그의 ID가 수신되었다!
            string tag_id = textBox2.Text;

            //CR + LF
            tag_id = tag_id.Replace(((char)0x0D).ToString(), "");


            //데이터베이스에 조회해서 등록된것인지 아닌지를 판단한다!
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from user where id='"+ tag_id + "'";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "user");


                if (ds.Tables[0].Rows.Count == 1)
                {
                    //MYSQL에 조회해보니까 1건 조회되더라..
                    //조회절차
                    textBox3.Text = ds.Tables[0].Rows[0]["name"].ToString();
                    textBox10.Text = ds.Tables[0].Rows[0]["edate"].ToString();
                    comboBox2.SelectedItem = ds.Tables[0].Rows[0]["gender"].ToString();
                    textBox4.Text = ds.Tables[0].Rows[0]["length"].ToString();
                    textBox5.Text = ds.Tables[0].Rows[0]["kg"].ToString();
                    textBox6.Text = ds.Tables[0].Rows[0]["oil"].ToString();
                    textBox7.Text = ds.Tables[0].Rows[0]["pt"].ToString();
                    textBox8.Text = ds.Tables[0].Rows[0]["room"].ToString();
                    string img_path = ds.Tables[0].Rows[0]["image"].ToString();
                    textBox9.Text = img_path;

                    pictureBox1.Image = new Bitmap("./img/" + img_path);

                    //히스토리 기록
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into history values('"+ tag_id + "','"+DateTime.Now.ToString()+"')", conn);
                    msc.ExecuteNonQuery();

                }
                else
                {
                    //유저의 정보가 저장이 되어있지 않다!
                    //저장절차!
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox9.Text = "";
                    textBox10.Text = "";
                    pictureBox1.Image = null;
                    MessageBox.Show("저장을 해주세요!");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "" &&
                textBox3.Text != "" &&
                textBox4.Text != "" &&
                textBox5.Text != "" &&
                textBox6.Text != "" &&
                textBox7.Text != "" &&
                textBox8.Text != "" &&
                textBox9.Text != ""
                )
            {
                //데이터가 전부 입력이 되었을때 진행!

                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    conn.Open();
                    string tag_id = textBox2.Text.Replace(((char)0x0D).ToString(), "");
                    DateTime s_dt = DateTime.Now;
                    DateTime e_dt = s_dt.AddMonths(int.Parse(comboBox1.SelectedItem.ToString()));
                    MySqlCommand msc = new MySqlCommand("insert into user values('"+ tag_id + 
                        "','"+ textBox3.Text + 
                        "','"+ s_dt.ToString() + 
                        "','"+ e_dt.ToString() + 
                        "','"+comboBox2.SelectedItem.ToString() +
                        "',"+ textBox4.Text + 
                        ","+ textBox5.Text + 
                        ","+ textBox6.Text + 
                        ",'"+ textBox7.Text + 
                        "',"+ textBox8.Text +
                        ",'"+ textBox9.Text + "')", conn);
                    msc.ExecuteNonQuery();
                }

                //저장한다음에는 입력폼을 초기화한다!
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                pictureBox1.Image = null;

                MessageBox.Show("저장되었습니다..!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //파일명만 분리해서 textbox에 출력한다!
                FileInfo fi = new FileInfo(openFileDialog1.FileName);
                textBox9.Text = fi.Name;
                pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2(textBox8);
            fm2.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //리스트뷰를 항상 초기화하고 시작한다!
            listView1.Items.Clear();

            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from history order by date desc limit 10";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "history");


                for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ds.Tables[0].Rows[i]["id"].ToString();

                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["date"].ToString());
                    listView1.Items.Add(lvi);
                }
            }
        }
    }
}

