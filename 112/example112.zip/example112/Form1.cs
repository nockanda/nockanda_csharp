﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example112
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        bool door_state = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독정보를 지정
            client.Subscribe(new string[] { "nockanda/door", "nockanda/lock_state", "nockanda/rfid" }, new byte[] { 0, 0, 0 });
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/door")
            {
                if(ReceivedMessage == "0")
                {
                    label1.Text = "문이 닫혔다!";
                }
                else
                {
                    label1.Text = "문이 열렸다!";
                    if (door_state)
                    {
                        label5.Text = "도난경보!";
                    }
                    else
                    {
                        label5.Text = "도난경보 해제!";
                    }
                }
            }else if(e.Topic == "nockanda/lock_state")
            {
                label2.Text = ReceivedMessage;

                if(ReceivedMessage == "도어락 해제")
                {
                    door_state = false;
                }
                else if(ReceivedMessage == "도어락 설정")
                {
                    door_state = true;
                }
            }else if(e.Topic == "nockanda/rfid")
            {
                label3.Text = ReceivedMessage;

                //비교작업
                bool is_match = false;
                for(int i = 0; i < listBox1.Items.Count; i++)
                {
                    if(listBox1.Items[i].ToString() == ReceivedMessage)
                    {
                        is_match = true;
                        break;
                    }
                }

                if (is_match)
                {
                    label4.Text = "허가된 사용자!";
                    //현재 도어락 상태와 반대되는 메시지를 publish한다
                    if (door_state)
                    {
                        //잠금을 해제하는 메시지
                        client.Publish("nockanda/lock", Encoding.UTF8.GetBytes("0"), 0, true);
                    }
                    else
                    {
                        //잠금을 설정하는 메시지
                        client.Publish("nockanda/lock", Encoding.UTF8.GetBytes("1"), 0, true);
                    }
                }
                else
                {
                    label4.Text = "권한없는 사용자!";
                }

            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/lock", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/lock", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && textBox1.Text.Length == 8)
            {
                listBox1.Items.Add(textBox1.Text);
            }
        }
    }
}
