﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example49
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
                byte[] send = new byte[1];
                send[0] = 2;
                serialPort1.Write(send, 0, 1);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //시리얼포트가 열려있으면 하겠다
                byte[] send = new byte[1];
                send[0] = 0;
                serialPort1.Write(send, 0, 1);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //시리얼포트가 열려있으면 하겠다
                byte[] send = new byte[1];
                send[0] = 1;
                serialPort1.Write(send, 0, 1);
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[1];
                serialPort1.Read(recv, 0, 1);
                string temp = "";
                if(recv[0] == 0)
                {
                    //잠금상태
                    temp = "잠금";
                    label1.Text = temp;
                }
                else if(recv[0] == 1)
                {
                    //열린상태
                    temp = "열림";
                    label1.Text = temp;
                }

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(temp);

                listView1.Items.Add(lvi);
            }
        }
    }
}
