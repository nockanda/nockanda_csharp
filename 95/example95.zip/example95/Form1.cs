﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example95
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //openapi서비스를 다운로드받는다..
            string yourkey = textBox1.Text;

            string date = monthCalendar1.SelectionRange.Start.ToString("yyyyMMdd");
            string query = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.xml?key=" + yourkey + "&targetDt=" + date;

            //공무원에게 제출해보자!
            WebRequest wr = WebRequest.Create(query);
            wr.Method = "GET";
            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["boxOfficeResult"]["dailyBoxOfficeList"];
            /*
             * 		<dailyBoxOffice>
		<rank>1</rank> //순위
		<rankInten>20</rankInten> //전일대비 순위의 증감분
		<rankOldAndNew>OLD</rankOldAndNew> 랭킹 신규진입여부
		<movieNm>미션 파서블</movieNm> //영화제목
		<openDt>2021-02-17</openDt> //영화의 개봉일
		<salesAmt>220939760</salesAmt> //해당일의 매출액
		<audiCnt>26010</audiCnt> //해당일의 관객수
		<audiInten>25810</audiInten> //전일 대비 관객수 증감분
		<audiAcc>27189</audiAcc> //누적관객수
		<scrnCnt>891</scrnCnt> //스크린수
		<showCnt>3051</showCnt> //상영된 횟수
             */
            //이전에 리스트뷰에 있던 내용을 클리어한다!
            listView1.Items.Clear();

            for (int i = 0; i < xn.ChildNodes.Count; i++)
            {
                //richTextBox1.Text += xn.ChildNodes[i]["movieNm"].InnerText + "\n";
                ListViewItem lvi = new ListViewItem();
                lvi.Text = xn.ChildNodes[i]["rank"].InnerText;
                lvi.SubItems.Add(xn.ChildNodes[i]["rankInten"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["rankOldAndNew"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["movieNm"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["openDt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["salesAmt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["audiCnt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["audiInten"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["audiAcc"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["scrnCnt"].InnerText);
                lvi.SubItems.Add(xn.ChildNodes[i]["showCnt"].InnerText);

                listView1.Items.Add(lvi);
            }
        }
    }
}
