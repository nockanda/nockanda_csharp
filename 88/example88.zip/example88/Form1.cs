﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example88
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://"+textBox1.Text + "/nockanda/0");
            MessageBox.Show(response);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda/1");
            MessageBox.Show(response);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("LED", "OFF");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);

            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("LED", "ON");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);

            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led1/off");
            MessageBox.Show(response);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led1/on");
            MessageBox.Show(response);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led2/off");
            MessageBox.Show(response);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led2/on");
            MessageBox.Show(response);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led3/on");
            MessageBox.Show(response);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led3/off");
            MessageBox.Show(response);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led4/off");
            MessageBox.Show(response);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/led4/on");
            MessageBox.Show(response);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            if (checkBox1.Checked)
            {
                nvc.Add("led1", "on");
            }
            else
            {
                nvc.Add("led1", "off");
            }
            if (checkBox2.Checked)
            {
                nvc.Add("led2", "on");
            }
            else
            {
                nvc.Add("led2", "off");
            }
            if (checkBox3.Checked)
            {
                nvc.Add("led3", "on");
            }
            else
            {
                nvc.Add("led3", "off");
            }
            if (checkBox4.Checked)
            {
                nvc.Add("led4", "on");
            }
            else
            {
                nvc.Add("led4", "off");
            }
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);

            MessageBox.Show(Encoding.UTF8.GetString(response));
        }
    }
}
