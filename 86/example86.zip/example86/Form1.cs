﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Xml;

namespace example86
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
            //한국환경공단 OPENAPI RESTFUL 서버에서 정보를 제공받는 과정
            string your_key = textBox1.Text;

            string station_name = textBox2.Text;

            byte[] utf8 = Encoding.UTF8.GetBytes(station_name);

            station_name = "";
            for (int i = 0; i < utf8.Length; i++)
            {
                station_name += "%" + utf8[i].ToString("X");
            }

            string query = "http://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty?serviceKey="+your_key+"&returnType=xml&numOfRows=24&stationName="+ station_name + "&dataTerm=DAILY";

            //WebClient wc = new WebClient();
            WebRequest wrq = WebRequest.Create(query);
            wrq.Method = "GET";

            WebResponse wrs = wrq.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            //richTextBox1.Text = response;
            
            //xml로 파싱하는 과정!
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode nd = xd["response"]["body"]["items"];

            label3.Text = "가장최근 측정시간:" + nd.ChildNodes[0]["dataTime"].InnerText;

            //그래프를 그려보자!
            string[] element = { "pm10Value", "so2Value" , "coValue", "no2Value", "o3Value", "khaiValue" };
            string[] unit = { "ug/m3", "ppm", "ppm", "ppm", "ppm", "" };
            Color[] mycolor = { Color.Blue, Color.Red, Color.Green, Color.Magenta, Color.Gold, Color.DeepPink };
            Chart[] mychart = {chart1,chart2,chart3,chart4,chart5,chart6};

            for (int j = 0; j < mychart.Length; j++)
            {

                mychart[j].ChartAreas.Clear();
                mychart[j].Series.Clear();

                ChartArea ca = new ChartArea();
                //녹칸다의 취향!
                ca.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None;
                ca.AxisX.LabelStyle.Angle = 30;

                CustomLabel[] cl = new CustomLabel[nd.ChildNodes.Count];

                Series dataset = new Series();
                dataset.ChartType = SeriesChartType.Line;
                //dataset.IsVisibleInLegend = false;
                dataset.LegendText = nd.ChildNodes[0][element[j]].InnerText + unit[j];
                dataset.Color = mycolor[j];
                for (int i = 0; i < nd.ChildNodes.Count; i++)
                {
                    //richTextBox1.Text += nd.ChildNodes[i]["dataTime"].InnerText + "/";
                    //richTextBox1.Text += nd.ChildNodes[i]["pm10Value"].InnerText + "\n";
                    //갯수 10
                    //0 1 2 3 4 5 6 7 8 9
                    //9 8 7 6 5 4 3 2 1 0
                    string text = nd.ChildNodes[(nd.ChildNodes.Count - 1) - i][element[j]].InnerText;
                    float value = 0;
                    if (text == "-")
                    {
                        value = 0;
                    }
                    else
                    {
                        value = float.Parse(text);
                    }
                    
                    dataset.Points.AddXY(i + 1, value);

                    cl[i] = new CustomLabel();
                    cl[i].Text = nd.ChildNodes[(nd.ChildNodes.Count - 1) - i]["dataTime"].InnerText;
                    cl[i].FromPosition = i;
                    cl[i].ToPosition = i + 2;

                    ca.AxisX.CustomLabels.Add(cl[i]);
                }

                mychart[j].Series.Add(dataset);
                mychart[j].ChartAreas.Add(ca);
            }
            
        }
    }
}
