﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example124
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example124;Uid=root;Pwd=qwer1234;";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && serialPort1.IsOpen == false)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen == true)
            {
                serialPort1.Close();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //크로스 스레드
            textBox2.Text = serialPort1.ReadLine();

            string fid = textBox2.Text;

            //리딩한 지문에 MYSQL에 존재하느냐?
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from info where fid="+ fid;
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "info");


                if(ds.Tables[0].Rows.Count == 1)
                {
                    //MYSQL에 이미 저장이 된 경우
                    //DS안에 있는 정보로 출력한다!
                    textBox3.Text = ds.Tables[0].Rows[0]["name"].ToString(); //이름
                    textBox4.Text = ds.Tables[0].Rows[0]["age"].ToString(); //나이
                    textBox5.Text = ds.Tables[0].Rows[0]["ex"].ToString(); //성별
                    textBox6.Text = ds.Tables[0].Rows[0]["grade"].ToString(); //계급
                    textBox7.Text = ds.Tables[0].Rows[0]["jtg"].ToString(); //주특기
                    string image_name = ds.Tables[0].Rows[0]["image"].ToString();
                    textBox8.Text = image_name; //주특기
                    comboBox1.SelectedItem = ds.Tables[0].Rows[0]["level"].ToString(); //등급

                    //픽쳐박스에 이미지 새로뛰우기!
                    pictureBox1.Image = new Bitmap("./img/"+ image_name);


                    //유저의 히스토리를 기록한다!
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into history values("+ textBox2.Text + ",'"+ textBox3.Text + "','"+ textBox6.Text + "','"+DateTime.Now.ToString()+"')", conn);
                    msc.ExecuteNonQuery();
                }
                else
                {
                    //MYSQL에 없는 경우!
                    MessageBox.Show("등록을 해주세요!");
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    comboBox1.SelectedItem = "1";
                    pictureBox1.Image = null;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //MYSQL에 유저의 정보를 저장한다!
            if(textBox2.Text != "" &&
                textBox3.Text != "" &&
                textBox4.Text != "" &&
                textBox5.Text != "" &&
                textBox6.Text != "" &&
                textBox7.Text != "" &&
                textBox8.Text != ""
                )
            {
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    conn.Open();
                    MySqlCommand msc = new MySqlCommand("insert into info values("+ textBox2.Text 
                        + ",'"+ textBox3.Text 
                        + "',"+ textBox4.Text 
                        + ",'"+ textBox5.Text
                        + "','"+ textBox6.Text 
                        + "','"+ textBox7.Text
                        + "','"+ comboBox1.SelectedItem.ToString() 
                        + "','"+ textBox8.Text 
                        + "','"+ DateTime.Now.ToString() +"')", conn);
                    msc.ExecuteNonQuery();
                }
                MessageBox.Show("데이터 들어간다!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileInfo fi = new FileInfo(openFileDialog1.FileName);
                

                textBox8.Text = fi.Name;

                //픽쳐박스에 이미지를 집어넣는다!
                pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //리스트뷰를 초기화한다!
            listView1.Items.Clear();

            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from history order by date desc limit 10";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "history");

                for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ds.Tables[0].Rows[i]["fid"].ToString();

                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["name"].ToString());
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["grade"].ToString());
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["date"].ToString());

                    listView1.Items.Add(lvi);
                }
            }
        }
    }
}
