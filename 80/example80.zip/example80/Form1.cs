﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;

namespace example80
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MJPEGStream stream;
        private void button1_Click(object sender, EventArgs e)
        {
            if (stream.IsRunning) stream.Stop();
            stream.Start();
        }
        private void video_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {

            Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
            pictureBox1.Image = bitmap;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (stream.IsRunning)
            {
                stream.Stop();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            stream = new MJPEGStream("http://192.168.0.15:81/stream");
            stream.NewFrame += new NewFrameEventHandler(video_NewFrame);
        }
    }
}
