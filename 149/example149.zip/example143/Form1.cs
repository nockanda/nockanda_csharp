﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace example143
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example149;Uid=root;Pwd=qwer1234;";
        bool server_run = true;
        HttpListener listener;
        Thread t;


        public class Product
        {
            public string result { get; set; }
            public string name { get; set; }
            public string price { get; set; }
            public string dc { get; set; }
        }

        public Form1()
        {
            InitializeComponent();
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;

                richTextBox1.Text += request.RawUrl + "\n";

                string barcode = request.RawUrl.Replace("/", "");


                string responseString = "";
                //바코드를 이용해서 DB를 조회한다!
                //검색구문
                using (MySqlConnection conn = new MySqlConnection(Conn))
                {
                    DataSet ds = new DataSet();
                    string sql = "select * from product where barcode='"+ barcode + "'";
                    MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                    adpt.Fill(ds, "product");

                    Product pd = new Product();
                    //결과값이 존재하냐? 안하냐?
                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        //검색결과가 없다
                        
                        pd.result = "NO";
                        pd.name = "";
                        pd.price = "";
                        pd.dc = "";

                    }
                    else
                    {
                        //검색결과가 있는데 딱 1개
                        //상품명과 가격을 출력해서 response한다!

                        pd.result = "OK";
                        pd.name = ds.Tables[0].Rows[0]["name"].ToString();
                        pd.price = ds.Tables[0].Rows[0]["price"].ToString();
                        pd.dc = ds.Tables[0].Rows[0]["dc"].ToString();
                    }

                    //JSON으로 변환해서 response
                    responseString = JsonConvert.SerializeObject(pd) + "\n";

                }

                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                // Construct a response.
                
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from product where barcode='" + textBox1.Text + "'";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "product");

                if(ds.Tables[0].Rows.Count == 0)
                {
                    //조회결과 없음
                    MessageBox.Show("검색결과가 없습니다!");
                }
                else
                {
                    //출력
                    textBox2.Text = ds.Tables[0].Rows[0]["name"].ToString();
                    textBox3.Text = ds.Tables[0].Rows[0]["price"].ToString();
                    textBox4.Text = ds.Tables[0].Rows[0]["dc"].ToString();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //수정구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("update product set dc=" + textBox4.Text + " where barcode='" + textBox1.Text + "'", conn);
                msc.ExecuteNonQuery();
            }

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}

