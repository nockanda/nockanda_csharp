﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example51
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[3];
                serialPort1.Read(recv, 0, 3);
                int value = (recv[0] << 16) | (recv[1] << 8) | (recv[2]);
                label1.Text = value.ToString("X");

                if(value == 0xFF30CF)
                {
                    //1
                    textBox2.Text += "1";
                }else if(value == 0xFF18E7)
                {
                    //2
                    textBox2.Text += "2";
                }
                else if (value == 0xFF7A85)
                {
                    //3
                    textBox2.Text += "3";
                }
                else if (value == 0xFF10EF)
                {
                    //4
                    textBox2.Text += "4";
                }
                else if (value == 0xFF38C7)
                {
                    //5
                    textBox2.Text += "5";
                }
                else if (value == 0xFF5AA5)
                {
                    //6
                    textBox2.Text += "6";
                }
                else if (value == 0xFF42BD)
                {
                    //7
                    textBox2.Text += "7";
                }
                else if (value == 0xFF4AB5)
                {
                    //8
                    textBox2.Text += "8";
                }
                else if (value == 0xFF52AD)
                {
                    //9
                    textBox2.Text += "9";
                }
                else if (value == 0xFF6897)
                {
                    //0
                    textBox2.Text += "0";
                }
                else if (value == 0xFF9867)
                {
                    //100
                    textBox2.Text += "100";
                }
                else if (value == 0xFFB04F)
                {
                    //200
                    textBox2.Text += "200";
                }
                else if (value == 0xFFA857)
                {
                    //+
                    int v = trackBar1.Value;
                    v++;
                    if (v > 10) v = 10;
                    trackBar1.Value = v;
                }
                else if (value == 0xFFE01F)
                {
                    //-
                    int v = trackBar1.Value;
                    v--;
                    if (v < 0) v = 0;
                    trackBar1.Value = v;
                }
                else if (value == 0xFF906F)
                {
                    //eq
                    trackBar1.Value = 5;
                }
                else if (value == 0xFF22DD)
                {
                    // |◀◀
                    label4.Text = "이전곡";
                }
                else if (value == 0xFF02FD)
                {
                    // ▶▶|
                    label4.Text = "다음곡";
                }
                else if (value == 0xFFC23D)
                {
                    //  ▶||
                    label4.Text = "재생";
                }
                else if (value == 0xFFA25D)
                {
                    //  CH-
                    pictureBox1.BackColor = Color.Red;
                }
                else if (value == 0xFF629D)
                {
                    // CH
                    pictureBox1.BackColor = Color.Blue;
                }
                else if (value == 0xFFE21D)
                {
                    //CH+
                    pictureBox1.BackColor = Color.Green;
                }
    
            }
        }
    }
}
