﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example105
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독정보를 등록해보자!
            client.Subscribe(new string[] { "outNOCK" }, new byte[] { 0 });
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            label1.Text = ReceivedMessage;

            /*
            this.Invoke(new MethodInvoker(delegate ()
            {
                
                label1.Text = ReceivedMessage;
            }));
            */
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = hScrollBar1.Value.ToString();
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar2.Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/fnd1", Encoding.UTF8.GetBytes(hScrollBar1.Value.ToString()), 0, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/fnd2", Encoding.UTF8.GetBytes(hScrollBar2.Value.ToString()), 0, true);
        }
    }
}
