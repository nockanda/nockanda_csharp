﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example69
{
    public partial class Form1 : Form
    {
        //0=비밀번호입력 대기중/1=비밀번호입력중
        //2=RFID대기중//3=지문대기중
        int state = 0;
        int system_pw = 123456;
        int input_pw = 0;
        DateTime dt;
        user[] myuser = new user[7]; //총7명
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
                timer1.Start();
            }
        }

        int user_search(byte[] input)
        {
            //myuser[0].rfid_check(rfid)
            int i = 0;
            for (i = 0; i < myuser.Length; i++)
            {
                if (myuser[i].rfid_check(input))
                {
                    //일치하는 경우
                    break;
                }
            }

            return i;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[5];
                serialPort1.Read(recv, 0, 5);
                if(recv[0] == 0x00)
                {
                    //4x4키패드로 부터 오는 값
                    input_pw = input_pw * 10 + ((char)recv[1] - '0');
                    //richTextBox1.Text += input_pw + "\n";
                    state = 1;
                    dt = DateTime.Now.AddSeconds(5); //요때 시간을 측정
                    if (input_pw / 100000 > 0)
                    {
                        //여섯자리인 경우
                        if(input_pw == system_pw)
                        {
                            //비밀번호 맞춤
                            //richTextBox1.Text += "비밀번호가 일치합니다!\n";
                            state = 2;
                            dt = DateTime.Now.AddSeconds(5);
                        }
                        else
                        {
                            //richTextBox1.Text += "비밀번호가 틀렸습니다!\n";
                            state = 0;
                        }
                        
                        input_pw = 0;
                    }
                }else if (recv[0] == 0x01 && state == 2)
                {
                    textBox3.Text = "";
                    for(int i = 1; i < 5; i++)
                    {
                        textBox3.Text += recv[i].ToString("X") +" ";
                    }
                    byte[] rfid = new byte[4];
                    
                    for(int i = 0; i < 4; i++)
                    {
                        rfid[i] = recv[i + 1];
                        //label1.Text += rfid[i].ToString("X");
                    }

                    //label1.Text = user_search(rfid).ToString();
                    int index = user_search(rfid);
                    textBox4.Text = myuser[index].name;
                    textBox5.Text = myuser[index].level;
                    textBox6.Text = myuser[index].fingernum.ToString();

                    state = 3;
                    dt = DateTime.Now.AddSeconds(10);
                }
                else if (recv[0] == 0x02 && state == 3)
                {
                    //지문
                    //label1.Text = recv[1].ToString();
                    if(textBox6.Text == recv[1].ToString())
                    {
                        //지문이 일치하는 경우
                        state = 4;
                    }
                    else
                    {
                        //틀린경우
                        state = 0;
                        textbox_clear();
                    }
                }


            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (state == 0)
            {
                //초기상태
                label7.Text = "시스템이 대기중입니다!";
            } else if (state == 1)
            {
                //비밀번호를 입력중
                label7.Text = "비밀번호 입력 중입니다!";
                textBox2.Text = input_pw.ToString();
                label1.Text = (dt - DateTime.Now).TotalSeconds.ToString();
                if((dt - DateTime.Now).TotalSeconds <= 0)
                {
                    label1.Text = "0";
                    state = 0;
                    input_pw = 0;
                    textbox_clear();
                }
            }
            else if(state == 2)
            {
                //비밀번호 인증 완료
                label7.Text = "RFID를 대기중입니다!";
                label1.Text = (dt - DateTime.Now).TotalSeconds.ToString();
                if ((dt - DateTime.Now).TotalSeconds <= 0)
                {
                    label1.Text = "0";
                    state = 0;
                    textbox_clear();
                }
            }
            else if(state == 3)
            {
                label7.Text = "지문입력을 대기중입니다!";
                label1.Text = (dt - DateTime.Now).TotalSeconds.ToString();
                if ((dt - DateTime.Now).TotalSeconds <= 0)
                {
                    label1.Text = "0";
                    state = 0;
                    textbox_clear();
                }
            }else if(state == 4)
            {
                label7.Text = "모든 인증이 완료되었습니다!";
            }
        }
        void textbox_clear()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            String tag1 = " a7 3c bb 7a"; //열쇠고리
            String tag2 = " d4 6d a2 2a"; //1
            String tag3 = " 4d 94 a0 3d"; //2
            String tag4 = " 1c 75 84 3d"; //3
            String tag5 = " bf 5f a0 3d"; //4
            String tag6 = " 17 83 a0 3d"; //5
            String tag7 = " 6b 08 a0 3d"; //6
            */

            for(int i = 0; i < myuser.Length; i++)
            {
                myuser[i] = new user();
            }

            myuser[0].name = "차태식";
            myuser[0].level = "하사";
            myuser[0].fingernum = 1;
            myuser[0].rfid[0] = 0xA7;
            myuser[0].rfid[1] = 0x3C;
            myuser[0].rfid[2] = 0xBB;
            myuser[0].rfid[3] = 0x7A;
            myuser[1].name = "녹칸다";
            myuser[1].level = "중령";
            myuser[1].fingernum = 2;
            myuser[1].rfid[0] = 0xD4;
            myuser[1].rfid[1] = 0x6D;
            myuser[1].rfid[2] = 0xA2;
            myuser[1].rfid[3] = 0x2A;
            myuser[2].name = "김철수";
            myuser[2].level = "중령";
            myuser[2].fingernum = 3;
            myuser[2].rfid[0] = 0x4D;
            myuser[2].rfid[1] = 0x94;
            myuser[2].rfid[2] = 0xA0;
            myuser[2].rfid[3] = 0x3D;
            myuser[3].name = "김미영";
            myuser[3].level = "중령";
            myuser[3].fingernum = 3;
            myuser[3].rfid[0] = 0x1C;
            myuser[3].rfid[1] = 0x75;
            myuser[3].rfid[2] = 0x84;
            myuser[3].rfid[3] = 0x3D;
            myuser[4].name = "박민수";
            myuser[4].level = "중령";
            myuser[4].fingernum = 4;
            myuser[4].rfid[0] = 0xBF;
            myuser[4].rfid[1] = 0x5F;
            myuser[4].rfid[2] = 0xA0;
            myuser[4].rfid[3] = 0x3D;
            myuser[5].name = "홍길순";
            myuser[5].level = "중령";
            myuser[5].fingernum = 5;
            myuser[5].rfid[0] = 0x17;
            myuser[5].rfid[1] = 0x83;
            myuser[5].rfid[2] = 0xA0;
            myuser[5].rfid[3] = 0x3D;
            myuser[6].name = "짠짜라";
            myuser[6].level = "중령";
            myuser[6].fingernum = 6;
            myuser[6].rfid[0] = 0x6B;
            myuser[6].rfid[1] = 0x08;
            myuser[6].rfid[2] = 0xA0;
            myuser[6].rfid[3] = 0x3D;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            state = 0;
            textbox_clear();
        }
    }
    class user
    {
        public string name = "";//이름
        public string level = "";//계급
        public byte[] rfid = new byte[4];
        public int fingernum = 0;

        public bool rfid_check(byte[] input)
        {
            bool output = true;
            for(int i = 0; i < 4; i++)
            {
                if(rfid[i] != input[i])
                {
                    output = false;
                }
            }

            return output;
        }
    }
}
