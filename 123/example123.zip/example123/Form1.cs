﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            //바코드 리더기의 종료 문자는 엔터이다
            //=>바코드 리더기의 한줄 입력이 끝이난경우다!
            if(e.KeyCode == Keys.Enter)
            {
                string isbn = textBox3.Text;
                textBox3.Text = "";

                string your_client_id = textBox1.Text;
                string your_client_secret = textBox2.Text;

                
                //네이버에 ISBN을 가지고 request한다!
                //쿼리를 만들자
                string query = "https://openapi.naver.com/v1/search/book_adv.xml?d_isbn=" + isbn;

                //request
                WebRequest wr = WebRequest.Create(query);
                wr.Method = "GET";
                wr.Headers.Add("X-Naver-Client-Id", your_client_id);
                wr.Headers.Add("X-Naver-Client-Secret", your_client_secret);

                WebResponse wrs = wr.GetResponse();
                Stream s = wrs.GetResponseStream();
                StreamReader sr = new StreamReader(s);

                string response = sr.ReadToEnd();

                //richTextBox1.Text = response;

                XmlDocument xd = new XmlDocument();
                xd.LoadXml(response);

                XmlNode xn = xd["rss"]["channel"];

                //0번 3번
                label12.Text = xn.ChildNodes[0].InnerText;
                label13.Text = xn.ChildNodes[3].InnerText;

                //8번
                textBox4.Text = xn.ChildNodes[7]["title"].InnerText;
                textBox5.Text = xn.ChildNodes[7]["author"].InnerText;
                textBox6.Text = xn.ChildNodes[7]["price"].InnerText;
                textBox7.Text = xn.ChildNodes[7]["discount"].InnerText;
                textBox8.Text = xn.ChildNodes[7]["publisher"].InnerText;
                textBox9.Text = xn.ChildNodes[7]["pubdate"].InnerText;
                textBox10.Text = xn.ChildNodes[7]["isbn"].InnerText;

                richTextBox1.Text = xn.ChildNodes[7]["description"].InnerText;

                string image_path = xn.ChildNodes[7]["image"].InnerText;
                if(image_path != "")
                {
                    pictureBox1.Load(image_path);
                }
            }
        }
    }
}
