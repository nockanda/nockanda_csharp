﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[6];
                serialPort1.Read(recv, 0, 6);

                float t = ((recv[0] * 256) + recv[1]) / 100.0f;
                float h = ((recv[2] * 256) + recv[3]) / 100.0f;
                float hic = ((recv[4] * 256) + recv[5]) / 100.0f;
                label6.Text = t.ToString();
                label5.Text = h.ToString();
                label4.Text = hic.ToString();

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(t.ToString());
                lvi.SubItems.Add(h.ToString());
                lvi.SubItems.Add(hic.ToString());

                listView1.Items.Add(lvi);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string path = "output.csv";
            FileInfo fi = new FileInfo(path);
            if (fi.Exists)
            {
                fi.Delete();
            }

            FileStream fs = new FileStream(path, FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fs);

            for(int i = 0; i < listView1.Items.Count; i++)
            {
                //listView1.Items[i].SubItems[0]
                sw.WriteLine(listView1.Items[i].SubItems[0].Text + "," + listView1.Items[i].SubItems[1].Text + "," + listView1.Items[i].SubItems[2].Text + "," + listView1.Items[i].SubItems[3].Text);
            }

            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();
            MessageBox.Show("다했습니다!");
        }
    }
}
