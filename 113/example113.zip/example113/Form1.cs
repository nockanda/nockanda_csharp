﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example113
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        int chart1_x = 0;
        int chart2_x = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);


            //구독정보를 지정
            //"nockanda/tsample"
            string[] topic = { "nockanda/tsample", "nockanda/wh", "nockanda/w", "nockanda/i" };
            byte[] qos = { 0, 0, 0, 0 };
            client.Subscribe(topic, qos);
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/tsample")
            {
                label1.Text = "샘플링간격=" + ReceivedMessage + "ms";
            }
            else if(e.Topic == "nockanda/wh")
            {
                label2.Text = "누적전력량=" + ReceivedMessage + "Wh";
            }
            else if (e.Topic == "nockanda/w")
            {
                label3.Text = "순간전력=" + ReceivedMessage + "W";


                //순간전력에 대한 chart를 그려보자!
                double value = double.Parse(ReceivedMessage);
                chart1.Series[0].Points.AddXY(chart1_x, value);

                //윈도우 사이즈를 20으로 잡자!
                if(chart1.Series[0].Points.Count > 20)
                {
                    chart1.Series[0].Points.RemoveAt(0);
                }

                chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;
                chart1.ChartAreas[0].AxisX.Maximum = chart1_x;

                double max = 0;
                for(int i = 0; i < chart1.Series[0].Points.Count; i++)
                {
                    if(max < chart1.Series[0].Points[i].YValues[0])
                    {
                        max = chart1.Series[0].Points[i].YValues[0];
                    }
                }

                chart1.ChartAreas[0].AxisY.Maximum = max + 2;

                chart1_x++;
            }
            else if (e.Topic == "nockanda/i")
            {
                label4.Text = "순간전류=" + ReceivedMessage + "A";

                //순간전력에 대한 chart를 그려보자!
                double value = double.Parse(ReceivedMessage);
                chart2.Series[0].Points.AddXY(chart2_x, value);

                //윈도우 사이즈를 20으로 잡자!
                if (chart2.Series[0].Points.Count > 20)
                {
                    chart2.Series[0].Points.RemoveAt(0);
                }

                chart2.ChartAreas[0].AxisX.Minimum = chart2.Series[0].Points[0].XValue;
                chart2.ChartAreas[0].AxisX.Maximum = chart2_x;

                double max = 0;
                for (int i = 0; i < chart2.Series[0].Points.Count; i++)
                {
                    if (max < chart2.Series[0].Points[i].YValues[0])
                    {
                        max = chart2.Series[0].Points[i].YValues[0];
                    }
                }

                chart2.ChartAreas[0].AxisY.Maximum = max + 0.1;

                chart2_x++;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/relay", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/relay", Encoding.UTF8.GetBytes("0"), 0, true);
        }
    }
}
