﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example73
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Rectangle r = new Rectangle(0, 0, 500, 500);
            g.DrawEllipse(Pens.Black, r);

            g.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Rectangle r = new Rectangle(0, 0, 500, 500);
            g.DrawEllipse(Pens.Black, r);
            g.DrawLine(Pens.Black, r.Width / 2, 0, r.Width / 2, r.Height);
            g.DrawLine(Pens.Black, 0, r.Height / 2, r.Width, r.Height / 2);

            g.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Rectangle r = new Rectangle(0, 0, 500, 500);
            g.DrawLine(Pens.Black, r.Width / 2, 0, r.Width / 2, r.Height);
            g.DrawLine(Pens.Black, 0, r.Height / 2, r.Width, r.Height / 2);
            g.DrawEllipse(Pens.Black, r);
            for (int i = 45; i < 360; i += 90)
            {
                double radian = i * (Math.PI / 180);
                double x = (r.Width / 2) * Math.Cos(radian);
                double y = (r.Width / 2) * Math.Sin(radian);
                g.DrawLine(Pens.Red, (r.Width / 2), (r.Width / 2), (r.Width / 2) + (int)x, (r.Width / 2) + (int)y);
            }

            g.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Rectangle r = new Rectangle(0, 0, 500, 500);
            g.DrawEllipse(Pens.Black, r);
            int jokak = 10;
            for (int i = 0; i <= 360; i += 360/jokak)
            {
                double radian = i * (Math.PI / 180);
                double x = (r.Width / 2) * Math.Cos(radian);
                double y = (r.Width / 2) * Math.Sin(radian);
                g.DrawLine(Pens.Red, (r.Width / 2), (r.Width / 2), (r.Width / 2) + (int)x, (r.Width / 2) + (int)y);
            }

            g.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();

            Rectangle r = new Rectangle(0, 0, 500, 500);
            g.DrawEllipse(Pens.Black, r);
            int jokak = 12;
            for (int i = 0; i <= 360; i += 360 / jokak)
            {
                double radian = i * (Math.PI / 180);
                double x = (r.Width / 2) * Math.Cos(radian);
                double y = (r.Width / 2) * Math.Sin(radian);
                g.DrawLine(Pens.Red, (r.Width / 2), (r.Width / 2), (r.Width / 2) + (int)x, (r.Width / 2) + (int)y);
            }

            g.Dispose();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            //clear
            g.FillRectangle(Brushes.White, 0, 0, pictureBox1.Width, pictureBox1.Height);

            Rectangle r = new Rectangle(0, 0, 500, 500);
            g.DrawEllipse(Pens.Black, r);
            int jokak = int.Parse(textBox1.Text);
            for (int i = 0; i <= 360; i += 360 / jokak)
            {
                double radian = i * (Math.PI / 180);
                double x = (r.Width / 2) * Math.Cos(radian);
                double y = (r.Width / 2) * Math.Sin(radian);
                g.DrawLine(Pens.Red, (r.Width / 2), (r.Width / 2), (r.Width / 2) + (int)x, (r.Width / 2) + (int)y);
            }

            g.Dispose();
        }
    }
}
