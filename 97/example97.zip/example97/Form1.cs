﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example97
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int x_pos = 0;

        private void button1_Click(object sender, EventArgs e)
        {
                       
            
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");

            label2.Text = "CDS : " + response;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                //타이머1이 작동중인 상태라면~
                timer1.Stop();
            }
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");

            int cds = int.Parse(response);
            if (cds > hScrollBar1.Value)
            {
                //낮
                label2.Text = "CDS : " + response + "(DAY!)";
            }
            else
            {
                //밤
                label2.Text = "CDS : " + response + "(NIGHT!)";
            }
            //리스트뷰에 값추가
            ListViewItem lvi = new ListViewItem();
            lvi.Text = DateTime.Now.ToString();
            lvi.SubItems.Add(response);
            listView1.Items.Add(lvi);

            //새로운 값을 하나 추가한다!
            chart1.Series[0].Points.AddXY(x_pos, cds);

            //윈도우 사이즈는 일단 10으로 두고 해보자!
            if(chart1.Series[0].Points.Count > 10)
            {
                //제일 과거의 데이터 1개를 지운다!
                chart1.Series[0].Points.RemoveAt(0);
            }

            //전체 그래프 윈도우를 쉬프트 한다!
            chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;
            chart1.ChartAreas[0].AxisX.Maximum = x_pos;

            x_pos++;
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = "임계값 : " + hScrollBar1.Value.ToString();
        }
    }
}
