﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example57
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Random rd = new Random(100100);
            Random rd = new Random();
            byte[] lotto = new byte[6];
            //10 20 0 0 0 0

            //richTextBox1.Text = "";
            for(int i = 0; i < 6;)
            {
                //추출한 숫자의 갯수 
                //lotto[?] = 랜덤숫자
                byte num = (byte)rd.Next(1, 46);
                bool jungbok = false;
                //2개의 값이 뽑힌상태
                //2
                //for (int j = 0; j < lotto.Lenght; j++)
                for (int j = 0;j< (i+1); j++)
                {
                    if(lotto[j] == num)
                    {
                        //중복인경우
                        //richTextBox1.Text += num + " 중복발생!\n";
                        jungbok = true;
                        break;
                    }
                }
                if(jungbok == false)
                {
                    //단 하나라도 중복이 없는경우
                    lotto[i] = num;
                    i++;
                }
            }
            //richTextBox1.Text += "-----------------\n";
            Array.Sort(lotto);
            label1.Text = "";
            for (int i=0;i< lotto.Length; i++)
            {
                label1.Text += lotto[i].ToString() + ",";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<int> mylist = new List<int>();
            Random rd = new Random();
            List<int> mylotto = new List<int>();
            //0~44 : 1~45
            for (int i = 1; i <= 45; i++)
            {
                mylist.Add(i);
                //richTextBox1.Text += i + ",";
            }
            //richTextBox1.Text += "\n--------------\n";

            for(int i = 0; i < 6; i++)
            {
                int num = rd.Next(0, 45-i);//0~44
                //richTextBox1.Text += "추첨한 숫자 ="+ mylist[num] + "],";
                mylotto.Add(mylist[num]);
                mylist.RemoveAt(num);
                for (int j = 0; j < mylist.Count; j++)
                {
                    
                    //richTextBox1.Text += mylist[j] + ",";
                }
                //richTextBox1.Text += "\n";
            }
            //richTextBox1.Text += "\n";
            mylotto.Sort();
            label1.Text = "";
            for(int i = 0; i < mylotto.Count; i++)
            {
                label1.Text += mylotto[i] + ",";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            List<int> mylist = new List<int>();
            Random rd = new Random();
            List<int> mylotto = new List<int>();
            //0~44 : 1~45
            for (int i = 1; i <= 45; i++)
            {
                mylist.Add(i);
                //richTextBox1.Text += i + ",";
            }
            //richTextBox1.Text += "\n--------------\n";

            for (int i = 0; i < 6; i++)
            {
                int num = rd.Next(0, 45 - i);//0~44
                //richTextBox1.Text += "추첨한 숫자 ="+ mylist[num] + "],";
                mylotto.Add(mylist[num]);
                mylist.RemoveAt(num);
                for (int j = 0; j < mylist.Count; j++)
                {

                    //richTextBox1.Text += mylist[j] + ",";
                }
                //richTextBox1.Text += "\n";
            }
            //richTextBox1.Text += "\n";
            mylotto.Sort();
            label1.Text = "";
            for (int i = 0; i < mylotto.Count; i++)
            {
                label1.Text += mylotto[i] + ",";
            }
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            timer1.Start();
        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            timer1.Stop();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[6];
                serialPort1.Read(recv, 0, 6);
                //Array.Sort(recv);
                label2.Text = "";
                for(int i = 0; i < recv.Length; i++)
                {
                    label2.Text += recv[i] + ",";
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = { 0 };
                serialPort1.Write(send, 0, 1);
            }
        }
    }
}
