﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example104
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //subscribe topic을 여기서 추가해보자!
            client.Subscribe(new string[] { "outNOCK", "outNOCK1", "outNOCK2" }, new byte[] { 0, 0, 0 });
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if (e.Topic == "outNOCK")
            {
                //C#104-1
                label1.Text = ReceivedMessage;
            }else if(e.Topic == "outNOCK1")
            {
                //C#104-2
                label2.Text = ReceivedMessage;
            }else if(e.Topic == "outNOCK2")
            {
                //C#104-3
                label3.Text = ReceivedMessage;
                listBox1.Items.Add(ReceivedMessage);
            }

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("inNOCK", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("inNOCK", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room1", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room1", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room2", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room2", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room3", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room3", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room4", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/room4", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/roomall", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/roomall", Encoding.UTF8.GetBytes("1"), 0, true);
        }
    }
}
