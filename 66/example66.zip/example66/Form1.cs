﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example66
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string han_cho = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ";
        string han_jung = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ";
        string han_jong = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ";
        //한글로 표현가능한 초성,중성,중송
        //초성19 ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ
        //중성21 ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ
        //종성28 (x)ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ
        private void button1_Click(object sender, EventArgs e)
        {
            

            for(char i = '가'; i <= '갛'; i++)
            {
                richTextBox1.Text += i;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (char i = '나'; i <= '낳'; i++)
            {
                richTextBox1.Text += i;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string output = "";
            for(char i = '가'; i <= '힣'; i++)
            {
                output += i;
            }

            richTextBox1.Text = output;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = ((int)'가').ToString("X");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < 28; i++)
            {
                //가 AC00
                //갛 AC27
                richTextBox1.Text += ((char)(0xAC00 + i)).ToString();
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //가나다라마바사아자차카타파하
            //초성 19 중성 21 종성28
            for(int i =0;i< 19; i++)
            {
                richTextBox1.Text += (char)(0xAC00 + (588 * i));
            }
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < 21; i++)
            {
                richTextBox1.Text += (char)(0xAC00 + (28*i));
            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //가 = AC00
            UInt16 gan = '간' - 0xAC00;

            //초성 588(21*28)만큼 차이
            //중성 28만큼 차이
            //종성 
            int chosung = gan / 588;
            int jungsung = (gan % 588) / 28;
            int jongsung = gan % 28;
            //richTextBox1.Text = chosung.ToString()+"\n";
            //richTextBox1.Text += jungsung.ToString() + "\n";
            //richTextBox1.Text += jongsung.ToString() + "\n";
            richTextBox1.Text += han_cho[chosung];
            richTextBox1.Text += han_jung[jungsung];
            richTextBox1.Text += han_jong[jongsung];
        }

        char[] bunhae(char input)
        {
            char[] output = new char[3];

            if (input < 0xAC00 || input > 0xD7A3)
            {
                //한글이 아님
                output[0] = ' ';
                output[1] = ' ';
                output[2] = ' ';
            }
            else
            {

                int gan = input - 0xAC00;

                //초성 588(21*28)만큼 차이
                //중성 28만큼 차이
                //종성 
                int chosung = gan / 588;
                int jungsung = (gan % 588) / 28;
                int jongsung = gan % 28;

                output[0] = han_cho[chosung];
                output[1] = han_jung[jungsung];
                output[2] = han_jong[jongsung];
            }
            return output;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
            {
                string input = textBox1.Text;
                for(int i = 0; i < input.Length; i++)
                {
                    char[] a = bunhae(input[i]);
                    for(int j = 0; j < a.Length; j++)
                    {
                        richTextBox1.Text += a[j];
                    }
                }
            }
        }


        char jorip(char[] input)
        {
            char output = ' ';
            //ㄱㅏㄴ
            //
            //ㄱㅏㄴ
            int cho_index = han_cho.IndexOf(input[0]);
            int jung_index = han_jung.IndexOf(input[1]);
            int jong_index = han_jong.IndexOf(input[2]);

            if (cho_index == -1 || jung_index == -1 || jong_index == -1)
            {
                //조합할 수 없는 형태의 문자이다!
                output = ' ';
            }
            else
            {
                output = (char)(0xAC00 + (cho_index * 588) + (jung_index * 28) + jong_index);
            }
            return output;
        }
        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                string data = textBox2.Text;
                if (!(data.Length % 3 == 0))
                {
                    MessageBox.Show("갯수가 안맞는데요?");
                    return;
                }

                for (int i = 0; i < data.Length; i += 3)
                {
                    char[] input = { data[i], data[i + 1], data[i + 2] };
                    richTextBox1.Text += jorip(input);
                }

            }
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = ((int)'가').ToString("X") + "~" + ((int)'힣').ToString("X");
        }
    }
}
