﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example46
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string tag1 = " a7 3c bb 7a"; //열쇠고리
        string tag2 = " d4 6d a2 2a"; //1
        string tag3 = " 4d 94 a0 3d"; //2
        string tag4 = " 1c 75 84 3d"; //3
        string tag5 = " bf 5f a0 3d"; //4
        string tag6 = " 17 83 a0 3d"; //5
        string tag7 = " 6b 08 a0 3d"; //6

        health[] club = new health[7];

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                string input = serialPort1.ReadLine();
                
                for(int i = 0; i < club.Length; i++)
                {
                    if(input.IndexOf(club[i].cardid) != -1)
                    {
                        //richTextBox1.Text = "이름:" + club[i].name;
                        textBox2.Text = club[i].name;
                        if (club[i].s == 0) textBox3.Text = "남";
                        else textBox3.Text = "여";
                        textBox4.Text = club[i].age.ToString();
                        textBox5.Text = club[i].room.ToString();
                        textBox6.Text = club[i].dt.ToString();
                        //richTextBox1.Text += "\n나이:" + club[i].age;
                        //richTextBox1.Text += "\n락커룸번호:" + club[i].room;
                        //richTextBox1.Text += "\n접수기간:" + club[i].dt;
                        break;
                    }
                }
            }
        }
        class health
        {
            //이름 성별 나이 락커룸번호 카드ID 기간
            public string name;
            public byte s;  //0이 남자 1이 여자
            public byte age;
            public byte room;
            public string cardid;
            public DateTime dt;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            club[0] = new health();
            club[0].name = "홍길동";
            club[0].s = 0;
            club[0].age = 19;
            club[0].room = 101;
            club[0].cardid = tag1;
            club[0].dt = DateTime.Now.AddDays(30);

            club[1] = new health();
            club[1].name = "김땡땡";
            club[1].s = 1;
            club[1].age = 22;
            club[1].room = 201;
            club[1].cardid = tag2;
            club[1].dt = DateTime.Now.AddDays(20);

            club[2] = new health();
            club[2].name = "김철수";
            club[2].s = 0;
            club[2].age = 33;
            club[2].room = 105;
            club[2].cardid = tag3;
            club[2].dt = DateTime.Now.AddDays(60);

            club[3] = new health();
            club[3].name = "담덕";
            club[3].s = 0;
            club[3].age = 39;
            club[3].room = 108;
            club[3].cardid = tag4;
            club[3].dt = DateTime.Now.AddDays(10);

            club[4] = new health();
            club[4].name = "신사임당";
            club[4].s = 1;
            club[4].age = 55;
            club[4].room = 206;
            club[4].cardid = tag5;
            club[4].dt = DateTime.Now.AddDays(80);

            club[5] = new health();
            club[5].name = "홍금보";
            club[5].s = 0;
            club[5].age = 25;
            club[5].room = 112;
            club[5].cardid = tag6;
            club[5].dt = DateTime.Now.AddDays(60);

            club[6] = new health();
            club[6].name = "김장미";
            club[6].s = 1;
            club[6].age = 30;
            club[6].room = 209;
            club[6].cardid = tag7;
            club[6].dt = DateTime.Now.AddDays(45);
        }
    }
}
