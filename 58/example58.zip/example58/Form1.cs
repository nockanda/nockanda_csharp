﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example58
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && textBox2.Text != "")
            {
                byte[] send = new byte[textBox2.Text.Length + 1];
                for (int i = 0; i < textBox2.Text.Length; i++)
                {
                    send[i] = (byte)textBox2.Text[i];
                }
                send[textBox2.Text.Length] = (byte)'\n';

                serialPort1.Write(send, 0, textBox2.Text.Length + 1);
            }
        }

        bool isbusy = false;
        private void button3_Click(object sender, EventArgs e)
        {
            Bitmap bt = new Bitmap(128, 32);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(Color.Black);

            g.FillEllipse(Brushes.White, 48, 0, 32, 32);

            g.Dispose();
            //isbusy
            for (int y = 0; y < bt.Height; y++)
            {
                byte pixel = 0;
                byte[] data = new byte[17];
                int data_position = 1;
                data[0] = (byte)y;
                //data[data_position]
                for (int x = 0; x < bt.Width; x++)
                {
                    //00001111 = 0x0F
                    if ((x + 1) % 8 == 0)
                    {
                        if (bt.GetPixel(x, y).R == 0)
                        {
                            //검정색
                            pixel = (byte)(pixel << 1);
                        }
                        else
                        {
                            //흰색
                            pixel = (byte)((pixel << 1) | 0x01);

                        }
                        data[data_position] = pixel;
                        data_position++;
                        //richTextBox1.Text += pixel.ToString("X") + ",";

                        //richTextBox1.Text += bt.GetPixel(x, y).R + "\n";
                    }
                    else
                    {
                        //richTextBox1.Text += bt.GetPixel(x, y).R + ",";
                        if (bt.GetPixel(x, y).R == 0)
                        {
                            //검정색
                            pixel = (byte)(pixel << 1);
                        }
                        else
                        {
                            //흰색
                            pixel = (byte)((pixel << 1) | 0x01);
                            
                        }
                    }
                }
                //전송지점
                
                serialPort1.Write(data, 0, 17);
                Thread.Sleep(10);
                for (int j = 0; j < data.Length; j++)
                {
                    richTextBox1.Text += data[j].ToString("X") + ",";
                }
                richTextBox1.Text += "\n";
                
            }
            pictureBox1.Image = bt;

            
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                int data = serialPort1.ReadByte();
               
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Bitmap bt = new Bitmap("./sample.bmp");
       

            for (int y = 0; y < bt.Height; y++)
            {
                byte pixel = 0;
                byte[] data = new byte[17];
                int data_position = 1;
                data[0] = (byte)y;
                //data[data_position]
                for (int x = 0; x < bt.Width; x++)
                {
                    //00001111 = 0x0F
                    if ((x + 1) % 8 == 0)
                    {
                        if (bt.GetPixel(x, y).R == 0)
                        {
                            //검정색
                            pixel = (byte)(pixel << 1);
                        }
                        else
                        {
                            //흰색
                            pixel = (byte)((pixel << 1) | 0x01);

                        }
                        data[data_position] = pixel;
                        data_position++;
                        //richTextBox1.Text += pixel.ToString("X") + ",";

                        //richTextBox1.Text += bt.GetPixel(x, y).R + "\n";
                    }
                    else
                    {
                        //richTextBox1.Text += bt.GetPixel(x, y).R + ",";
                        if (bt.GetPixel(x, y).R == 0)
                        {
                            //검정색
                            pixel = (byte)(pixel << 1);
                        }
                        else
                        {
                            //흰색
                            pixel = (byte)((pixel << 1) | 0x01);

                        }
                    }
                }
                //전송지점

                serialPort1.Write(data, 0, 17);
                Thread.Sleep(10);
                for (int j = 0; j < data.Length; j++)
                {
                    richTextBox1.Text += data[j].ToString("X") + ",";
                }
                richTextBox1.Text += "\n";

            }
            pictureBox1.Image = bt;
        }

        int x_pos = 0;
        private void button5_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Bitmap bt2 = new Bitmap("./sample.bmp");
            Bitmap bt = new Bitmap(bt2.Width, bt2.Height);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(Color.Black);
            g.DrawImage(bt2, x_pos, 0);
            g.Dispose();


            for (int y = 0; y < bt.Height; y++)
            {
                byte pixel = 0;
                byte[] data = new byte[17];
                int data_position = 1;
                data[0] = (byte)y;
                //data[data_position]
                for (int x = 0; x < bt.Width; x++)
                {
                    //00001111 = 0x0F
                    if ((x + 1) % 8 == 0)
                    {
                        if (bt.GetPixel(x, y).R == 0)
                        {
                            //검정색
                            pixel = (byte)(pixel << 1);
                        }
                        else
                        {
                            //흰색
                            pixel = (byte)((pixel << 1) | 0x01);

                        }
                        data[data_position] = pixel;
                        data_position++;
                        //richTextBox1.Text += pixel.ToString("X") + ",";

                        //richTextBox1.Text += bt.GetPixel(x, y).R + "\n";
                    }
                    else
                    {
                        //richTextBox1.Text += bt.GetPixel(x, y).R + ",";
                        if (bt.GetPixel(x, y).R == 0)
                        {
                            //검정색
                            pixel = (byte)(pixel << 1);
                        }
                        else
                        {
                            //흰색
                            pixel = (byte)((pixel << 1) | 0x01);

                        }
                    }
                }
                //전송지점

                serialPort1.Write(data, 0, 17);
                Thread.Sleep(10);
                /*
                for (int j = 0; j < data.Length; j++)
                {
                    richTextBox1.Text += data[j].ToString("X") + ",";
                }
                richTextBox1.Text += "\n";
                */
            }
            pictureBox1.Image = bt;



            x_pos+=10;
            if (x_pos > bt.Width) x_pos = 0;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}
