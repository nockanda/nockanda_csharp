﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using MySql.Data.MySqlClient;

namespace example143
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example144;Uid=root;Pwd=qwer1234;";
        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;

                


                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                string responseString = "";
                if (request.RawUrl.IndexOf("favicon.ico") != -1)
                {
                    //favicon.ico 패턴이 존재한다!
                    //우리의 관심대상이 아니다!
                    responseString = "<HTML><BODY> NO WEBBROWSER!</BODY></HTML>\n";
                }
                else
                {
                    richTextBox1.Text += request.RawUrl + "\n";
                    //존재하지 않는다!
                    //관심대상
                    if (request.UserAgent == "nockanda")
                    {
                        //IoT보드
                        richTextBox1.Text += "IoT보드\n";

                        //어떤 센서로부터 값이 전송이 되는가?
                        ///cds?value=123
                        ///dht11?
                        ///mhz19?
                        if (request.RawUrl.IndexOf("cds") != -1)
                        {
                            //광센서로부터 수신된 값!
                            ///cds?value=123
                            string[] data = request.RawUrl.Split('=');
                            textBox1.Text = data[1];

                            //DB에 집어넣자
                            //삽입구문
                            using (MySqlConnection conn = new MySqlConnection(Conn))
                            {
                                conn.Open();
                                MySqlCommand msc = new MySqlCommand("insert into cds(value,date) values("+ data[1] + ",'"+DateTime.Now.ToString()+"')", conn);
                                msc.ExecuteNonQuery();
                            }

                            //richTextBox1.Text += data[1] + "\n";
                            if (data[1] != "-999")
                            {
                                aGauge1.Value = int.Parse(data[1]);
                            }
                        }
                        else if (request.RawUrl.IndexOf("dht11") != -1)
                        {
                            //온습도센서!
                            ///dht11?temp=12&humi=12
                            string data = request.RawUrl;

                            //0123456789
                            //4  5

                            data = data.Substring(6, data.Length - 6);


                            //temp=12&humi=12

                            string[] data2 = data.Split('&');
                            //data2[0] == "temp=12"
                            //data2[1] == "humi=12"

                            string temp = data2[0].Split('=')[1];
                            string humi = data2[1].Split('=')[1];

                            textBox2.Text = temp;
                            textBox3.Text = humi;

                            //DB에 집어넣자
                            //삽입구문
                            using (MySqlConnection conn = new MySqlConnection(Conn))
                            {
                                conn.Open();
                                MySqlCommand msc = new MySqlCommand("insert into dht11(temp,humi,date) values("+temp+","+humi+",'"+DateTime.Now.ToString()+"')", conn);
                                msc.ExecuteNonQuery();
                            }

                            if (temp != "-999")
                            {
                                aGauge2.Value = float.Parse(temp);
                            }
                            if (humi != "-999")
                            {
                                aGauge3.Value = float.Parse(humi);
                            }


                            richTextBox1.Text += request.RawUrl + "\n";
                        }
                        else if (request.RawUrl.IndexOf("mhz19") != -1)
                        {
                            string[] data = request.RawUrl.Split('=');
                            textBox4.Text = data[1];

                            //DB에 집어넣자
                            //삽입구문
                            using (MySqlConnection conn = new MySqlConnection(Conn))
                            {
                                conn.Open();
                                MySqlCommand msc = new MySqlCommand("insert into mhz19(value,date) values("+ data[1] + ",'"+DateTime.Now.ToString()+"')", conn);
                                msc.ExecuteNonQuery();
                            }

                            if (data[1] != "-999")
                            {
                                aGauge4.Value = float.Parse(data[1]) / 10;
                            }
                        }
                        responseString = "<HTML><BODY> NOCKANDA IOT BOARD!</BODY></HTML>\n";
                    }
                    else
                    {
                        //웹브라우저
                        //광센서, 온습도센서, 이산화탄소센서
                        //192.168.0.5:60000/cds
                        //192.168.0.5:60000/dht11
                        //192.168.0.5:60000/mhz19

                        if(request.RawUrl.IndexOf("cds") != -1)
                        {
                            //CDS
                            
                            responseString = "<html><meta charset=\"utf-8\"><table border=1 width=100%><tr><td>순번</td><td>데이터</td><td>시간</td></tr>";

                            //DB에서 CDS데이터 10건을 조회해서 HTML로 출력한다!
                            //검색구문
                            using (MySqlConnection conn = new MySqlConnection(Conn))
                            {
                                DataSet ds = new DataSet();
                                string sql = "select * from cds order by num desc limit 10";
                                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                                adpt.Fill(ds, "cds");

                                for(int i = 0;i< ds.Tables[0].Rows.Count; i++)
                                {
                                    responseString += "<tr><td>"+ ds.Tables[0].Rows[i]["num"].ToString() + "</td><td>"+ ds.Tables[0].Rows[i]["value"].ToString() + "</td><td>"+ ds.Tables[0].Rows[i]["date"].ToString() + "</td></tr>";
                                    

                                }
                            }

                            responseString += "</table></html>\n";
                        }
                        else if (request.RawUrl.IndexOf("dht11") != -1)
                        {
                            responseString = "<html><meta charset=\"utf-8\"><table border=1 width=100%><tr><td>순번</td><td>온도('C)</td><td>습도(%)</td><td>시간</td></tr>";

                            //DB에서 CDS데이터 10건을 조회해서 HTML로 출력한다!
                            //검색구문
                            using (MySqlConnection conn = new MySqlConnection(Conn))
                            {
                                DataSet ds = new DataSet();
                                string sql = "select * from dht11 order by num desc limit 10";
                                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                                adpt.Fill(ds, "dht11");

                                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                {
                                    responseString += "<tr><td>" + ds.Tables[0].Rows[i]["num"].ToString() + "</td><td>" + ds.Tables[0].Rows[i]["temp"].ToString() + "</td><td>" + ds.Tables[0].Rows[i]["humi"].ToString() + "</td><td>" + ds.Tables[0].Rows[i]["date"].ToString() + "</td></tr>";

                                }
                            }

                            responseString += "</table></html>\n";
                        }
                        else if (request.RawUrl.IndexOf("mhz19") != -1)
                        {
                            responseString = "<html><meta charset=\"utf-8\"><table border=1 width=100%><tr><td>순번</td><td>Co2농도(PPM)</td><td>시간</td></tr>";

                            //DB에서 CDS데이터 10건을 조회해서 HTML로 출력한다!
                            //검색구문
                            using (MySqlConnection conn = new MySqlConnection(Conn))
                            {
                                DataSet ds = new DataSet();
                                string sql = "select * from mhz19 order by num desc limit 10";
                                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                                adpt.Fill(ds, "mhz19");

                                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                {
                                    responseString += "<tr><td>" + ds.Tables[0].Rows[i]["num"].ToString() + "</td><td>" + ds.Tables[0].Rows[i]["value"].ToString() + "</td><td>" + ds.Tables[0].Rows[i]["date"].ToString() + "</td></tr>";


                                }
                            }

                            responseString += "</table></html>\n";
                        }
                        else
                        {
                            responseString = "<HTML><meta charset=\"utf-8\"><BODY> 잘못된 요청입니다!!</BODY></HTML>\n";
                        }

                            richTextBox1.Text += "웹브라우저\n";
                        
                    }
                }

                

                
                // Construct a response.
                
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }
    }
}
