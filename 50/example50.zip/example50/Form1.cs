﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example50
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }
        void sendcolor()
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                send[0] = (byte)trackBar1.Value;
                send[1] = (byte)trackBar2.Value;
                send[2] = (byte)trackBar3.Value;

                serialPort1.Write(send, 0, 3);
            }
        }

        private void trackBar1_MouseUp(object sender, MouseEventArgs e)
        {
            label4.Text = trackBar1.Value.ToString();

            Color c = Color.FromArgb(trackBar1.Value, trackBar2.Value, trackBar3.Value);
            pictureBox2.BackColor = c;
            sendcolor();
        }

        private void trackBar2_MouseUp(object sender, MouseEventArgs e)
        {
            label5.Text = trackBar2.Value.ToString();
            Color c = Color.FromArgb(trackBar1.Value, trackBar2.Value, trackBar3.Value);
            pictureBox2.BackColor = c;
            sendcolor();
        }

        private void trackBar3_MouseUp(object sender, MouseEventArgs e)
        {

            label6.Text = trackBar3.Value.ToString();
            Color c = Color.FromArgb(trackBar1.Value, trackBar2.Value, trackBar3.Value);
            pictureBox2.BackColor = c;
            sendcolor();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            //e.X
            //e.Y
            Bitmap bt = new Bitmap(pictureBox1.Image);
            Color c = bt.GetPixel(e.X, e.Y);
            trackBar1.Value = c.R;
            trackBar2.Value = c.G;
            trackBar3.Value = c.B;
            label4.Text = c.R.ToString();
            label5.Text = c.G.ToString();
            label6.Text = c.B.ToString();
            pictureBox2.BackColor = c;
            sendcolor();
        }
    }
}

