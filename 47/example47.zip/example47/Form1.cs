﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example47
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
                label1.Text = "0";
                label2.Text = "0";
                label3.Text = "0";
            }
        }

        //https://stackoverflow.com/questions/12024406/how-can-i-rotate-an-image-by-any-degree
        private Bitmap RotateImage(Bitmap bmp, float angle)
        {
            Bitmap rotatedImage = new Bitmap(bmp.Width, bmp.Height);
            rotatedImage.SetResolution(bmp.HorizontalResolution, bmp.VerticalResolution);

            using (Graphics g = Graphics.FromImage(rotatedImage))
            {
                // Set the rotation point to the center in the matrix
                g.TranslateTransform(bmp.Width / 2, bmp.Height / 2);
                // Rotate
                g.RotateTransform(angle);
                // Restore rotation point in the matrix
                g.TranslateTransform(-bmp.Width / 2, -bmp.Height / 2);
                // Draw the image on the bitmap
                g.DrawImage(bmp, new Point(0, 0));
            }

            return rotatedImage;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[6];
                serialPort1.Read(recv, 0, 6);
                double x = ((recv[0] * 256) + recv[1]) / 100.0;
                double y = ((recv[2] * 256) + recv[3]) / 100.0;
                double z = ((recv[4] * 256) + recv[5]) / 100.0;
                if (x < 0 || x > 360) return;
                if (y < 0 || y > 360) return;
                if (z < 0 || z > 360) return;
                label1.Text = ((int)(x-180)).ToString();
                label2.Text = ((int)(y-180)).ToString();
                label3.Text = ((int)(180-z)).ToString();

                Bitmap bt = new Bitmap("./2.png");
                pictureBox1.Image = RotateImage(bt, (float)(x - 180));
                Bitmap bt2 = new Bitmap("./1.png");
                pictureBox2.Image = RotateImage(bt2, (float)(y - 180));
                Bitmap bt3 = new Bitmap("./3.png");
                pictureBox3.Image = RotateImage(bt3, (float)(180 - z));

                //byte[] send = new byte[1];
                //send[0] = 0;
                //serialPort1.Write(send, 0, 1);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
