﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example40
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool isbusy = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            if (serialPort1.IsOpen)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(label1.Text);
                listView1.Items.Add(lvi);
                label1.Text = "0KG";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && isbusy == false)
            {
                byte[] send = new byte[1];
                send[0] = 1;
                serialPort1.Write(send, 0, 1);
                isbusy = true;
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[2];
                serialPort1.Read(recv, 0, 2);
                double weight = ((recv[0] * 256) + recv[1]) / 100.0;
                label1.Text = weight.ToString() + "KG";
                if (weight > 10) return;
                vScrollBar1.Value = 10 - (int)weight;
                isbusy = false;
            }
        }
    }
}
