﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example25
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && serialPort1.IsOpen)
            {
                int value = int.Parse(textBox2.Text);
                int value2 = int.Parse(textBox3.Text);
                int value3 = int.Parse(textBox4.Text);
                int value4 = int.Parse(textBox5.Text);

                if (value > (Math.Pow(2, 16)-1) || value2 > (Math.Pow(2, 16) - 1) || value3 > (Math.Pow(2, 16) - 1) || value4 > (Math.Pow(2, 16) - 1))
                {
                    //입력한도가 초과된경우
                    return;
                }
                byte[] send = new byte[8];
                send[0] = (byte)(value / 256);
                send[1] = (byte)(value % 256);
                send[2] = (byte)(value2 / 256);
                send[3] = (byte)(value2 % 256);
                send[4] = (byte)(value3 / 256);
                send[5] = (byte)(value3 % 256);
                send[6] = (byte)(value4 / 256);
                send[7] = (byte)(value4 % 256);

                serialPort1.Write(send, 0, 8);

                ListViewItem lvi = new ListViewItem();
                lvi.Text = value.ToString();
                lvi.SubItems.Add(value2.ToString());
                lvi.SubItems.Add(value3.ToString());
                lvi.SubItems.Add(value4.ToString());
                listView1.Items.Add(lvi);
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[8];
                serialPort1.Read(recv, 0, 8);

                int value = recv[0] * 256 + recv[1];
                int value2 = recv[2] * 256 + recv[3];
                int value3 = recv[4] * 256 + recv[5];
                int value4 = recv[6] * 256 + recv[7];
                label1.Text = value.ToString();
                label2.Text = value2.ToString();
                label3.Text = value3.ToString();
                label4.Text = value4.ToString();
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen && listView1.SelectedItems.Count == 1)
            {

                int value = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
                int value2 = int.Parse(listView1.SelectedItems[0].SubItems[1].Text);
                int value3 = int.Parse(listView1.SelectedItems[0].SubItems[2].Text);
                int value4 = int.Parse(listView1.SelectedItems[0].SubItems[3].Text);

                if (value > (Math.Pow(2, 16) - 1) || value2 > (Math.Pow(2, 16) - 1) || value3 > (Math.Pow(2, 16) - 1) || value4 > (Math.Pow(2, 16) - 1))
                {
                    //입력한도가 초과된경우
                    return;
                }
                byte[] send = new byte[8];
                send[0] = (byte)(value / 256);
                send[1] = (byte)(value % 256);
                send[2] = (byte)(value2 / 256);
                send[3] = (byte)(value2 % 256);
                send[4] = (byte)(value3 / 256);
                send[5] = (byte)(value3 % 256);
                send[6] = (byte)(value4 / 256);
                send[7] = (byte)(value4 % 256);

                serialPort1.Write(send, 0, 8);

            }
        }
    }
}
