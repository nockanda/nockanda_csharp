﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example37
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[3];
                serialPort1.Read(recv, 0, 3);

                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(recv[0].ToString());
                int duration = (recv[1] * 256) + recv[2];
                lvi.SubItems.Add(duration.ToString());
                if(recv[0] == 10)
                {
                    lvi.SubItems.Add("쉬는시간");
                }
                else
                {
                    lvi.SubItems.Add("누른시간");
                }
                listView1.Items.Add(lvi);
                //
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                for(int i = 0; i < listView1.Items.Count; i++)
                {
                    //1 2
                    //listView1.Items[i].SubItems[1]
                    //listView1.Items[i].SubItems[2]
                    listView1.Items[i].Selected = true;
                    send[0] = byte.Parse(listView1.Items[i].SubItems[1].Text);
                    int duration = int.Parse(listView1.Items[i].SubItems[2].Text);
                    send[1] = (byte)(duration / 256);
                    send[2] = (byte)(duration % 256);
                    serialPort1.Write(send, 0, 3);
                    Thread.Sleep(duration);
                }
                send[0] = 10;
                send[1] = 0;
                send[2] = 0;
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }
    }
}
