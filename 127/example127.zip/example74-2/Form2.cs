﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example74_2
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example127;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //폼이 로드 되었을때
            //DB에서 데이터를 가져와서
            //그래프에 출력한다!
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from sp order by date desc limit 20";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "sp");

                chart1.Series[0].LegendText = "토양습도";
                chart1.Series[1].LegendText = "광량";
                chart1.Series[2].LegendText = "습도(%)";
                chart1.Series[3].LegendText = "온도('C)";
                chart1.Series[4].LegendText = "CO2농도(PPM)";

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string soil = ds.Tables[0].Rows[i]["soil"].ToString();
                    string cds = ds.Tables[0].Rows[i]["cds"].ToString();
                    string humi = ds.Tables[0].Rows[i]["humi"].ToString();
                    string temp = ds.Tables[0].Rows[i]["temp"].ToString();
                    string co2 = ds.Tables[0].Rows[i]["co2"].ToString();

                    //-999가 DB에 들어있으면 에러인 상황!
                    int soil2 = int.Parse(soil);
                    if (soil2 == -999) soil2 = 0;

                    int cds2 = int.Parse(cds);
                    if (cds2 == -999) cds2 = 0;

                    float humi2 = float.Parse(humi);
                    if (humi2 == -999) humi2 = 0;

                    float temp2 = float.Parse(temp);
                    if (temp2 == -999) temp2 = 0;

                    int co22 = int.Parse(co2);
                    if (co22 == -999) co22 = 0;

                    chart1.Series[0].Points.AddXY(i, soil2);
                    chart1.Series[1].Points.AddXY(i, cds2);
                    chart1.Series[2].Points.AddXY(i, humi2);
                    chart1.Series[3].Points.AddXY(i, temp2);
                    chart1.Series[4].Points.AddXY(i, co22);
                }
            }

        }
    }
}
