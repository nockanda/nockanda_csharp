﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Xml;

namespace example85
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19SidoInfStateJson?serviceKey=서비스키&pageNo=1&numOfRows=20

            string yourkey = textBox1.Text;
            

            //openapi사용을 위한 query
            string query = "http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19SidoInfStateJson?serviceKey="+yourkey+"&pageNo=1&numOfRows=20";

            //C#이 웹클라이언트 역할을 하기 위한 클래쓰
            WebClient wc = new WebClient();
            //웹리퀘스트생성
            WebRequest wrq = WebRequest.Create(query);
            wrq.Method = "GET";

            //웹리스폰스 생성
            WebResponse wrs = wrq.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            //리스폰스 전문을 받아온다!
            string response = sr.ReadToEnd();
            
            //string response = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><response><header><resultCode>00</resultCode><resultMsg>NORMAL SERVICE.</resultMsg></header><body><items><item><createDt>2021-02-04 09:40:47.151</createDt><deathCnt>3</deathCnt><defCnt>2767</defCnt><gubun>검역</gubun><gubunCn>隔離區</gubunCn><gubunEn>Lazaretto</gubunEn><incDec>6</incDec><isolClearCnt>2222</isolClearCnt><isolIngCnt>542</isolIngCnt><localOccCnt>0</localOccCnt><overFlowCnt>6</overFlowCnt><qurRate>-</qurRate><seq>7436</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.151</createDt><deathCnt>0</deathCnt><defCnt>527</defCnt><gubun>제주</gubun><gubunCn>济州</gubunCn><gubunEn>Jeju</gubunEn><incDec>3</incDec><isolClearCnt>516</isolClearCnt><isolIngCnt>11</isolIngCnt><localOccCnt>2</localOccCnt><overFlowCnt>1</overFlowCnt><qurRate>78.57</qurRate><seq>7435</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>10</deathCnt><defCnt>2042</defCnt><gubun>경남</gubun><gubunCn>庆南</gubunCn><gubunEn>Gyeongsangnam-do</gubunEn><incDec>8</incDec><isolClearCnt>1844</isolClearCnt><isolIngCnt>188</isolIngCnt><localOccCnt>7</localOccCnt><overFlowCnt>1</overFlowCnt><qurRate>60.75</qurRate><seq>7434</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>68</deathCnt><defCnt>3050</defCnt><gubun>경북</gubun><gubunCn>庆北</gubunCn><gubunEn>Gyeongsangbuk-do</gubunEn><incDec>6</incDec><isolClearCnt>2753</isolClearCnt><isolIngCnt>229</isolIngCnt><localOccCnt>6</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>114.55</qurRate><seq>7433</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>7</deathCnt><defCnt>761</defCnt><gubun>전남</gubun><gubunCn>全南</gubunCn><gubunEn>Jeollanam-do</gubunEn><incDec>2</incDec><isolClearCnt>664</isolClearCnt><isolIngCnt>90</isolIngCnt><localOccCnt>2</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>40.81</qurRate><seq>7432</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>50</deathCnt><defCnt>1055</defCnt><gubun>전북</gubun><gubunCn>全北</gubunCn><gubunEn>Jeollabuk-do</gubunEn><incDec>1</incDec><isolClearCnt>938</isolClearCnt><isolIngCnt>67</isolIngCnt><localOccCnt>1</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>58.05</qurRate><seq>7431</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>33</deathCnt><defCnt>2074</defCnt><gubun>충남</gubun><gubunCn>忠南</gubunCn><gubunEn>Chungcheongnam-do</gubunEn><incDec>13</incDec><isolClearCnt>1871</isolClearCnt><isolIngCnt>170</isolIngCnt><localOccCnt>13</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>97.72</qurRate><seq>7430</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>55</deathCnt><defCnt>1611</defCnt><gubun>충북</gubun><gubunCn>忠北</gubunCn><gubunEn>Chungcheongbuk-do</gubunEn><incDec>4</incDec><isolClearCnt>1399</isolClearCnt><isolIngCnt>157</isolIngCnt><localOccCnt>4</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>100.73</qurRate><seq>7429</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.15</createDt><deathCnt>33</deathCnt><defCnt>1724</defCnt><gubun>강원</gubun><gubunCn>江原</gubunCn><gubunEn>Gangwon-do</gubunEn><incDec>8</incDec><isolClearCnt>1503</isolClearCnt><isolIngCnt>188</isolIngCnt><localOccCnt>8</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>111.91</qurRate><seq>7428</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.149</createDt><deathCnt>434</deathCnt><defCnt>20222</defCnt><gubun>경기</gubun><gubunCn>京畿</gubunCn><gubunEn>Gyeonggi-do</gubunEn><incDec>134</incDec><isolClearCnt>17859</isolClearCnt><isolIngCnt>1929</isolIngCnt><localOccCnt>128</localOccCnt><overFlowCnt>6</overFlowCnt><qurRate>152.61</qurRate><seq>7427</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.149</createDt><deathCnt>1</deathCnt><defCnt>197</defCnt><gubun>세종</gubun><gubunCn>世宗</gubunCn><gubunEn>Sejong</gubunEn><incDec>0</incDec><isolClearCnt>185</isolClearCnt><isolIngCnt>11</isolIngCnt><localOccCnt>0</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>57.55</qurRate><seq>7426</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.149</createDt><deathCnt>37</deathCnt><defCnt>941</defCnt><gubun>울산</gubun><gubunCn>蔚山</gubunCn><gubunEn>Ulsan</gubunEn><incDec>2</incDec><isolClearCnt>874</isolClearCnt><isolIngCnt>30</isolIngCnt><localOccCnt>2</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>82.04</qurRate><seq>7425</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.149</createDt><deathCnt>14</deathCnt><defCnt>1107</defCnt><gubun>대전</gubun><gubunCn>大田</gubunCn><gubunEn>Daejeon</gubunEn><incDec>2</incDec><isolClearCnt>966</isolClearCnt><isolIngCnt>127</isolIngCnt><localOccCnt>2</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>75.09</qurRate><seq>7424</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.149</createDt><deathCnt>18</deathCnt><defCnt>1857</defCnt><gubun>광주</gubun><gubunCn>光州</gubunCn><gubunEn>Gwangju</gubunEn><incDec>12</incDec><isolClearCnt>1431</isolClearCnt><isolIngCnt>408</isolIngCnt><localOccCnt>12</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>127.48</qurRate><seq>7423</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.149</createDt><deathCnt>51</deathCnt><defCnt>3897</defCnt><gubun>인천</gubun><gubunCn>仁川</gubunCn><gubunEn>Incheon</gubunEn><incDec>44</incDec><isolClearCnt>3505</isolClearCnt><isolIngCnt>341</isolIngCnt><localOccCnt>43</localOccCnt><overFlowCnt>1</overFlowCnt><qurRate>131.83</qurRate><seq>7422</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.148</createDt><deathCnt>210</deathCnt><defCnt>8346</defCnt><gubun>대구</gubun><gubunCn>大邱</gubunCn><gubunEn>Daegu</gubunEn><incDec>8</incDec><isolClearCnt>8031</isolClearCnt><isolIngCnt>105</isolIngCnt><localOccCnt>7</localOccCnt><overFlowCnt>1</overFlowCnt><qurRate>342.54</qurRate><seq>7421</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.148</createDt><deathCnt>95</deathCnt><defCnt>2829</defCnt><gubun>부산</gubun><gubunCn>釜山</gubunCn><gubunEn>Busan</gubunEn><incDec>26</incDec><isolClearCnt>2372</isolClearCnt><isolIngCnt>362</isolIngCnt><localOccCnt>26</localOccCnt><overFlowCnt>0</overFlowCnt><qurRate>82.92</qurRate><seq>7420</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.148</createDt><deathCnt>329</deathCnt><defCnt>24755</defCnt><gubun>서울</gubun><gubunCn>首尔</gubunCn><gubunEn>Seoul</gubunEn><incDec>172</incDec><isolClearCnt>20771</isolClearCnt><isolIngCnt>3655</isolIngCnt><localOccCnt>166</localOccCnt><overFlowCnt>6</overFlowCnt><qurRate>254.33</qurRate><seq>7419</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item><item><createDt>2021-02-04 09:40:47.148</createDt><deathCnt>1448</deathCnt><defCnt>79762</defCnt><gubun>합계</gubun><gubunCn>合计</gubunCn><gubunEn>Total</gubunEn><incDec>451</incDec><isolClearCnt>69704</isolClearCnt><isolIngCnt>8610</isolIngCnt><localOccCnt>429</localOccCnt><overFlowCnt>22</overFlowCnt><qurRate>153.84</qurRate><seq>7418</seq><stdDay>2021년 02월 04일 00시</stdDay><updateDt>null</updateDt></item></items><numOfRows>20</numOfRows><pageNo>1</pageNo><totalCount>19</totalCount></body></response>";
            //richTextBox1.Text = response;

            //받아온 xml문서를 파싱한다!
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(response);

            XmlNode xn = xd["response"]["body"]["items"];


            string[] dataset = { "incDec", "defCnt", "isolClearCnt" , "isolIngCnt", "localOccCnt", "overFlowCnt" };
            Chart[] mychart = { chart1, chart2,chart3,chart4,chart5,chart6 };

            for (int j = 0; j < mychart.Length; j++)
            {

                //그래프를 그려보자!
                mychart[j].Series.Clear();
                mychart[j].ChartAreas.Clear();

                ChartArea ca = new ChartArea();
                ca.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None;
                ca.AxisX.LabelStyle.Angle = 30;

                CustomLabel[] cl = new CustomLabel[xn.ChildNodes.Count];

                Series sri = new Series();
                sri.IsVisibleInLegend = false;
                sri.IsValueShownAsLabel = true;
                sri.Palette = ChartColorPalette.BrightPastel;

                for (int i = 0; i < xn.ChildNodes.Count; i++)
                {
                    //richTextBox1.Text += xn.ChildNodes[i]["gubun"].InnerText + "/";
                    //richTextBox1.Text += xn.ChildNodes[i]["incDec"].InnerText+"\n";

                    sri.Points.AddXY(i + 1, float.Parse(xn.ChildNodes[i][dataset[j]].InnerText));
                    cl[i] = new CustomLabel();
                    cl[i].Text = xn.ChildNodes[i]["gubun"].InnerText;
                    cl[i].FromPosition = i;
                    cl[i].ToPosition = i + 2;
                    ca.AxisX.CustomLabels.Add(cl[i]);
                }

                mychart[j].ChartAreas.Add(ca);
                mychart[j].Series.Add(sri);
            }
        }
    }
}
