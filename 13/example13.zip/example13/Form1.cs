﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //예외처리
            if(textBox1.Text == "")
            {
                MessageBox.Show("이름이 입력이 안되었습니다!");
                return;
            }
            //이미입력이 된 학번이면 입력을 막는다
            for(int i = 0; i < listView1.Items.Count; i++)
            {
                if(listView1.Items[i].Text == numericUpDown1.Value.ToString())
                {
                    MessageBox.Show("이미 입력한 학번입니다!");
                    return;
                }
            }

            //입력한 값들을 리스트뷰에 집어넣어보자!
            ListViewItem lvi = new ListViewItem();
            lvi.Text = numericUpDown1.Value.ToString();
            lvi.SubItems.Add(textBox1.Text); //이름
            string s = "";
            if (radioButton1.Checked)
            {
                s = "남";
            }else if (radioButton2.Checked)
            {
                s = "여";
            }
            lvi.SubItems.Add(s); //성별
            lvi.SubItems.Add(numericUpDown2.Value.ToString());
            lvi.SubItems.Add(numericUpDown3.Value.ToString());
            lvi.SubItems.Add(numericUpDown4.Value.ToString());
            lvi.SubItems.Add(numericUpDown5.Value.ToString());

            listView1.Items.Add(lvi); //반영


            //컨트롤 초기화
            numericUpDown1.Value++;
            textBox1.Text = "";
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;
            numericUpDown4.Value = 0;
            numericUpDown5.Value = 0;

            //학급평균 계산부분
            double total_average = 0;
            for(int i = 0; i < listView1.Items.Count; i++)
            {
                double average = 0;
                //listView1.Items[i].SubItems[3~6]
                for(int j = 3; j <= 6; j++)
                {
                    average += double.Parse(listView1.Items[i].SubItems[j].Text);
                }

                total_average += (average/4);
            }
            total_average = total_average / listView1.Items.Count;
            label10.Text = "학급평균 : " + total_average.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //listView1.SelectedItems[0].SubItems[0] 번호
            //listView1.SelectedItems[0].SubItems[1] 이름
            //listView1.SelectedItems[0].SubItems[2] 성별
            //listView1.SelectedItems[0].SubItems[3] 국어
            //listView1.SelectedItems[0].SubItems[4] 수학
            //listView1.SelectedItems[0].SubItems[5] 영어
            //listView1.SelectedItems[0].SubItems[6] 과학
            if (listView1.SelectedItems.Count == 1)
            {

                numericUpDown1.Value = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
                textBox1.Text = listView1.SelectedItems[0].SubItems[1].Text;
                string s = listView1.SelectedItems[0].SubItems[2].Text;
                if (s == "남")
                {
                    radioButton1.Checked = true;
                    radioButton2.Checked = false;
                }else if(s == "여")
                {
                    radioButton1.Checked = false;
                    radioButton2.Checked = true;
                }
                int num1 = int.Parse(listView1.SelectedItems[0].SubItems[3].Text);
                int num2 = int.Parse(listView1.SelectedItems[0].SubItems[4].Text);
                int num3 = int.Parse(listView1.SelectedItems[0].SubItems[5].Text);
                int num4 = int.Parse(listView1.SelectedItems[0].SubItems[6].Text);
                numericUpDown2.Value = num1;
                numericUpDown3.Value = num2;
                numericUpDown4.Value = num3;
                numericUpDown5.Value = num4;

                //평균계산부분
                double average = (num1+num2+num3+num4)/4;
                label9.Text = "학생평균 : " + average.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count == 1)
            {
                //예외처리
                if (textBox1.Text == "")
                {
                    MessageBox.Show("이름이 입력이 안되었습니다!");
                    return;
                }

                //입력한 값들을 리스트뷰에 집어넣어보자!
                listView1.SelectedItems[0].SubItems[0].Text = numericUpDown1.Value.ToString();
                listView1.SelectedItems[0].SubItems[1].Text = textBox1.Text;
                string s = "";
                if (radioButton1.Checked)
                {
                    s = "남";
                }
                else if (radioButton2.Checked)
                {
                    s = "여";
                }
                listView1.SelectedItems[0].SubItems[2].Text = s;
                listView1.SelectedItems[0].SubItems[3].Text = numericUpDown2.Value.ToString();
                listView1.SelectedItems[0].SubItems[4].Text = numericUpDown3.Value.ToString();
                listView1.SelectedItems[0].SubItems[5].Text = numericUpDown4.Value.ToString();
                listView1.SelectedItems[0].SubItems[6].Text = numericUpDown5.Value.ToString();



            }
        }
    }
}
