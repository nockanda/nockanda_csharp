﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example42
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //1을보내면 켜는걸로 약속하자
                byte[] send = new byte[1];
                send[0] = 1;

                serialPort1.Write(send, 0, 1);
                listBox1.Items.Add(DateTime.Now + "/선풍기작동!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //0을보내면 멈추는걸로 약속하자
                byte[] send = new byte[1];
                send[0] = 0;

                serialPort1.Write(send, 0, 1);
                listBox1.Items.Add(DateTime.Now + "/선풍기멈춤!");
            }
        }
        DateTime stopwatch;
        private void button4_Click(object sender, EventArgs e)
        {
            stopwatch = DateTime.Now.AddSeconds((double)numericUpDown1.Value);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double gap = (stopwatch - DateTime.Now).TotalSeconds;
            if(gap < 0)
            {
                if (serialPort1.IsOpen)
                {
                    //1을보내면 켜는걸로 약속하자
                    byte[] send = new byte[1];
                    send[0] = 1;

                    serialPort1.Write(send, 0, 1);
                    listBox1.Items.Add(DateTime.Now + "/예약선풍기작동!");
                }
                timer1.Stop();
            }
        }
    }
}
