﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using MySql.Data.MySqlClient;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace example143
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example145;Uid=root;Pwd=qwer1234;";
        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();
        }

        byte nockanda(string input)
        {
            //EC
            //input[0] : E
            //input[1] : C
            //0~9 , A(10) ~ F(15)

            int num1 = 0;
            if (input[0] >= '0' && input[0] <= '9')
            {
                //숫자 0~9
                num1 = input[0] - '0';
            }
            else if (input[0] >= 'A' && input[0] <= 'F')
            {
                num1 = input[0] - 'A' + 10;
            }
            else if (input[0] >= 'a' && input[0] <= 'f')
            {
                num1 = input[0] - 'a' + 10;
            }

            int num2 = 0;
            if (input[1] >= '0' && input[1] <= '9')
            {
                //숫자 0~9
                num2 = input[1] - '0';
            }
            else if (input[1] >= 'A' && input[1] <= 'F')
            {
                num2 = input[1] - 'A' + 10;
            }
            else if (input[1] >= 'a' && input[1] <= 'f')
            {
                num2 = input[1] - 'a' + 10;
            }

            return (byte)(num1 * 16 + num2);
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;

                richTextBox1.Text += request.RawUrl + "\n";

                ///student?stu_num=201812312
                string[] data1 = request.RawUrl.Split('?');
                //  /student   : data1[0]
                //  stu_num=201812312  : data1[1]

                string[] data2 = data1[1].Split('=');
                // data2[0] : stu_num
                // data2[1] : 201812312




                if (
                   data2[0] == "name" ||
                   data2[0] == "depart" ||
                   data2[0] == "gender"
                   )
                {
                    //한글 인코딩 부분
                    //data2[1]
                    //%EC%BB%B4%EA%B3%B5

                    string query = data2[1].Replace("%", "");

                    //12 ->6
                    byte[] data = new byte[query.Length / 2];

                    //ECBBB4EAB3B5
                    //012345678901
                    //0 1 2 3 4 5
                    //0 2 4 6 8 10
                    for (int i = 0; i < query.Length / 2; i++)
                    {
                        //0~5
                        string tt = query[i * 2].ToString() + query[i * 2 + 1].ToString();
                        data[i] = nockanda(tt);
                        //richTextBox1.Text += data[i] + "\n";
                    }
                    data2[1] = Encoding.UTF8.GetString(data);
                }
                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                string responseString = "";
                //무조건 1개의 조건을 가지고 검색을 한다!
                string sql = "";

                //stu_num, name, depart, gender, level, date

                if (data2[0] == "stu_num" ||
                   data2[0] == "name" ||
                   data2[0] == "depart" ||
                   data2[0] == "gender" ||
                   data2[0] == "level" ||
                   data2[0] == "date"
                   )
                {

                    sql = "select * from student where "+ data2[0] + "='" + data2[1] + "'";

                    richTextBox1.Text += sql + "\n";

                    //DB하고 커넥트
                    //검색구문
                    using (MySqlConnection conn = new MySqlConnection(Conn))
                    {
                        DataSet ds = new DataSet();

                        MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                        adpt.Fill(ds, "student");


                        if (ds.Tables[0].Rows.Count == 0)
                        {
                            //검색결과가 없음
                            responseString = "검색결과가 없습니다!!\n";
                        }
                        else
                        {
                            /*
                            //PLAIN TEXT
                            //검색결과가 존재하는경우
                            responseString = "응답데이터입니다..!\n";
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string stu_num = ds.Tables[0].Rows[i]["stu_num"].ToString();
                                string name = ds.Tables[0].Rows[i]["name"].ToString();
                                string depart = ds.Tables[0].Rows[i]["depart"].ToString();
                                string gender = ds.Tables[0].Rows[i]["gender"].ToString();
                                string level = ds.Tables[0].Rows[i]["level"].ToString();
                                string date = ds.Tables[0].Rows[i]["date"].ToString();
                                responseString += stu_num+"\t"+ name+"\t"+ depart+"\t"+ gender+"\t"+level+"\t"+date + "\n";
                            }
                            */

                            /*
                            //XML RESPONSE
                            XmlDocument xd = new XmlDocument();

                            XmlNode root = xd.CreateElement("response");
                            xd.AppendChild(root);
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string stu_num = ds.Tables[0].Rows[i]["stu_num"].ToString();
                                string name = ds.Tables[0].Rows[i]["name"].ToString();
                                string depart = ds.Tables[0].Rows[i]["depart"].ToString();
                                string gender = ds.Tables[0].Rows[i]["gender"].ToString();
                                string level = ds.Tables[0].Rows[i]["level"].ToString();
                                string date = ds.Tables[0].Rows[i]["date"].ToString();

                                XmlNode item = xd.CreateElement("item");

                                XmlNode node1 = xd.CreateElement("stu_num");
                                node1.InnerText = stu_num;
                                XmlNode node2 = xd.CreateElement("name");
                                node2.InnerText = name;
                                XmlNode node3 = xd.CreateElement("depart");
                                node3.InnerText = depart;
                                XmlNode node4 = xd.CreateElement("gender");
                                node4.InnerText = gender;
                                XmlNode node5 = xd.CreateElement("level");
                                node5.InnerText = level;
                                XmlNode node6 = xd.CreateElement("date");
                                node6.InnerText = date;

                                item.AppendChild(node1);
                                item.AppendChild(node2);
                                item.AppendChild(node3);
                                item.AppendChild(node4);
                                item.AppendChild(node5);
                                item.AppendChild(node6);

                                root.AppendChild(item);
                            }

                            responseString = xd.OuterXml +"\n";
                            */


                            //JSON으로 response!

                            JObject root = new JObject();

                            JArray student = new JArray();

                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string stu_num = ds.Tables[0].Rows[i]["stu_num"].ToString();
                                string name = ds.Tables[0].Rows[i]["name"].ToString();
                                string depart = ds.Tables[0].Rows[i]["depart"].ToString();
                                string gender = ds.Tables[0].Rows[i]["gender"].ToString();
                                string level = ds.Tables[0].Rows[i]["level"].ToString();
                                string date = ds.Tables[0].Rows[i]["date"].ToString();

                                JObject node1 = new JObject();
                                node1.Add("stu_num", stu_num);
                                node1.Add("name", name);
                                node1.Add("depart", depart);
                                node1.Add("gender", gender);
                                node1.Add("level", level);
                                node1.Add("date", date);
                                student.Add(node1);

                            }

                            root.Add("response", student);

                            //richTextBox1.Text = root.ToString();

                            responseString = "NOCKANDA\n"+ root.ToString() + "\n";
                        }
                    }
                    
                    
                }
                else
                {
                    //키워드가 존재하지 않는 상황...
                    responseString = "키워드가 존재하지 않습니다!\n";
                }


                

                
                // Construct a response.
                
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }
    }
}
