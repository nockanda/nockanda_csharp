﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example147_client3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class cds
        {
            public string num { get; set; }
            public string value { get; set; }
            public string date { get; set; }
        }

        public class dht11
        {
            public string num { get; set; }
            public string temp { get; set; }
            public string humi { get; set; }
            public string date { get; set; }
        }

        public class mhz19
        {
            public string num { get; set; }
            public string co2 { get; set; }
            public string date { get; set; }
        }
        void get_data(string query)
        {
            //Request
            //http://192.168.0.5:60000/cds
            //WebRequest wr = WebRequest.Create("http://192.168.0.5:60000/"+query);
            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create("http://192.168.0.5:60000/" + query);

            wr.UserAgent = "APP";

            //Response
            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            //richTextBox1.Text = "웹서버로부터 응답받은 결과입니다..!\n";

            if (response.IndexOf("CDS") != -1)
            {
                //richTextBox1.Text += "광센서의 값입니다..!\n";
                //CDS 존재한다!
                response = response.Replace("CDS", "");

                List<cds> cds_array = JsonConvert.DeserializeObject<List<cds>>(response);

                textBox1.Text = cds_array[0].num;
                textBox2.Text = cds_array[0].value;
                textBox3.Text = cds_array[0].date;

            }

            else if (response.IndexOf("dht11") != -1)
            {
                //온습도센서
                //Console.WriteLine("온습도센서의 값입니다..!");
                //CDS 존재한다!
                response = response.Replace("dht11", "");
                List<dht11> cds_array = JsonConvert.DeserializeObject<List<dht11>>(response);

                //Console.Write("번호");
                //Console.Write("\t");
                //Console.Write("온도");
                //Console.Write("\t");
                //Console.Write("습도");
                //Console.Write("\t");
                //Console.WriteLine("시간");

                textBox6.Text = cds_array[0].num;
                textBox9.Text = cds_array[0].num;
                textBox5.Text = cds_array[0].temp;
                textBox8.Text = cds_array[0].humi;
                textBox4.Text = cds_array[0].date;
                textBox7.Text = cds_array[0].date;

            }
            else if (response.IndexOf("mhz19") != -1)
            {
                //Console.WriteLine("이산화탄소센서의 값입니다..!");
                //CDS 존재한다!
                response = response.Replace("mhz19", "");

                List<mhz19> cds_array = JsonConvert.DeserializeObject<List<mhz19>>(response);

                //Console.Write("번호");
                //Console.Write("\t");
                //Console.Write("Co2농도");
                ////Console.Write("\t");
                //Console.WriteLine("시간");

                textBox12.Text = cds_array[0].num;
                textBox11.Text = cds_array[0].co2;
                textBox10.Text = cds_array[0].date;


            }

            /*
            //response == JSON DOC

            */
            sr.Close();
            s.Close();
            wrs.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            get_data("cds");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            get_data("dht11");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            get_data("mhz19");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {
                timer1.Start();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            get_data("cds");
            get_data("dht11");
            get_data("mhz19");

        }
    }
}
