﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace example147_client2
{
    public class cds
    {
        public string num { get; set; }
        public string value { get; set; }
        public string date { get; set; }
    }

    public class dht11
    {
        public string num { get; set; }
        public string temp { get; set; }
        public string humi { get; set; }
        public string date { get; set; }
    }

    public class mhz19
    {
        public string num { get; set; }
        public string co2 { get; set; }
        public string date { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            if(args.Length == 1)
            {
                //args[0]
                if(args[0] == "cds" || args[0] == "dht11" || args[0] == "mhz19")
                {
                    //실행
                    get_data(args[0]);
                }
                else
                {
                    //입력에러
                    Console.WriteLine("쿼리가 존재하지 않는 것이다!");
                }
            }
            /*
            get_data("cds");
            Console.WriteLine("--------------------------");
            get_data("dht11");
            Console.WriteLine("--------------------------");
            get_data("mhz19");
            */
        }


        static void get_data(string query)
        {
            //Request
            //http://192.168.0.5:60000/cds
            //WebRequest wr = WebRequest.Create("http://192.168.0.5:60000/"+query);
            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create("http://192.168.0.5:60000/" + query);

            wr.UserAgent = "APP";

            //Response
            WebResponse wrs = wr.GetResponse();
            Stream s = wrs.GetResponseStream();
            StreamReader sr = new StreamReader(s);

            string response = sr.ReadToEnd();

            Console.WriteLine("웹서버로부터 응답받은 결과입니다..!");

            if (response.IndexOf("CDS") != -1)
            {
                Console.WriteLine("광센서의 값입니다..!");
                //CDS 존재한다!
                response = response.Replace("CDS", "");

                List<cds> cds_array = JsonConvert.DeserializeObject<List<cds>>(response);

                Console.Write("번호");
                Console.Write("\t");
                Console.Write("광센서값");
                Console.Write("\t");
                Console.WriteLine("시간");
                for (int i = 0; i < cds_array.Count; i++)
                {
                    Console.Write(cds_array[i].num);
                    Console.Write("\t");
                    Console.Write(cds_array[i].value);
                    Console.Write("\t");
                    Console.WriteLine(cds_array[i].date);

                }
            }
            else if (response.IndexOf("dht11") != -1)
            {
                //온습도센서
                Console.WriteLine("온습도센서의 값입니다..!");
                //CDS 존재한다!
                response = response.Replace("dht11", "");
                List<dht11> cds_array = JsonConvert.DeserializeObject<List<dht11>>(response);

                Console.Write("번호");
                Console.Write("\t");
                Console.Write("온도");
                Console.Write("\t");
                Console.Write("습도");
                Console.Write("\t");
                Console.WriteLine("시간");
                for (int i = 0; i < cds_array.Count; i++)
                {
                    Console.Write(cds_array[i].num);
                    Console.Write("\t");
                    Console.Write(cds_array[i].temp);
                    Console.Write("\t");
                    Console.Write(cds_array[i].humi);
                    Console.Write("\t");
                    Console.WriteLine(cds_array[i].date);

                }
            }
            else if (response.IndexOf("mhz19") != -1)
            {
                Console.WriteLine("이산화탄소센서의 값입니다..!");
                //CDS 존재한다!
                response = response.Replace("mhz19", "");

                List<mhz19> cds_array = JsonConvert.DeserializeObject<List<mhz19>>(response);

                Console.Write("번호");
                Console.Write("\t");
                Console.Write("Co2농도");
                Console.Write("\t");
                Console.WriteLine("시간");
                for (int i = 0; i < cds_array.Count; i++)
                {
                    Console.Write(cds_array[i].num);
                    Console.Write("\t");
                    Console.Write(cds_array[i].co2);
                    Console.Write("\t");
                    Console.WriteLine(cds_array[i].date);

                }
            }

            /*
            //response == JSON DOC

            */
            sr.Close();
            s.Close();
            wrs.Close();
        }
    }
}
