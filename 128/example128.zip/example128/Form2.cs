﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example128
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example128;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            for(int i = 0; i < chart1.Series.Count; i++)
            {
                chart1.Series[i].Points.Clear();
            }

            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from waterpump order by num desc limit 20";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "waterpump");

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string pump = ds.Tables[0].Rows[i]["pump"].ToString();
                    string flow = ds.Tables[0].Rows[i]["flow"].ToString();
                    string min = ds.Tables[0].Rows[i]["min"].ToString();
                    string max = ds.Tables[0].Rows[i]["max"].ToString();

                    chart1.Series[0].Points.AddXY(i, int.Parse(pump));
                    chart1.Series[1].Points.AddXY(i, float.Parse(flow));
                    chart1.Series[2].Points.AddXY(i, int.Parse(min));
                    chart1.Series[3].Points.AddXY(i, int.Parse(max));
                }
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }
    }
}
