﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example67
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string han_cho = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ";
        string han_jung = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ";
        string han_jong = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ";
        int[] han_cho_count ={ 1, 2, 1, 2, 4, 3, 3, 4, 8, 2, 4, 1, 3, 6, 4, 2, 3, 4, 3 };
        int[] han_jung_count = { 2, 3, 3, 4, 2, 3, 3, 4, 2, 4, 5, 3, 3, 2, 4, 5, 3, 3, 1, 2, 1 };
        int[] han_jong_count = { 0, 1, 2, 3, 1, 4, 4, 2, 3, 4, 6, 7, 5, 6, 7, 6, 3, 4, 6, 2, 4, 1, 3, 4, 2, 3, 4, 3 };
        int bunhae(char input)
        {
            int gan = input - 0xAC00;

            //초성 588(21*28)만큼 차이
            //중성 28만큼 차이
            //종성 
            int chosung = gan / 588;
            int jungsung = (gan % 588) / 28;
            int jongsung = gan % 28;

            return han_cho_count[chosung]+
                   han_jung_count[jungsung]+
                   han_jong_count[jongsung];
        }
        char jorip(char[] input)
        {
            char output = ' ';
            //ㄱㅏㄴ
            //
            //ㄱㅏㄴ
            int cho_index = han_cho.IndexOf(input[0]);
            int jung_index = han_jung.IndexOf(input[1]);
            int jong_index = han_jong.IndexOf(input[2]);

            output = (char)(0xAC00 + (cho_index * 588) + (jung_index * 28) + jong_index);
            return output;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                //이름을 제대로 입력안한경우
                MessageBox.Show("이름 입력부탁드림");
                return;
            }
            //이름은 3글자라고 가정함
            if (textBox1.Text.Length != 3 || textBox2.Text.Length != 3)
            {
                //잘못입력한 경우
                MessageBox.Show("이름은 3글자로 부탁드림..");
                return;
            }
            richTextBox1.Text = "";
            string name1 = textBox1.Text;
            string name2 = textBox2.Text;
            string sum = "";
            sum += name1[0].ToString() + name2[0].ToString()
                + name1[1].ToString() + name2[1].ToString()
                + name1[2].ToString() + name2[2].ToString();
            richTextBox1.Text = sum + "\n";
            //1차 연산에서 결과가 5개가 나온다
            int[] result1 = new int[5];
            for (int i = 0; i < sum.Length - 1; i++)
            {
                int count1 = bunhae(sum[i]);
                int count2 = bunhae(sum[i+1]);
                int output = (count1 + count2) % 10;
                result1[i] = output;
                richTextBox1.Text += " " + output +" ";
            }
            richTextBox1.Text += "\n";
            richTextBox1.Text += "  ";
            //2차연산에서 결과가 4개 나온다
            int[] result2 = new int[4];
            for(int i = 0; i < result1.Length - 1; i++)
            {
                result2[i] = (result1[i] + result1[i + 1]) % 10;
                richTextBox1.Text += " " + result2[i].ToString()+" ";
            }
            richTextBox1.Text += "\n";
            richTextBox1.Text += "   ";
            //3차연산에서 결과가 3개 나온다
            int[] result3 = new int[3];
            for(int i = 0; i < result2.Length - 1; i++)
            {
                result3[i] = (result2[i] + result2[i + 1]) % 10;
                richTextBox1.Text += " " +result3[i].ToString() + " ";
            }
            //마무리연산에서 2개의 결과가 나온다
            richTextBox1.Text += "\n";
            richTextBox1.Text += "      ";
            int[] result4 = new int[2];
            for (int i = 0; i < result3.Length - 1; i++)
            {
                result4[i] = (result3[i] + result3[i + 1]) % 10;
                richTextBox1.Text += result4[i].ToString();
            }
            richTextBox1.Text += "%\n";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string temp = textBox1.Text;
            textBox1.Text = textBox2.Text;
            textBox2.Text = temp;
        }
    }
}

