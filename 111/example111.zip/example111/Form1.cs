﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace example111
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독정보등록
            string[] topic = {"nockanda/device1", "nockanda/flow", "nockanda/level" };
            byte[] qos = { 0, 0, 0 };
            client.Subscribe(topic, qos);
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/device1")
            {
                label1.Text = ReceivedMessage;
            }else if(e.Topic == "nockanda/flow")
            {
                label2.Text = ReceivedMessage +" ml";
            }else if(e.Topic == "nockanda/level")
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();

                if(ReceivedMessage == "0")
                {
                    label3.Text = "최저수위감지";
                    lvi.SubItems.Add("최저수위감지");
                    //워터펌프를 관리하는 사물인터넷보드에게
                    //작동을 멈추라는 MQTT메시지를 publish하자!
                    client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("0"), 0, true);
                }
                else
                {
                    label3.Text = "물이 넉넉함!";
                    lvi.SubItems.Add("물이 넉넉함!");
                }

                listView1.Items.Add(lvi);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("1"), 0, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/pump", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/clear", Encoding.UTF8.GetBytes("0"), 0, true);
        }
    }
}
