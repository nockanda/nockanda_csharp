﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example96
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<string, string> pitch = new Dictionary<string, string>()
        {
            {"NOTE_C7",  "2093"},
            {"NOTE_CS7", "2217"},
            {"NOTE_D7",  "2349"},
            {"NOTE_DS7","2489"},
            {"NOTE_E7","2637"},
            {"NOTE_F7","2794"},
            {"NOTE_FS7","2960"},
            {"NOTE_G7","3136"},
            {"NOTE_GS7","3322"},
            {"NOTE_A7","3520"},
            {"NOTE_AS7","3729"},
            {"NOTE_B7","3951"},
            {"NOTE_C8","4186"}
        };

        private void button1_Click(object sender, EventArgs e)
        {

            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            
            //리스트뷰2에 있는 내용을 그대로 전송하면 끝!
            for(int i = 0; i < listBox2.Items.Count; i++)
            {
                nvc.Add(i.ToString(), listBox2.Items[i].ToString());
            }

            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (KeyValuePair<string, string> kvp in pitch)
            {
                //Console.WriteLine("Key = {0}, Value = {1}", kvp.Key, kvp.Value);
                listBox1.Items.Add(kvp.Key);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string key = listBox1.SelectedItem.ToString();
           
            //label2.Text = pitch[key];
            int duration = 0;

            if (radioButton1.Checked)
            {
                //2분음표
                duration = 2000;
            }
            else if (radioButton2.Checked)
            {
                //4분
                duration = 1000;
            }
            else if (radioButton3.Checked)
            {
                //8분
                duration = 500;
            }
            else if (radioButton4.Checked)
            {
                //16분
                duration = 250;
            }
            else if (radioButton5.Checked)
            {
                //4.5분
                duration = 1500;
            }
            else if (radioButton6.Checked)
            {
                //16.5분
                duration = 375;
            }
            else if (radioButton7.Checked)
            {
                //8.5분
                duration = 750;
            }

            listBox2.Items.Add(pitch[key]+"/"+ duration.ToString());
        }
    }
}
