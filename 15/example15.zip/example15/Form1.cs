﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int progress_value = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            progress_value += 10;
            if (progress_value > 100)
            {
                progress_value = 100;
            }
            progressBar1.Value = progress_value;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progress_value -= 10;
            if (progress_value <= 0)
            {
                progress_value = 0;
            }
            progressBar1.Value = progress_value;
        }

        Point origin_location = new Point(24, 231);
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label1.Text = hScrollBar1.Value.ToString();
            button3.Location = new Point(origin_location.X + (hScrollBar1.Value*10), button3.Location.Y);
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = vScrollBar1.Value.ToString();
            //button3.Location = new Point(button3.Location.X, (origin_location.Y+vScrollBar1.Value));
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label3.Text = trackBar1.Value.ToString();
            progressBar1.Value = trackBar1.Value;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
