﻿namespace example16
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("노드7");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("노드16");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("노드19");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("노드20");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("노드17", new System.Windows.Forms.TreeNode[] {
            treeNode32,
            treeNode33});
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("노드18");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("노드8", new System.Windows.Forms.TreeNode[] {
            treeNode31,
            treeNode34,
            treeNode35});
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("노드9");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("노드0", new System.Windows.Forms.TreeNode[] {
            treeNode30,
            treeNode36,
            treeNode37});
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("노드10");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("노드21");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("노드22");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("노드11", new System.Windows.Forms.TreeNode[] {
            treeNode40,
            treeNode41});
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("노드12");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("노드1", new System.Windows.Forms.TreeNode[] {
            treeNode39,
            treeNode42,
            treeNode43});
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("노드2");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("노드13");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("노드23");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("노드24");
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("노드25");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("노드14", new System.Windows.Forms.TreeNode[] {
            treeNode47,
            treeNode48,
            treeNode49});
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("노드15");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("노드3", new System.Windows.Forms.TreeNode[] {
            treeNode46,
            treeNode50,
            treeNode51});
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("노드4");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("노드26");
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("노드27");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("노드28");
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("노드5", new System.Windows.Forms.TreeNode[] {
            treeNode54,
            treeNode55,
            treeNode56});
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("노드6");
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(28, 29);
            this.treeView1.Name = "treeView1";
            treeNode30.Name = "노드7";
            treeNode30.Text = "노드7";
            treeNode31.Name = "노드16";
            treeNode31.Text = "노드16";
            treeNode32.Name = "노드19";
            treeNode32.Text = "노드19";
            treeNode33.Name = "노드20";
            treeNode33.Text = "노드20";
            treeNode34.Name = "노드17";
            treeNode34.Text = "노드17";
            treeNode35.Name = "노드18";
            treeNode35.Text = "노드18";
            treeNode36.Name = "노드8";
            treeNode36.Text = "노드8";
            treeNode37.Name = "노드9";
            treeNode37.Text = "노드9";
            treeNode38.Name = "노드0";
            treeNode38.Text = "노드0";
            treeNode39.Name = "노드10";
            treeNode39.Text = "노드10";
            treeNode40.Name = "노드21";
            treeNode40.Text = "노드21";
            treeNode41.Name = "노드22";
            treeNode41.Text = "노드22";
            treeNode42.Name = "노드11";
            treeNode42.Text = "노드11";
            treeNode43.Name = "노드12";
            treeNode43.Text = "노드12";
            treeNode44.Name = "노드1";
            treeNode44.Text = "노드1";
            treeNode45.Name = "노드2";
            treeNode45.Text = "노드2";
            treeNode46.Name = "노드13";
            treeNode46.Text = "노드13";
            treeNode47.Name = "노드23";
            treeNode47.Text = "노드23";
            treeNode48.Name = "노드24";
            treeNode48.Text = "노드24";
            treeNode49.Name = "노드25";
            treeNode49.Text = "노드25";
            treeNode50.Name = "노드14";
            treeNode50.Text = "노드14";
            treeNode51.Name = "노드15";
            treeNode51.Text = "노드15";
            treeNode52.Name = "노드3";
            treeNode52.Text = "노드3";
            treeNode53.Name = "노드4";
            treeNode53.Text = "노드4";
            treeNode54.Name = "노드26";
            treeNode54.Text = "노드26";
            treeNode55.Name = "노드27";
            treeNode55.Text = "노드27";
            treeNode56.Name = "노드28";
            treeNode56.Text = "노드28";
            treeNode57.Name = "노드5";
            treeNode57.Text = "노드5";
            treeNode58.Name = "노드6";
            treeNode58.Text = "노드6";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode38,
            treeNode44,
            treeNode45,
            treeNode52,
            treeNode53,
            treeNode57,
            treeNode58});
            this.treeView1.Size = new System.Drawing.Size(739, 152);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(25, 262);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(319, 139);
            this.listBox1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(28, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(319, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "삽입";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(131, 187);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "삽입";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(212, 187);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "삭제";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(396, 187);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "수정";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(25, 185);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(293, 185);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 25);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(586, 185);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 25);
            this.textBox3.TabIndex = 9;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(692, 187);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "루트삽입";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "label1";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(672, 225);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(95, 23);
            this.button6.TabIndex = 11;
            this.button6.Text = "트리뷰확장";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(674, 262);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(95, 23);
            this.button7.TabIndex = 12;
            this.button7.Text = "색깔변경";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(674, 303);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(95, 23);
            this.button8.TabIndex = 14;
            this.button8.Text = "트리복사";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.treeView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
    }
}

