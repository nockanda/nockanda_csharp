﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("ㅎㅎ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //트리뷰에 선택된 노드가 존재한다면~
            if (treeView1.SelectedNode != null && textBox1.Text != "")
            {
                //선택한 노드에 잎을 하나 달자
                treeView1.SelectedNode.Nodes.Add(textBox1.Text);
                textBox1.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //트리뷰에 선택된 노드가 존재한다면~
            if (treeView1.SelectedNode != null)
            {
                treeView1.Nodes.Remove(treeView1.SelectedNode);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null && textBox2.Text != "")
            {
                treeView1.SelectedNode.Text = textBox2.Text;
                textBox2.Text = "";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            if(textBox3.Text != "")
            {
                treeView1.Nodes.Add(textBox3.Text);
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //label1.Text = treeView1.SelectedNode.Text;
            label1.Text = treeView1.SelectedNode.FullPath;
            listBox1.Items.Add(treeView1.SelectedNode.FullPath);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            treeView1.ExpandAll();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                treeView1.SelectedNode.BackColor = Color.Red;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            
        }
    }
}
