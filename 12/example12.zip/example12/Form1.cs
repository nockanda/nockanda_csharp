﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //선택된 아이템을 팝업으로 뛰워보자!(단일)
            //if (listBox1.SelectedIndex != -1)
            //{
            //   MessageBox.Show(listBox1.SelectedItem.ToString());
            //}
            //선택된 복수개 아이템을 팝업으로 뛰워보자!

            string output = "";
            for (int i = 0; i < listBox1.SelectedItems.Count; i++)
            {
                //listBox1.Items
                //listBox1.SelectedItems
                output += listBox1.SelectedItems[i].ToString()+"\n";
            }
            MessageBox.Show(output);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //단순 삽입!
            //if(textBox1.Text != "")
            //{
            //    listBox1.Items.Add(textBox1.Text);
            //}

            //중복된게 있으면 삽입하지 않겠다.
            if (textBox1.Text != "")
            {
                bool isjoongbok = false;
                for(int i = 0; i < listBox1.Items.Count; i++)
                {
                    if(listBox1.Items[i].ToString() == textBox1.Text)
                    {
                        //중복!
                        isjoongbok = true;
                        MessageBox.Show("중복!");
                        break;
                    }
                }

                if (!isjoongbok)
                {
                    listBox1.Items.Add(textBox1.Text);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //복수개 선택된 항목을 삭제해보자!
            for (int i = listBox1.SelectedItems.Count -1; i >= 0; i--)
            {
                listBox1.Items.Remove(listBox1.SelectedItems[i]);
                //MessageBox.Show(listBox1.SelectedItems[i].ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //삭제하고 새로삽입하는게 바로 업데이트다!
            if (textBox1.Text != "" && listBox1.SelectedItems.Count == 1)
            {
                //공백이 아니면서 1개만 선택됨!
                listBox1.Items.Remove(listBox1.SelectedItems[0]);
                listBox1.Items.Add(textBox1.Text);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //리스트뷰에서 선택된 레코드를 팝업으로 뛰우기
            string output = "";
            if(listView1.SelectedItems.Count > 0)
            {
                //output = listView1.SelectedItems[0].Text + "\n";
                for(int i = 0; i < listView1.SelectedItems[0].SubItems.Count; i++)
                {
                    output += listView1.SelectedItems[0].SubItems[i].Text + "\n";
                }
            }
            MessageBox.Show(output);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "")
            {
                //공백이 없을떄 하겠다
                ListViewItem lvi = new ListViewItem();
                lvi.Text = textBox2.Text;
                lvi.SubItems.Add(textBox3.Text);
                lvi.SubItems.Add(textBox4.Text);
                lvi.SubItems.Add(textBox5.Text);
                lvi.SubItems.Add(textBox6.Text);

                listView1.Items.Add(lvi);
            }
                
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //여러개 삭제 가능!
            if (listView1.SelectedItems.Count > 0)
            {
                for(int i = listView1.SelectedItems.Count -1 ; i >=0 ; i--)
                {
                    listView1.SelectedItems[i].Remove();
                }
                
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                //리스트뷰에 아이템이 선택된경우
                //listView1.SelectedItems[0].Text
                listBox1.Items.Add(listView1.SelectedItems[0].Text);
            }
        }
    }
}
