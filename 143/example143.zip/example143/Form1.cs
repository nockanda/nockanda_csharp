﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;

namespace example143
{
    public partial class Form1 : Form
    {
        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;
                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                // Construct a response.
                string responseString = "<HTML><BODY> Hello world!</BODY></HTML>\n";
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }
    }
}
