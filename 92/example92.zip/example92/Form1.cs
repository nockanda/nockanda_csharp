﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example92
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/-2048");
            MessageBox.Show(response);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/2048");
            MessageBox.Show(response);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/-1024");
            MessageBox.Show(response);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/1024");
            MessageBox.Show(response);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/-32");
            MessageBox.Show(response);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/32");
            MessageBox.Show(response);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("step", "-2048");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button11_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("step", "2048");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button10_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("step", "-1024");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button9_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("step", "1024");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button8_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("step", "-32");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }

        private void button7_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("step", "32");
            byte[] response = wc.UploadValues("http://" + textBox1.Text, nvc);
            MessageBox.Show(Encoding.UTF8.GetString(response));
        }
    }
}
