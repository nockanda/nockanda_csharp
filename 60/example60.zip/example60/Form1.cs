﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example60
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //온도('c),압력(pa),고도(m),씨레벨압력(pa),해발고도(m)
                string input = serialPort1.ReadLine();
                string[] datas = input.Split(',');

                if (datas.Length < 5) return;

                ListViewItem lvi = new ListViewItem();
                lvi.Text = datas[0];
                for(int i = 1; i < 5; i++)
                {
                    lvi.SubItems.Add(datas[i]);
                }
                listView1.Items.Add(lvi);

                label6.Text = datas[0];
                label7.Text = datas[1];
                label8.Text = datas[2];
                label9.Text = datas[3];
                label10.Text = datas[4];
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string path = "./output.csv";
            FileStream fs = new FileStream(path, FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fs);

            for(int i = 0; i < listView1.Items.Count; i++)
            {
                sw.Write(listView1.Items[i].SubItems[0].Text);
                sw.Write(",");
                sw.Write(listView1.Items[i].SubItems[1].Text);
                sw.Write(",");
                sw.Write(listView1.Items[i].SubItems[2].Text);
                sw.Write(",");
                sw.Write(listView1.Items[i].SubItems[3].Text);
                sw.Write(",");
                sw.Write(listView1.Items[i].SubItems[4].Text);
            }


            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();

            MessageBox.Show("저장했습니다!");
        }
    }
}
