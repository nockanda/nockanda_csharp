﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example90
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int x_pos = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");

            //MessageBox.Show(response);
            string[] data = response.Split('/');
            //data[0]. data[1]
            label2.Text = data[0] + "'C";
            label3.Text = data[1] + "%";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            WebClient wc = new WebClient();
            string response = wc.DownloadString("http://" + textBox1.Text + "/nockanda");

            //MessageBox.Show(response);
            string[] data = response.Split('/');
            //data[0]. data[1]
            label2.Text = data[0] + "'C";
            label3.Text = data[1] + "%";

            double t = double.Parse(data[0]);
            double h = double.Parse(data[1]);
            
            
            /*
            Random r = new Random();
            int t = r.Next(0, 100);
            int h = r.Next(0, 100);
            */
            chart1.Series[0].Points.AddXY(x_pos, t);
            chart2.Series[0].Points.AddXY(x_pos, h);

            if (chart1.Series[0].Points.Count > 10)
                chart1.Series[0].Points.RemoveAt(0);

            if (chart2.Series[0].Points.Count > 10)
                chart2.Series[0].Points.RemoveAt(0);

            chart1.ChartAreas[0].AxisX.Maximum = x_pos;
            chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;

            chart2.ChartAreas[0].AxisX.Maximum = x_pos;
            chart2.ChartAreas[0].AxisX.Minimum = chart2.Series[0].Points[0].XValue;

            chart1.ChartAreas[0].AxisY.Maximum = 50;
            chart2.ChartAreas[0].AxisY.Maximum = 100;

            x_pos++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                timer1.Stop();
            }
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }
    }
}
