﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example26
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        byte degree1 = 0;
        byte degree2 = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = byte.Parse(textBox2.Text);
                send[1] = byte.Parse(textBox3.Text);
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
                listBox1.Items.Add(send[0] + "," + send[1]);
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            try
            {
                if (serialPort1.IsOpen)
                {
                    byte[] recv = new byte[3];
                    serialPort1.Read(recv, 0, 3);
                    if (recv[2] == '\n' && recv[0] != 26 && recv[1] != 26)
                    {
                        degree1 = recv[0];
                        degree2 = recv[1];
                        label1.Text = recv[0].ToString();
                        label2.Text = recv[1].ToString();
                    }
                    else
                    {
                        while (serialPort1.ReadByte() == '\n')
                        {
                            //패킷버림
                        }
                    }

                }
            }
            catch
            {

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                degree1++;
                if (degree1 > 180) degree1 = 180;
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = degree1;
                send[1] = degree2;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                degree2++;
                if (degree2 > 180) degree2 = 180;
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = degree1;
                send[1] = degree2;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                degree1--;
                if (degree1 < 0) degree1 = 0;

                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = degree1;
                send[1] = degree2;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                degree2--;
                if (degree2 < 0) degree2 = 0;
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = degree1;
                send[1] = degree2;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = 0;
                send[1] = 0;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = (byte)trackBar1.Value;
                send[1] = degree2;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = degree1;
                send[1] = (byte)trackBar2.Value;
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(degree1 + "," + degree2);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1 && serialPort1.IsOpen)
            {
                string[] degrees = listBox1.SelectedItem.ToString().Split(',');
                byte[] send = new byte[3];
                //사용자는 무조건 숫자를 입력할거야!
                send[0] = byte.Parse(degrees[0]);
                send[1] = byte.Parse(degrees[1]);
                send[2] = (byte)'\n';
                serialPort1.Write(send, 0, 3);

                //0x00 //0x01
                //0x00 // 0x01

            }
        }
    }
}

