﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Accord.Math.Optimization;

namespace example132
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random();

            string[] man = {"남자1번","남자2번","남자3번","남자4번","남자5번" };
            string[] woman = { "여자1번", "여자2번", "여자3번", "여자4번", "여자5번" };

            //남자최대 100점, 여자최대 100점이다!
            //그러므로 0~200사이의 랜덤값이 뽑히면된다!
            double[][] hogamdo = new double[5][];

            //edge 데이터 삽입
            for(int i = 0; i < 5; i++)
            {
                hogamdo[i] = new double[5];
                for (int j = 0; j < 5; j++)
                {
                    hogamdo[i][j] = r.Next(0, 201);
                }
            }

            //edge데이터 테스트 출력
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    richTextBox1.Text += hogamdo[i][j] + "\t";
                }
                richTextBox1.Text += "\n";
            }

            Munkres m = new Munkres(hogamdo);

            bool success = m.Maximize();    // solve it (should return true)
            double[] solution = m.Solution; // Solution will be 0, 1, 2
            double minimumCost = m.Value;

            for(int i = 0; i < solution.Length; i++)
            {
                //richTextBox1.Text += solution[i] + "\t";
                richTextBox1.Text += man[i] + "-------" + woman[(int)solution[i]] + "\n";
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TextBox[][] mat =
            {
                new TextBox[]{textBox1,textBox2,textBox3,textBox4,textBox5 },
                new TextBox[]{textBox10,textBox9,textBox8,textBox7,textBox6 },
                new TextBox[]{textBox15,textBox14,textBox13,textBox12,textBox11 },
                new TextBox[]{textBox20,textBox19,textBox18,textBox17,textBox16 },
                new TextBox[]{ textBox25, textBox24, textBox23, textBox22, textBox21 }
            };

            Random r = new Random();
            for(int i = 0; i < 5; i++)
            {
                for(int j = 0; j < 5; j++)
                {
                    mat[i][j].Text = r.Next(0, 101).ToString();
                    mat[i][j].BackColor = Color.White;
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            TextBox[][] mat =
            {
                new TextBox[]{textBox1,textBox2,textBox3,textBox4,textBox5 },
                new TextBox[]{textBox10,textBox9,textBox8,textBox7,textBox6 },
                new TextBox[]{textBox15,textBox14,textBox13,textBox12,textBox11 },
                new TextBox[]{textBox20,textBox19,textBox18,textBox17,textBox16 },
                new TextBox[]{ textBox25, textBox24, textBox23, textBox22, textBox21 }
            };

            double[][] cost = new double[5][];

            for (int i = 0; i < 5; i++)
            {
                cost[i] = new double[5];

                for (int j = 0; j < 5; j++)
                {
                    cost[i][j] = double.Parse(mat[i][j].Text);

                }
            }

            Munkres m = new Munkres(cost);

            bool success = m.Maximize();    // solve it (should return true)
            double[] solution = m.Solution; // Solution will be 0, 1, 2
            
            for(int i = 0; i < 5; i++)
            {
                mat[i][(int)solution[i]].BackColor = Color.Red;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            Bitmap bt = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics g = Graphics.FromImage(bt);

            //100개의 포인트를 랜덤하게
            Point[] p1 = new Point[100];
            Point[] p2 = new Point[100];
            for (int i = 0; i < 100; i++)
            {
                p1[i] = new Point(r.Next(0, 801), r.Next(0, 300));
                p2[i] = new Point(r.Next(0, 801), r.Next(0, 300));
                g.FillRectangle(Brushes.Red, p1[i].X, p1[i].Y, 5, 5);
                g.FillRectangle(Brushes.Blue, p2[i].X, p2[i].Y, 5, 5);
            }

            double[][] cost = new double[100][];

            for(int i = 0; i < 100; i++)
            {
                cost[i] = new double[100];
                for(int j = 0; j < 100; j++)
                {
                    cost[i][j] = Math.Sqrt((Math.Pow((p2[j].X - p1[i].X), 2) + Math.Pow((p2[j].Y - p1[i].Y), 2)));
                }
            }

            // Create a new Hungarian algorithm
            Munkres m = new Munkres(cost);

            bool success = m.Minimize();    // solve it (should return true)
            double[] solution = m.Solution; // Solution will be 0, 1, 2
            

            for(int i = 0; i < 100; i++)
            {
                g.DrawLine(Pens.Black, p1[i], p2[(int)solution[i]]);
            }

            //g.FillRectangle(brush)

            g.Dispose();


            pictureBox1.Image = bt;
        }
    }
}
