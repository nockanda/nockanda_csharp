﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example56
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && !serialPort1.IsOpen)
            {
                serialPort1.PortName = textBox1.Text;
                serialPort1.Open();
            }
        }
        int max = 100;
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                byte[] recv = new byte[1];
                serialPort1.Read(recv, 0, 1);

                if (!gamestart) return;

                int value = trackBar1.Value;

                //richTextBox1.Text += recv[0].ToString();

                
                if (recv[0] == 4)
                {
                    //1번플레이어
                    value++;
                }
                else if (recv[0] == 8)
                {
                    //2번플레이어
                    value--;
                }
                else
                {
                    return;
                }

                if(value > max)
                {
                    //플레이어1 승리
                    label3.Text = "플레이어1 승리";
                    gamestart = false;
                    value = max;
                }
                if(value < 1)
                {
                    //플레이어2 승리
                    label3.Text = "플레이어2 승리";
                    gamestart = false;
                    value = 1;
                }
                trackBar1.Value = value;
                
            }
        }
        bool gamestart = false;
        private void button2_Click(object sender, EventArgs e)
        {
            trackBar1.Value = 50;
            gamestart = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gamestart = false;
        }
    }
}
