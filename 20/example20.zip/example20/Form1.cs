﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string path = "./abc/input.txt";
            string path = textBox1.Text;

            FileStream fs = new FileStream(path, FileMode.Open);
            StreamReader sr = new StreamReader(fs);

            //파일을 연상태에서 할일
            richTextBox1.Text = ""; //초기화
            while (!sr.EndOfStream)
            {
                richTextBox1.Text += sr.ReadLine() +"\n";
            }
            

            sr.Close();
            sr.Dispose();
            fs.Close();
            fs.Dispose();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileInfo fi = new FileInfo(openFileDialog1.FileName);
                //textBox2.Text = fi.Extension;

                if (fi.Extension == ".txt")
                {

                    //textBox2.Text = openFileDialog1.FileName;
                    FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open);
                    StreamReader sr = new StreamReader(fs);

                    //파일을 연상태에서 할일
                    richTextBox1.Text = ""; //초기화
                    while (!sr.EndOfStream)
                    {
                        richTextBox1.Text += sr.ReadLine() + "\n";
                    }


                    sr.Close();
                    sr.Dispose();
                    fs.Close();
                    fs.Dispose();
                }else if(fi.Extension == ".png")
                {

                    pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items.Clear();
                //오픈파일다이얼로그의 복수개 선택된 파일경로를
                //하나씩 하나씩해서 전체를 불러오겠다
                //중요한것은 i를 쓴적이 없다.
                /*
                for(int i = 0; i < openFileDialog1.FileNames.Length; i++)
                {
                    listBox1.Items.Add(openFileDialog1.FileNames[i]);
                }
                */
                foreach(string file in openFileDialog1.FileNames)
                {
                    listBox1.Items.Add(file);
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            FileInfo fi = new FileInfo(listBox1.SelectedItem.ToString());
            //textBox2.Text = fi.Extension;

            if (fi.Extension == ".txt")
            {

                //textBox2.Text = openFileDialog1.FileName;
                FileStream fs = new FileStream(listBox1.SelectedItem.ToString(), FileMode.Open);
                StreamReader sr = new StreamReader(fs);

                //파일을 연상태에서 할일
                richTextBox1.Text = ""; //초기화
                while (!sr.EndOfStream)
                {
                    richTextBox1.Text += sr.ReadLine() + "\n";
                }


                sr.Close();
                sr.Dispose();
                fs.Close();
                fs.Dispose();
            }
            else if (fi.Extension == ".png")
            {

                pictureBox1.Image = new Bitmap(listBox1.SelectedItem.ToString());
            }
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //saveFileDialog1.FileName
                FileStream fs = new FileStream(saveFileDialog1.FileName,FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);

                //파일쓰기 작업 진행
                sw.WriteLine(richTextBox1.Text);

                sw.Close();
                sw.Dispose();
                fs.Close();
                fs.Dispose();

                MessageBox.Show("저장되었습니다!");
            }
        }
    }
}
