﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace example143
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=acompany;Uid=root;Pwd=qwer1234;";
        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;

                richTextBox1.Text += request.RawUrl + "\n";

                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                // Construct a response.
                string responseString = "";

                //request.RawUrl  : /finger=1

                Nockanda n = new Nockanda();

                //헤더를 점검해본다!
                string pw = request.Headers.Get("Nockanda");
                richTextBox1.Text += "pw=" + pw + "\n";
                if (pw == "subscribe!!")
                {
                    //정상단말기
                    if (request.RawUrl.IndexOf("/finger=") == 0)
                    {
                        // 지정된 쿼리로 문구가 시작이 되느냐?
                        //지문번호를 잘라내보자
                        string query = request.RawUrl;

                        string finger = query.Substring(8, query.Length - 8);

                        //출근체크 DB에서 등록이 되었는지를 확인!
                        using (MySqlConnection conn = new MySqlConnection(Conn))
                        {
                            DataSet ds = new DataSet();
                            string sql = "select * from ccheck where finger=" + finger;
                            MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                            adpt.Fill(ds, "ccheck");

                            if (ds.Tables[0].Rows.Count == 0)
                            {
                                //출근등록
                                //DB에 저장

                                string result = "";
                                if (radioButton1.Checked)
                                {
                                    //정상출근
                                    //responseString = "정상출근 입니다!!\n";
                                    result = "출근";

                                    n.msg = "정상출근 입니다!!";
                                    n.state = "0";
                                }
                                else if (radioButton2.Checked)
                                {
                                    //responseString = "지각입니다!!\n";
                                    result = "지각";

                                    n.msg = "지각 입니다!!";
                                    n.state = "1";
                                }

                                conn.Open();
                                MySqlCommand msc = new MySqlCommand("insert into ccheck values(" + finger + ",'" + DateTime.Now.ToString() + "','" + result + "')", conn);
                                msc.ExecuteNonQuery();
                            }
                            else
                            {
                                //이미 등록이 되어있는 상황
                                //responseString = "이미 출근 등록을 했습니다!\n";

                                n.msg = "이미 출근 등록을 했습니다!";
                                n.state = "2";
                            }
                        }


                    }
                    else
                    {
                        //파라미터 에러
                        //responseString = "파라미터에러\n";

                        n.msg = "파라미터에러!";
                        n.state = "-1";
                    }
                    

                }
                else
                {
                    //부적합단말기
                    n.msg = "비정상적인 접근입니다!!";
                    n.state = "-1";
                }

                responseString = JsonConvert.SerializeObject(n) + "\n";

                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                // Get a response stream and write the response to it.
                response.ContentLength64 = buffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                // You must close the output stream.
                output.Close();
                listener.Stop();

                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }


        public class Nockanda
        {
            public string msg { get; set; }
            public string state { get; set; }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();

            fm2.ShowDialog();
        }
    }
}
