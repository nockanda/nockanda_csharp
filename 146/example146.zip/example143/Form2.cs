﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example143
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=acompany;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //출근기록을 DB에서 꺼낸다
            //지문번호를 이용해서 직원의 상세정보를 가져온다!

            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from ccheck";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "ccheck");

                for(int i=0;i< ds.Tables[0].Rows.Count; i++)
                {
                    //ds.Tables[0].Rows[i]["finger"].ToString()
                    //ds.Tables[0].Rows[i]["date"].ToString()
                    //ds.Tables[0].Rows[i]["result"].ToString()
                    string date = ds.Tables[0].Rows[i]["date"].ToString();
                    string result = ds.Tables[0].Rows[i]["result"].ToString();
                    string finger = ds.Tables[0].Rows[i]["finger"].ToString();
                    DataSet ds2 = new DataSet();
                    string sql2 = "select * from user where finger="+ finger;
                    MySqlDataAdapter adpt2 = new MySqlDataAdapter(sql2, conn);
                    adpt2.Fill(ds2, "user");

                    if(ds2.Tables[0].Rows.Count == 1)
                    {
                        //검색결과 있음
                        string num = ds2.Tables[0].Rows[0]["num"].ToString();
                        string name = ds2.Tables[0].Rows[0]["name"].ToString();
                        string level = ds2.Tables[0].Rows[0]["level"].ToString();
                        string gender = ds2.Tables[0].Rows[0]["gender"].ToString();

                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = num;
                        lvi.SubItems.Add(finger);
                        lvi.SubItems.Add(name);
                        lvi.SubItems.Add(level);
                        lvi.SubItems.Add(gender);
                        lvi.SubItems.Add(date);
                        lvi.SubItems.Add(result);

                        listView1.Items.Add(lvi);
                    }

                    
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //삭제구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("delete from ccheck", conn);
                msc.ExecuteNonQuery();
                MessageBox.Show("삭제했습니다!!");
                listView1.Items.Clear();
            }
        }
    }
}
