﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example138;Uid=root;Pwd=qwer1234;";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from nockanda order by date desc limit 30";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "nockanda");

                for (int i = 0; i < chart1.Series.Count; i++)
                {
                    chart1.Series[i].Points.Clear();
                }

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    int cds = int.Parse(ds.Tables[0].Rows[i]["cds"].ToString());
                    int soil = int.Parse(ds.Tables[0].Rows[i]["soil"].ToString());
                    float temp = float.Parse(ds.Tables[0].Rows[i]["temp"].ToString());
                    float humi = float.Parse(ds.Tables[0].Rows[i]["humi"].ToString());
                    int co2 = int.Parse(ds.Tables[0].Rows[i]["co2"].ToString());

                    if (cds != -999)
                    {
                        chart1.Series[0].Points.AddXY(i, cds);
                    }
                    if (soil != -999)
                    {
                        chart1.Series[1].Points.AddXY(i, soil);
                    }
                    if (temp != -999)
                    {
                        chart1.Series[2].Points.AddXY(i, temp);
                    }
                    if (humi != -999)
                    {
                        chart1.Series[3].Points.AddXY(i, humi);
                    }
                    if (co2 != -999)
                    {
                        chart1.Series[4].Points.AddXY(i, co2);
                    }
                }
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }
    }
}
