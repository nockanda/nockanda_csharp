﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=example138;Uid=root;Pwd=qwer1234;";
        MqttClient client;
        string clientId;

        int cds = -999;
        int soil = -999;
        float temp = -999;
        float humi = -999;
        int co2 = -999;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MQTT 브로커와 연결하는 부분
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독할 TOPIC 지정
            string[] topic = { "nockanda/cds", "nockanda/soil","nockanda/dht11","nockanda/co2" };
            byte[] qos = { 0, 0, 0, 0 };
            client.Subscribe(topic, qos);
        }

        //MQTT이벤트 핸들러
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/cds")
            {
                //label1.Text = "CDS : " + ReceivedMessage;
                cds = int.Parse(ReceivedMessage);
                aGauge1.Value = cds;

            }
            else if(e.Topic == "nockanda/soil")
            {
                //label2.Text = "SOIL : " + ReceivedMessage;
                soil =int.Parse(ReceivedMessage);
                aGauge2.Value = soil;
            }
            else if(e.Topic == "nockanda/dht11")
            {
                //label3.Text = "DHT11 : " + ReceivedMessage;
                string[] data = ReceivedMessage.Split(',');
                humi = float.Parse(data[0]);
                aGauge4.Value = humi;
                temp = float.Parse(data[1]);
                aGauge3.Value = temp;
            }
            else if(e.Topic == "nockanda/co2")
            {
                //label4.Text = "CO2 : " + ReceivedMessage;
                co2 = int.Parse(ReceivedMessage);
                aGauge5.Value = co2 / 10;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {
                timer1.Start();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //삽입구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand("insert into nockanda(cds,soil,temp,humi,co2,date) values(" + cds + "," + soil + "," + temp + "," + humi + "," + co2 + ",'" + DateTime.Now.ToString() + "')", conn);
                msc.ExecuteNonQuery();
                cds = -999;
                soil = -999;
                humi = -999;
                temp = -999;
                co2 = -999;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();
            fm2.Show();
        }
    }
}
