﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace example135
{
    public partial class Form2 : Form
    {
        string Conn = "Server=localhost;Database=example135;Uid=root;Pwd=qwer1234;";

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //검색구문
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from cds order by num desc limit 30";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "cds");

                for(int i = 0; i < ds.Tables[0].Rows.Count; i++) {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ds.Tables[0].Rows[i]["num"].ToString();
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["value"].ToString());
                    lvi.SubItems.Add(ds.Tables[0].Rows[i]["date"].ToString());

                    listView1.Items.Add(lvi);
                }
            }

        }
    }
}
