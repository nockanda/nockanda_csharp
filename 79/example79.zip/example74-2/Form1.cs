﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example74_2
{
    public partial class Form1 : Form
    {
        bool is_received = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] port = SerialPort.GetPortNames();

            for(int i = 0; i < port.Length; i++)
            {
                comboBox1.Items.Add(port[i]);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
            {
                //시리얼포트가 닫혀있다면~
                if(comboBox1.SelectedIndex != -1)
                {
                    serialPort1.PortName = comboBox1.SelectedItem.ToString();
                    serialPort1.Open();

                    richTextBox1.Text += "시리얼포트가 열렸습니다!\n";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //2번 아두이노에게 보내는 request
            byte direct = 0;
            if (radioButton1.Checked)
            {
                //정회전
                direct = 0;
            }
            else if (radioButton2.Checked)
            {
                //역회전
                direct = 1;
            }


            byte[] send = new byte[10];
            send[0] = 0x01; //2번아두이노의 ID
            send[1] = 0x00;
            send[2] = direct; //방향
            send[3] = (byte)hScrollBar1.Value; //파워
            send[4] = 0;
            send[5] = 0;
            send[6] = 0;
            send[7] = 0;
            send[8] = 0;
            send[9] = 0;

            //request!
            is_received = false;
            serialPort1.Write(send, 0, 10);
            richTextBox1.Text += "Request!\n";

            //시간을 측정해보자!
            DateTime timeout = DateTime.Now;
            while (true)
            {
                //무한루프생성
                if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                {
                    richTextBox1.Text += "TIMEOUT\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                    break;
                }
                if (is_received)
                {
                    //richTextBox1.Text += "RECEIVED!\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                    byte[] recv = new byte[10];
                    serialPort1.Read(recv, 0, 10);

                    //리스트뷰에 수신메시지를 집어넣자!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = recv[0].ToString("X");
                    for (int i = 1; i < 10; i++)
                    {
                        if (i == 2 || i == 3)
                            lvi.SubItems.Add(((char)recv[i]).ToString());
                        else
                            lvi.SubItems.Add(recv[i].ToString("X"));
                    }

                    listView2.Items.Add(lvi);

                    break;
                }
            }

            //1번 아두이노에게 request
            send[0] = 0x00; //1번 아두이노의 ID
            send[1] = 0x00;
            send[2] = direct; //방향
            send[3] = (byte)hScrollBar1.Value; //파워
            send[4] = 0;
            send[5] = 0;
            send[6] = 0;
            send[7] = 0;
            send[8] = 0;
            send[9] = 0;

            //request!
            is_received = false;
            serialPort1.Write(send, 0, 10);
            richTextBox1.Text += "Request!\n";

            //시간을 측정해보자!
            timeout = DateTime.Now;
            while (true)
            {
                //무한루프생성
                if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                {
                    richTextBox1.Text += "TIMEOUT\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                    break;
                }
                if (is_received)
                {
                    //richTextBox1.Text += "RECEIVED!\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                    byte[] recv = new byte[10];
                    serialPort1.Read(recv, 0, 10);

                    //리스트뷰에 수신메시지를 집어넣자!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = recv[0].ToString("X");
                    for (int i = 1; i < 10; i++)
                    {
                        if (i == 2 || i == 3)
                            lvi.SubItems.Add(((char)recv[i]).ToString());
                        else
                            lvi.SubItems.Add(recv[i].ToString("X"));
                    }

                    listView2.Items.Add(lvi);

                    break;
                }
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            is_received = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = textBox1.Text;
                lvi.SubItems.Add("-");

                listView1.Items.Add(lvi);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count == 1)
            {
                //richTextBox1.Text = listView1.SelectedIndices[0].ToString();
                listView1.Items.RemoveAt(listView1.SelectedIndices[0]);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                byte[] send = new byte[10];
                send[0] = byte.Parse(listView1.SelectedItems[0].Text);
                send[1] = 0x00;
                send[2] = byte.Parse(textBox2.Text);
                send[3] = byte.Parse(textBox3.Text);
                send[4] = byte.Parse(textBox4.Text);
                send[5] = byte.Parse(textBox5.Text);
                send[6] = byte.Parse(textBox6.Text);
                send[7] = byte.Parse(textBox7.Text);
                send[8] = byte.Parse(textBox8.Text);
                send[9] = byte.Parse(textBox9.Text);

                //request!
                is_received = false;
                serialPort1.Write(send, 0, 10);
                richTextBox1.Text += "Request!\n";

                //시간을 측정해보자!
                DateTime timeout = DateTime.Now;
                while (true)
                {
                    //무한루프생성
                    if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                    {
                        richTextBox1.Text += "TIMEOUT\n";
                        listView1.SelectedItems[0].SubItems[1].Text = "FALSE";
                        
                        break;
                    }
                    if (is_received)
                    {
                        //richTextBox1.Text += "RECEIVED!\n";
                        listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                        byte[] recv = new byte[10];
                        serialPort1.Read(recv, 0, 10);

                        //리스트뷰에 수신메시지를 집어넣자!
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = recv[0].ToString("X");
                        for (int i = 1; i < 10; i++)
                        {
                            if (i == 2 || i == 3)
                                lvi.SubItems.Add(((char)recv[i]).ToString());
                            else
                                lvi.SubItems.Add(recv[i].ToString("X"));
                        }

                        listView2.Items.Add(lvi);

                        break;
                    }
                }
            }
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label2.Text = ((int)(hScrollBar1.Value / 255.0 * 100)).ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] send = new byte[10];
            send[0] = 0x02; //3번아두이노의 ID
            send[1] = 0x00;
            send[2] = 0;
            send[3] = 0;
            send[4] = 0;
            send[5] = 0;
            send[6] = 0;
            send[7] = 0;
            send[8] = 0;
            send[9] = 0;

            //request!
            is_received = false;
            serialPort1.Write(send, 0, 10);
            richTextBox1.Text += "Request!\n";

            //시간을 측정해보자!
            DateTime timeout = DateTime.Now;
            while (true)
            {
                //무한루프생성
                if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                {
                    richTextBox1.Text += "TIMEOUT\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                    break;
                }
                if (is_received)
                {
                    //richTextBox1.Text += "RECEIVED!\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                    byte[] recv = new byte[10];
                    serialPort1.Read(recv, 0, 10);

                    //recv[0] ~ recv[9]
                    //recv[2] recv[3]
                    int rpm = recv[2] * 256 + recv[3];
                    label3.Text = rpm + "RPM";

                    //리스트뷰에 수신메시지를 집어넣자!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = recv[0].ToString("X");
                    for (int i = 1; i < 10; i++)
                    {
                            lvi.SubItems.Add(recv[i].ToString("X"));
                    }

                    listView2.Items.Add(lvi);

                    break;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
            timer1.Start();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            byte[] send = new byte[10];
            send[0] = 0x02; //3번아두이노의 ID
            send[1] = 0x00;
            send[2] = 0;
            send[3] = 0;
            send[4] = 0;
            send[5] = 0;
            send[6] = 0;
            send[7] = 0;
            send[8] = 0;
            send[9] = 0;

            //request!
            is_received = false;
            serialPort1.Write(send, 0, 10);
            richTextBox1.Text += "Request!\n";

            //시간을 측정해보자!
            DateTime timeout = DateTime.Now;
            while (true)
            {
                //무한루프생성
                if ((DateTime.Now - timeout).TotalMilliseconds > 1000)
                {
                    richTextBox1.Text += "TIMEOUT\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "FALSE";

                    break;
                }
                if (is_received)
                {
                    //richTextBox1.Text += "RECEIVED!\n";
                    //listView1.SelectedItems[0].SubItems[1].Text = "TRUE";
                    byte[] recv = new byte[10];
                    serialPort1.Read(recv, 0, 10);

                    //recv[0] ~ recv[9]
                    //recv[2] recv[3]
                    int rpm = recv[2] * 256 + recv[3];
                    label3.Text = rpm + "RPM";

                    //리스트뷰에 수신메시지를 집어넣자!
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = recv[0].ToString("X");
                    for (int i = 1; i < 10; i++)
                    {
                        lvi.SubItems.Add(recv[i].ToString("X"));
                    }

                    listView2.Items.Add(lvi);

                    break;
                }
            }
        }
    }
}
