﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace example142
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if(textBox1.Text != "" && textBox2.Text != "")
            {
                //첫번째 request
                string your_key = textBox1.Text;

                string egg_num = textBox2.Text;

                //request
                string query = "http://data.ekape.or.kr/openapi-data/service/user/grade/gradeinfo/egg?serviceKey=" + your_key + "&eggshellNo=" + egg_num;
                WebRequest wr = WebRequest.Create(query);
                wr.Method = "GET";

                WebResponse wrs = wr.GetResponse();
                Stream s = wrs.GetResponseStream();
                StreamReader sr = new StreamReader(s);

                string response = sr.ReadToEnd();


                XmlDocument xd = new XmlDocument();
                xd.LoadXml(response);

                XmlNode xn = xd["response"]["body"]["items"]["item"];

                textBox3.Text = xn["eggshellNo"].InnerText;
                textBox4.Text = xn["judgeYmd"].InnerText;
                textBox5.Text = xn["eggSpec"].InnerText;
                textBox6.Text = xn["eggDay"].InnerText;
                textBox7.Text = xn["eggBreedNm"].InnerText;
                textBox8.Text = xn["farmNm"].InnerText;

                sr.Close();
                s.Close();
                wrs.Close();
                

                //두번쨰 Request
                string date = DateTime.Now.ToString("yyyyMMdd");
                string query2 = "http://data.ekape.or.kr/openapi-data/service/user/grade/poultry/egg?serviceKey="+ your_key + "&startYmd="+ date + "&endYmd="+ date + "&type=1";

                WebRequest wr2 = WebRequest.Create(query2);
                wr2.Method = "GET";

                WebResponse wrs2 = wr2.GetResponse();
                Stream s2 = wrs2.GetResponseStream();

                StreamReader sr2 = new StreamReader(s2);

                string response2 = sr2.ReadToEnd();

                XmlDocument xd2 = new XmlDocument();
                xd2.LoadXml(response2);

                XmlNode xn2 = xd2["response"]["body"]["items"];

                //xn2.ChildNodes[0]["big"].InnerText
                //xn2.ChildNodes[1]["big"].InnerText

                textBox14.Text = xn2.ChildNodes[0]["typeName"].InnerText;
                textBox13.Text = xn2.ChildNodes[0]["modYmd"].InnerText;
                textBox12.Text = xn2.ChildNodes[0]["verybig"].InnerText +"원";
                textBox11.Text = xn2.ChildNodes[0]["special"].InnerText + "원";
                textBox10.Text = xn2.ChildNodes[0]["big"].InnerText + "원";
                textBox9.Text = xn2.ChildNodes[0]["medium"].InnerText + "원";
                textBox15.Text = xn2.ChildNodes[0]["small"].InnerText + "원";

                textBox22.Text = xn2.ChildNodes[1]["typeName"].InnerText;
                textBox21.Text = xn2.ChildNodes[1]["modYmd"].InnerText;
                textBox20.Text = xn2.ChildNodes[1]["verybig"].InnerText + "원";
                textBox19.Text = xn2.ChildNodes[1]["special"].InnerText + "원";
                textBox18.Text = xn2.ChildNodes[1]["big"].InnerText + "원";
                textBox17.Text = xn2.ChildNodes[1]["medium"].InnerText + "원";
                textBox16.Text = xn2.ChildNodes[1]["small"].InnerText + "원";

                sr2.Close();
                s2.Close();
                wrs2.Close();
            }
            else
            {
                MessageBox.Show("값을 입력해주세요!");
            }
            
        }
    }
}
