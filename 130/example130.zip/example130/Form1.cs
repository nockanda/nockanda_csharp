﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace example130
{
    public partial class Form1 : Form
    {
        bool direct = false; //false면 한국어->다른나라언어
        //true면 나른나라언어에서 -> 한국어

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //네이버 파파고 번역 서버에 request를 해보자!
            string url = "https://openapi.naver.com/v1/papago/n2mt";
            string client_id = textBox1.Text;
            string client_secret = textBox2.Text;


            WebRequest wr = WebRequest.Create(url);
            wr.Headers.Add("X-Naver-Client-Id", client_id);
            wr.Headers.Add("X-Naver-Client-Secret", client_secret);
            wr.Method = "POST";

            string query = "";

            string source = "";
            string target = "";
            if (direct)
            {
                //다른언어를 한국어로
                query = richTextBox2.Text;
                source = comboBox1.SelectedItem.ToString();
                target = "ko";
            }
            else
            {
                //한국어를 다른언어로
                query = richTextBox1.Text;
                source = "ko";
                target = comboBox1.SelectedItem.ToString();
            }


            byte[] byteDataParams = Encoding.UTF8.GetBytes("source=" + source + "&target=" + target + "&text=" + query);
            wr.ContentType = "application/x-www-form-urlencoded";
            wr.ContentLength = byteDataParams.Length;
            Stream st = wr.GetRequestStream();
            st.Write(byteDataParams, 0, byteDataParams.Length);
            st.Close();

            WebResponse wrs = wr.GetResponse();
            Stream stream = wrs.GetResponseStream();
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            string text = reader.ReadToEnd();
            stream.Close();
            wrs.Close();
            reader.Close();

            JObject json = JObject.Parse(text);

            if (direct)
            {
                richTextBox1.Text = json["message"]["result"]["translatedText"].ToString();
            }
            else
            {
                richTextBox2.Text = json["message"]["result"]["translatedText"].ToString();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string client_id = textBox1.Text;
            string client_secret = textBox2.Text;


            string url = "https://openapi.naver.com/v1/papago/detectLangs";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Headers.Add("X-Naver-Client-Id", client_id);
            request.Headers.Add("X-Naver-Client-Secret", client_secret);
            request.Method = "POST";
            string query = richTextBox3.Text;
            byte[] byteDataParams = Encoding.UTF8.GetBytes("query=" + query);
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = byteDataParams.Length;
            Stream st = request.GetRequestStream();
            st.Write(byteDataParams, 0, byteDataParams.Length);
            st.Close();
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream stream = response.GetResponseStream();
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            string text = reader.ReadToEnd();
            stream.Close();
            response.Close();
            reader.Close();

            JObject json = JObject.Parse(text);

            string code = json["langCode"].ToString();
            comboBox1.SelectedItem = code;
            textBox3.Text = code;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string client_id = textBox1.Text;
            string client_secret = textBox2.Text;


            string query = textBox4.Text;
            string url = "https://openapi.naver.com/v1/krdict/romanization?query=" + query;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Headers.Add("X-Naver-Client-Id", client_id); // 개발자센터에서 발급받은 Client ID
            request.Headers.Add("X-Naver-Client-Secret", client_secret); // 개발자센터에서 발급받은 Client Secret
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream stream = response.GetResponseStream();
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            string text = reader.ReadToEnd(); //JSON

            JObject json = JObject.Parse(text);
            JToken data = json["aResult"][0]["aItems"];


            listView1.Items.Clear();
            for (int i = 0;i< data.Count(); i++)
            {
                //richTextBox1.Text += (i+1) +"번째 : " + data[i].ToString() + "\n";
                ListViewItem lvi = new ListViewItem();
                lvi.Text = data[i]["name"].ToString();
                lvi.SubItems.Add(data[i]["score"].ToString());

                listView1.Items.Add(lvi);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (direct)
            {
                //다른언어를 한국어로 바꾸는경우
                button4.Text = "▶";
                direct = false;

            }
            else
            {
                //한국어를 다른언어로 바꾸는경우
                button4.Text = "◀";
                direct = true;
            }
        }
    }
}
